<?php
/** 
Plugin Name: Hand of Midas - Envato Affiliate Plugin
Plugin URI: http://codecanyon.net/user/coderevolution/portfolio
Description: This plugin will generate money for you, even in your sleep using the Envato Affiliate Program.
Author: CodeRevolution
Version: 1.1
Author URI: https://codecanyon.net/user/coderevolution
*/
defined( 'ABSPATH' ) or die();
require "update-checker/plugin-update-checker.php";

$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/midas/master/info.json", __FILE__, "midas-money-generator-envato-affiliate");
add_action('admin_menu', 'midas_register_my_custom_menu_page');
function midas_register_my_custom_menu_page()
{
    add_menu_page('Hand of Midas Envato Affiliate', 'Hand of Midas Envato Affiliate', 'manage_options', 'midas_admin_settings', 'midas_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('midas_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'midas_admin_settings');
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
        add_submenu_page('midas_admin_settings', 'Activity & Logging', 'Activity & Logging', 'manage_options', 'midas_logs', 'midas_logs');
        add_submenu_page('midas_admin_settings', 'Newest Market Items', 'Newest Market Items', 'manage_options', 'midas_newest_post_rules', 'midas_newest_post_rules');
        add_submenu_page('midas_admin_settings', 'Newest User Items', 'Newest User Items', 'manage_options', 'midas_newest_user', 'midas_newest_user');
        add_submenu_page('midas_admin_settings', 'Popular Market Items', 'Popular Market Items', 'manage_options', 'midas_popular_items', 'midas_popular_items');
        add_submenu_page('midas_admin_settings', 'Random Market Items', 'Random Market Items', 'manage_options', 'midas_random_items', 'midas_random_items');
        add_submenu_page('midas_admin_settings', 'Featured Market Items', 'Featured Market Items', 'manage_options', 'midas_featured_items', 'midas_featured_items');
        add_submenu_page('midas_admin_settings', 'Manual Items by ID', 'Manual Items by ID', 'manage_options', 'midas_manual_items', 'midas_manual_items');
        add_submenu_page('midas_admin_settings', 'Grouped Item Posts', 'Grouped Item Posts', 'manage_options', 'midas_group_items', 'midas_group_items');
    }
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'midas_add_settings_link');
function midas_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=midas_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
add_action('add_meta_boxes', 'midas_add_meta_box');
function midas_add_meta_box()
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] === 'on') {
        if (isset($midas_Main_Settings['enable_metabox']) && $midas_Main_Settings['enable_metabox'] == 'on') {
            add_meta_box('midas_meta_box_function_add', 'Hand of Midas Auto Generated Post Information', 'midas_meta_box_function', 'post', 'advanced', 'default');
            add_meta_box('midas_meta_box_function_add', 'Hand of Midas Auto Generated Post Information', 'midas_meta_box_function', 'page', 'advanced', 'default');
        }
    }
}
function midas_meta_box_function($post)
{
    $post_creator_last_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
    $post_item_id              = get_post_meta($post->ID, 'post_item_id', true);
    $post_parent_rule          = get_post_meta($post->ID, 'post_parent_rule', true);
    $post_parent_type          = get_post_meta($post->ID, 'post_parent_type', true);
    $post_thumbnail            = get_post_meta($post->ID, 'post_thumbnail', true);
    $post_item_marketplace     = get_post_meta($post->ID, 'post_item_marketplace', true);
    $post_item_url             = get_post_meta($post->ID, 'post_item_url', true);
    $post_item_user            = get_post_meta($post->ID, 'post_item_user', true);
    $post_item_thumbnail       = get_post_meta($post->ID, 'post_item_thumbnail', true);
    $post_item_media_url       = get_post_meta($post->ID, 'post_item_media_url', true);
    $post_item_cost            = get_post_meta($post->ID, 'post_item_cost', true);
    $post_item_uploaded        = get_post_meta($post->ID, 'post_item_uploaded', true);
    $post_item_last_update     = get_post_meta($post->ID, 'post_item_last_update', true);
    $post_item_cats            = get_post_meta($post->ID, 'post_item_cats', true);
    $post_item_tags            = get_post_meta($post->ID, 'post_item_tags', true);
    if (isset($post_item_id) && $post_item_id != '') {
        $ech = '<table><tr><td><b>Item Last Updated:</b></td><td>&nbsp;' . $post_creator_last_updated . '</td></tr>';
        $ech .= '<tr><td><b>Item ID:</b></td><td>&nbsp;' . $post_item_id . '</td></tr>';
        $ech .= '<tr><td><b>Post Created by Rule Type:</b></td><td>&nbsp;';
        if ($post_parent_type == '0') {
            $ech .= 'Newest Market Items Rules';
        } elseif ($post_parent_type == '1') {
            $ech .= 'Newest User Items Rules';
        } elseif ($post_parent_type == '2') {
            $ech .= 'Popular Market Items Rules';
        } elseif ($post_parent_type == '3') {
            $ech .= 'Random Market Items Rules';
        } elseif ($post_parent_type == '4') {
            $ech .= 'Featured Market Items Rules';
        } elseif ($post_parent_type == '5') {
            $ech .= 'Manual Items by ID Rules';
        } elseif ($post_parent_type == '6') {
            $ech .= 'Grouped Items Posts Rules';
        }
        else
        {
            $ech .= 'Unknown rule type: ' . $post_parent_type;
        }
        $ech .= '</td></tr>';
        $ech .= '<tr><td><b>Parent Rule ID:</b></td><td>&nbsp;' . $post_parent_rule . '</td></tr>';
        $ech .= '<tr><td><b>Post Preview Image URL:</b></td><td>&nbsp;' . $post_thumbnail . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Marketplace:</b></td><td>&nbsp;' . $post_item_marketplace . '</td></tr>';
        $ech .= '<tr><td><b>Post Item URL:</b></td><td>&nbsp;' . $post_item_url . '</td></tr>';
        $ech .= '<tr><td><b>Post Item User:</b></td><td>&nbsp;' . $post_item_user . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Thumbnail:</b></td><td>&nbsp;' . $post_item_thumbnail . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Media URL:</b></td><td>&nbsp;' . $post_item_media_url . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Cost:</b></td><td>&nbsp;' . $post_item_cost . '$</td></tr>';
        $ech .= '<tr><td><b>Post Item Upload Date:</b></td><td>&nbsp;' . $post_item_uploaded . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Last Updated Date:</b></td><td>&nbsp;' . $post_item_last_update . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Categories:</b></td><td>&nbsp;' . $post_item_cats . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Tags:</b></td><td>&nbsp;' . $post_item_tags . '</td></tr>';
        $ech .= '</table><br/>';
        $ech .= '<p><b>Import Comments From <a href="' . $post_item_url . '" target="_blank">Marketplace Item</a>:</b></p>';
        $ech .= '<input type="hidden" id="item_id" name="item_id" value="' . $post_item_id . '"/>';
        $ech .= '<input type="hidden" id="post_id" name="post_id" value="' . $post->ID . '"/>';
        $ech .= 'Maximum Comments to Import:&nbsp;<input type="number" id="max_comments" step="1" min="0" max="50" name="max_comments" value="10"/>';
        $ech .= '&nbsp;&nbsp;<button id="submit-my-form" type="submit">Import Comments Now</button>';
    } else {
        $ech = 'This is not an automatically generated post.';
    }
    echo $ech;
}
function midas_my_ajax_action() {
    if(!isset($_POST['max_comments']) || $_POST['max_comments'] == '')
    {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[CommentImporter] max_comments not set!', '0', 7, '1');
        }
        echo '-1';
        die();
    }
    if(!isset($_POST['item_id']) || $_POST['item_id'] == '')
    {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[CommentImporter] item_id not set!', '0', 7, '1');
        }
        echo '-1';
        die();
    }
    if(!isset($_POST['post_id']) || $_POST['post_id'] == '')
    {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[CommentImporter] post_id not set!', '0', 7, '1');
        }
        echo '-1';
        die();
    }
    $post_id = $_POST['post_id'];
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['rule_timeout']) && $midas_Main_Settings['rule_timeout'] != '')
    {
        $timeout = intval($midas_Main_Settings['rule_timeout']);
    }
    else
    {
        $timeout = 3600;
    }
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', $timeout);
    @ini_set('ignore_user_abort', 1);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    ignore_user_abort(true);
    set_time_limit($timeout);
    $comments_inserted = 1;
    $feed_uri = 'https://marketplace.envato.com/feeds/items/' . $_POST['item_id'];
    $newItems = file_get_contents($feed_uri);
    if ($newItems === false) {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[CommentImporter] file_get_contents failed!', '0', 7, '1');
        }
        echo '-1';
        die();
    }
    $content_xml = new DOMDocument();
    if (!$content_xml->loadXML($newItems)) {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[CommentImporter] loadXML failed!', '0', 7, '1');
        }
        echo '-1';
        die();
    }
    $content = '';
    $author = '';
    $max_comments = intval($_POST['max_comments']);
    $existing_comments = get_comments('post_id=' . $post_id);          
    foreach ($content_xml->documentElement->childNodes as $item_xml) {
        if($comments_inserted <= $max_comments)
        {
            $content = midas_get_xml_value($item_xml, 'content');
            $author = midas_get_xml_value($item_xml, 'author');
            if(isset($content) && trim($content) != '' && isset($author) && trim($author) != '')
            {
                $time = midas_get_xml_value($item_xml, 'published');
                if(!isset($time) || trim($time) == '')
                {
                    $time = current_time('mysql');
                }
                $content = midas_replaceContentSmileys($content);
                $found = false;
                foreach($existing_comments as $comment)
                {
                    if($comment->comment_author == trim($author) && $comment->comment_content == trim($content))
                    {
                        $found = true;
                        break;
                    }
                }
                if($found)
                {
                    continue;
                }
                $data = array(
                    'comment_post_ID' => $post_id,
                    'comment_author' => trim($author),
                    'comment_author_email' => '',
                    'comment_author_url' => '',
                    'comment_content' => trim($content),
                    'comment_type' => '',
                    'comment_parent' => 0,
                    'user_id' => 1,
                    'comment_author_IP' => '127.0.0.1',
                    'comment_agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36',
                    'comment_date' => $time,
                    'comment_approved' => 1
                );
                $ret = wp_insert_comment($data);
                if($ret !== FALSE)
                {
                    $comments_inserted++;
                }
            }
        }
        else
        {
            break;
        }
    }
    echo $comments_inserted - 1;
    die();
}

function midas_my_ajax_action_init() {
    if (isset($_POST['action']) && $_POST['action'] == 'midas_my_ajax_action') {
        do_action('wp_ajax_midas_my_ajax_action');
    }
}

if (is_admin()){
    add_action('wp_ajax_midas_my_ajax_action', 'midas_my_ajax_action');
}

add_action( 'init', 'midas_my_ajax_action_init');
function midas_debug_to_console($data)
{
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
add_filter('cron_schedules', 'midas_add_cron_schedule');
function midas_add_cron_schedule($schedules)
{
    $schedules['midas_cron'] = array(
        'interval' => 3600,
        'display' => __('Midas Cron')
    );
    $schedules['weekly']     = array(
        'interval' => 604800,
        'display' => __('Once Weekly')
    );
    $schedules['monthly']    = array(
        'interval' => 2592000,
        'display' => __('Once Monthly')
    );
    return $schedules;
}
function midas_auto_clear_log() {
    if(file_exists(WP_CONTENT_DIR . '/midas_info.log'))
    {
        unlink(WP_CONTENT_DIR . '/midas_info.log');
    }
}

function midas_shutdown() 
{ 
    $a=error_get_last(); 
    if($a !== null)
    {
        midas_log_to_file ('[EXIT] Exit error type: ' . $a['type'] . ', message: ' . $a['message'] . ', file: ' . $a['file'] . ', line: ' . $a['line'] . '!', '0', 7, '1');
    }
}

function midas_auto_update_posts() {
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['rule_timeout']) && $midas_Main_Settings['rule_timeout'] != '')
    {
        $timeout = intval($midas_Main_Settings['rule_timeout']);
    }
    else
    {
        $timeout = 3600;
    }
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', $timeout);
    @ini_set('ignore_user_abort', 1);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    ignore_user_abort(true);
    set_time_limit($timeout);
    $auto = 1;
    $updated = 0;
    if (!get_option('midas_auto_running_list')) {
        $running = array();
    } else {
        $running = get_option('midas_auto_running_list');
    }
    if (!empty($running)) {
        if (in_array(array('auto_update' => 'auto_update'), $running)) {
            return;
        }
    }
    $running[] = array(
        'auto_update' => 'auto_update'
    );
    update_option('midas_auto_running_list', $running);
    try
    {
        $query = array(
            'post_status' => array(
                'publish',
                'draft',
                'pending',
                'trash',
                'private'
            ),
            'post_type' => array(
                'any'
            ),
            'numberposts' => -1
        );
        
        if (isset($midas_Main_Settings['user_name'])) {
            $envato_username = $midas_Main_Settings['user_name'];
        } else {
            $envato_username = '';
        }
        $post_list = get_posts($query);
        foreach ($post_list as $post) {
            $id = get_post_meta($post->ID, 'post_item_id', true);
            $type = get_post_meta($post->ID, 'post_parent_type', true);
            $param = get_post_meta($post->ID, 'post_parent_rule', true);
            $marketplace = get_post_meta($post->ID, 'post_item_marketplace', true);
            if(!isset($type) || $type == '')
            {
                if(isset($midas_Main_Settings['enable_detailed_logging']))
                {
                    midas_log_to_file ('[AutoUpdater] User generated post detected (type not set): ' . $post->ID . '!', $param, $type, $auto);
                }
                continue;
            }
            if($type == '6')
            {
                continue;
            }
            if(!isset($marketplace) || $marketplace == '')
            {
                if(isset($midas_Main_Settings['enable_detailed_logging']) && $type != '6')
                {
                    midas_log_to_file ('[AutoUpdater] marketplace is not set for post: ' . $post->ID . '!', $param, $type, $auto);
                }
                continue;
            }
            if(!isset($param) || $param == '')
            {
                if(isset($midas_Main_Settings['enable_detailed_logging']))
                {
                    midas_log_to_file ('[AutoUpdater] param is not set for post: ' . $post->ID . '!', $param, $type, $auto);
                }
                continue;
            }
            if(isset($id) && $id != '')
            {
                if(substr($id, 0, strlen('group')) !== 'group')
                {
                    $item_in_post_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
                    $item_info = file_get_contents("https://marketplace.envato.com/api/v3/item:" . $id . ".json");
                    if ($item_info === false) {
                        midas_log_to_file ('[AutoUpdater] file_get_contents failed: ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                        continue;
                    }
                    $json = json_decode($item_info, true);
                    if ($json === NULL) {
                        midas_log_to_file ('[AutoUpdater] json_decode failed: ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                        continue;
                    }
                    if (!isset($json['item'])) {
                        midas_log_to_file ('[AutoUpdater] json[item] not set: ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                        continue;
                    }
                    $dom = new DOMDocument();
                    if (!isset($json['item']['url'])) {
                        midas_log_to_file ('[AutoUpdater] Item does not have url attribute ' . 'https://marketplace.envato.com/api/v3/item:' . $id . '.json' . '!', $param, $type, $auto);
                        continue;
                    }
                    @$dom->loadHTMLFile($json['item']['url']);
                    if ($dom === FALSE) {
                        midas_log_to_file ('[AutoUpdater] loadHTMLFile failed for: ' . $json['item']['url'] . '!', $param, $type, $auto);
                        continue;
                    }
                    $xpath   = new DOMXPath($dom);
                    $div     = $xpath->query('//div[@class="user-html"]');
                    if ($div === FALSE) {
                        midas_log_to_file ('[AutoUpdater] xpath->query failed for: ' . $json['item']['url'] . '!', $param, $type, $auto);
                        continue;
                    }
                    $div     = $div->item(0);
                    $content = $dom->saveXML($div);
                    if ($content === FALSE) {
                        midas_log_to_file ('[AutoUpdater] saveXML failed for: ' . $json['item']['url'] . '!', $param, $type, $auto);
                        continue;
                    }
                    $item_last_update = isset($json['item']['last_update']) ? $json['item']['last_update'] : '';
                    if ($item_in_post_updated != $item_last_update && $item_last_update != '') {
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['submit_status'])) {
                                $post_status = $midas_Main_Settings['submit_status'];
                            } else {
                                $post_status = 'publish';
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['submit_status_user'])) {
                                $post_status = $midas_Main_Settings['submit_status_user'];
                            } else {
                                $post_status = 'publish';
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['submit_status_popular'])) {
                                $post_status = $midas_Main_Settings['submit_status_popular'];
                            } else {
                                $post_status = 'publish';
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['submit_status_random'])) {
                                $post_status = $midas_Main_Settings['submit_status_random'];
                            } else {
                                $post_status = 'publish';
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['submit_status_featured'])) {
                                $post_status = $midas_Main_Settings['submit_status_featured'];
                            } else {
                                $post_status = 'publish';
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['submit_status_manual'])) {
                                $post_status = $midas_Main_Settings['submit_status_manual'];
                            } else {
                                $post_status = 'publish';
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['submit_status_grouped'])) {
                                $post_status = $midas_Main_Settings['submit_status_grouped'];
                            } else {
                                $post_status = 'publish';
                            }
                        } else {
                            if (isset($midas_Main_Settings['submit_status'])) {
                                $post_status = $midas_Main_Settings['submit_status'];
                            } else {
                                $post_status = 'publish';
                            }
                        }
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['default_type'])) {
                                $post_type = $midas_Main_Settings['default_type'];
                            } else {
                                $post_type = 'post';
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['default_type_user'])) {
                                $post_type = $midas_Main_Settings['default_type_user'];
                            } else {
                                $post_type = 'post';
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['default_type_popular'])) {
                                $post_type = $midas_Main_Settings['default_type_popular'];
                            } else {
                                $post_type = 'post';
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['default_type_random'])) {
                                $post_type = $midas_Main_Settings['default_type_random'];
                            } else {
                                $post_type = 'post';
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['default_type_featured'])) {
                                $post_type = $midas_Main_Settings['default_type_featured'];
                            } else {
                                $post_type = 'post';
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['default_type_manual'])) {
                                $post_type = $midas_Main_Settings['default_type_manual'];
                            } else {
                                $post_type = 'post';
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['default_type_grouped'])) {
                                $post_type = $midas_Main_Settings['default_type_grouped'];
                            } else {
                                $post_type = 'post';
                            }
                        } else {
                            if (isset($midas_Main_Settings['default_type'])) {
                                $post_type = $midas_Main_Settings['default_type'];
                            } else {
                                $post_type = 'post';
                            }
                        }
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['enable_comments']) && $midas_Main_Settings['enable_comments'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['enable_comments_user']) && $midas_Main_Settings['enable_comments_user'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['enable_comments_popular']) && $midas_Main_Settings['enable_comments_popular'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['enable_comments_random']) && $midas_Main_Settings['enable_comments_random'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['enable_comments_featured']) && $midas_Main_Settings['enable_comments_featured'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['enable_comments_manual']) && $midas_Main_Settings['enable_comments_manual'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['enable_comments_grouped']) && $midas_Main_Settings['enable_comments_grouped'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        } else {
                            if (isset($midas_Main_Settings['enable_comments']) && $midas_Main_Settings['enable_comments'] == 'on') {
                                $accept_comments = 'open';
                            } else {
                                $accept_comments = 'closed';
                            }
                        }
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['post_user_name'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name'];
                            } else {
                                $post_user_name = 1;
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['post_user_name_user'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name_user'];
                            } else {
                                $post_user_name = 1;
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['post_user_name_popular'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name_popular'];
                            } else {
                                $post_user_name = 1;
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['post_user_name_random'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name_random'];
                            } else {
                                $post_user_name = 1;
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['post_user_name_featured'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name_featured'];
                            } else {
                                $post_user_name = 1;
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['post_user_name_manual'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name_manual'];
                            } else {
                                $post_user_name = 1;
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['post_user_name_grouped'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name_grouped'];
                            } else {
                                $post_user_name = 1;
                            }
                        } else {
                            if (isset($midas_Main_Settings['post_user_name'])) {
                                $post_user_name = $midas_Main_Settings['post_user_name'];
                            } else {
                                $post_user_name = 1;
                            }
                        }
                        
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['auto_categories'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['auto_categories_user'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories_user'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['auto_categories_popular'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories_popular'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['auto_categories_random'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories_random'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['auto_categories_featured'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories_featured'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['auto_categories_manual'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories_manual'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['auto_categories_grouped'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories_grouped'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        } else {
                            if (isset($midas_Main_Settings['auto_categories'])) {
                                $can_create_cat = $midas_Main_Settings['auto_categories'];
                            } else {
                                $can_create_cat = 'off';
                            }
                        }
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['default_tags'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags'];
                            } else {
                                $item_create_tag = '';
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['default_tags_user'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags_user'];
                            } else {
                                $item_create_tag = '';
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['default_tags_popular'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags_popular'];
                            } else {
                                $item_create_tag = '';
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['default_tags_random'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags_random'];
                            } else {
                                $item_create_tag = '';
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['default_tags_featured'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags_featured'];
                            } else {
                                $item_create_tag = '';
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['default_tags_manual'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags_manual'];
                            } else {
                                $item_create_tag = '';
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['default_tags_grouped'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags_grouped'];
                            } else {
                                $item_create_tag = '';
                            }
                        } else {
                            if (isset($midas_Main_Settings['default_tags'])) {
                                $item_create_tag = $midas_Main_Settings['default_tags'];
                            } else {
                                $item_create_tag = '';
                            }
                        }
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['auto_image'])) {
                                $auto_image = $midas_Main_Settings['auto_image'];
                            } else {
                                $auto_image = '';
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['auto_image_user'])) {
                                $auto_image = $midas_Main_Settings['auto_image_user'];
                            } else {
                                $auto_image = '';
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['auto_image_popular'])) {
                                $auto_image = $midas_Main_Settings['auto_image_popular'];
                            } else {
                                $auto_image = '';
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['auto_image_random'])) {
                                $auto_image = $midas_Main_Settings['auto_image_random'];
                            } else {
                                $auto_image = '';
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['auto_image_featured'])) {
                                $auto_image = $midas_Main_Settings['auto_image_featured'];
                            } else {
                                $auto_image = '';
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['auto_image_manual'])) {
                                $auto_image = $midas_Main_Settings['auto_image_manual'];
                            } else {
                                $auto_image = '';
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['auto_image_grouped'])) {
                                $auto_image = $midas_Main_Settings['auto_image_grouped'];
                            } else {
                                $auto_image = '';
                            }
                        } else {
                            if (isset($midas_Main_Settings['auto_image'])) {
                                $auto_image = $midas_Main_Settings['auto_image'];
                            } else {
                                $auto_image = '';
                            }
                        }
                        if ($type == 0) {
                            if (isset($midas_Main_Settings['auto_tags'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        } elseif ($type == 1) {
                            if (isset($midas_Main_Settings['auto_tags_user'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags_user'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        } elseif ($type == 2) {
                            if (isset($midas_Main_Settings['auto_tags_popular'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags_popular'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        } elseif ($type == 3) {
                            if (isset($midas_Main_Settings['auto_tags_random'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags_random'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        } elseif ($type == 4) {
                            if (isset($midas_Main_Settings['auto_tags_featured'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags_featured'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        } elseif ($type == 5) {
                            if (isset($midas_Main_Settings['auto_tags_manual'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags_manual'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        } elseif ($type == 6) {
                            if (isset($midas_Main_Settings['auto_tags_grouped'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags_grouped'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        } else {
                            if (isset($midas_Main_Settings['auto_tags'])) {
                                $can_create_tag = $midas_Main_Settings['auto_tags'];
                            } else {
                                $can_create_tag = 'off';
                            }
                        }
                        $item_media = '';
                        if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                            $item_media = isset($json['item']['preview_url']) ? $json['item']['preview_url'] : '';
                        }
                        if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                            $item_media = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                        }
                        $item_img                  = isset($json['item']['live_preview_url']) ? $json['item']['live_preview_url'] : '';
                        $item_video                = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                        $item_thumb                = isset($json['item']['thumbnail']) ? $json['item']['thumbnail'] : '';
                        $item_url                  = isset($json['item']['url']) ? $json['item']['url'] : '';
                        $item_user                 = isset($json['item']['user']) ? $json['item']['user'] : '';
                        $item_cost                 = isset($json['item']['cost']) ? $json['item']['cost'] : '';
                        $item_cat                  = isset($json['item']['category']) ? $json['item']['category'] : '';
                        $item_tags                 = isset($json['item']['tags']) ? $json['item']['tags'] : '';
                        $item_uploaded             = isset($json['item']['uploaded_on']) ? $json['item']['uploaded_on'] : '';
                        $just_title                = isset($json['item']['item']) ? $json['item']['item'] : '';
                        $item_sales                = isset($json['item']['sales']) ? $json['item']['sales'] : '';
                        $item_rating               = isset($json['item']['rating']) ? $json['item']['rating'] : '';
                        $my_post                   = array();
                        $my_post['ID']             = $post->ID;
                        $my_post['post_type']      = $post_type;
                        $my_post['comment_status'] = $accept_comments;
                        $my_post['post_status']    = $post_status;
                        $my_post['post_author']    = $post_user_name;
                        if ($can_create_tag == 'on') {
                            $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                        } else if ($item_create_tag != '') {
                            $my_post['tags_input'] = $item_create_tag;
                        }
                        $my_post['post_item_id']             = $id;
                        $my_post['post_item_marketplace']    = $marketplace;
                        $my_post['post_item_user']           = $item_user;
                        $my_post['post_item_url']            = $item_url;
                        $my_post['post_item_thumbnail']      = $item_thumb;
                        $my_post['post_item_preview_img']    = $item_img;
                        $my_post['post_item_media_url']      = $item_media;
                        $my_post['post_item_cost']           = $item_cost;
                        $my_post['post_item_uploaded']       = $item_uploaded;
                        $my_post['post_item_cats']           = $item_cat;
                        $my_post['post_item_tags']           = $item_tags;
                        $my_post['market_item_last_updated'] = $item_last_update;
                        if ($type == 0) {
                            $the_content = $midas_Main_Settings['post_content'];
                        } elseif ($type == 1) {
                            $the_content = $midas_Main_Settings['post_content_user'];
                        } elseif ($type == 2) {
                            $the_content = $midas_Main_Settings['post_content_popular'];
                        } elseif ($type == 3) {
                            $the_content = $midas_Main_Settings['post_content_random'];
                        } elseif ($type == 4) {
                            $the_content = $midas_Main_Settings['post_content_featured'];
                        } elseif ($type == 5) {
                            $the_content = $midas_Main_Settings['post_content_manual'];
                        } else{
                            $the_content = '';
                        }
                        if (strpos($the_content, '%%') !== false) {
                            $the_content = midas_replaceContentShortcodes($the_content, $json['item'], $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                        }
                        if (strpos($the_content, 'images/smileys/') !== false) {
                            $the_content = midas_replaceContentSmileys($the_content);
                        }
                        $my_post['post_excerpt']   = midas_getExcerpt($content);
                        $my_post['post_content'] = $the_content;
                        if ($type == 0) {
                            $the_title = $midas_Main_Settings['post_title'];
                        } elseif ($type == 1) {
                            $the_title = $midas_Main_Settings['post_title_user'];
                        } elseif ($type == 2) {
                            $the_title = $midas_Main_Settings['post_title_popular'];
                        } elseif ($type == 3) {
                            $the_title = $midas_Main_Settings['post_title_random'];
                        } elseif ($type == 4) {
                            $the_title = $midas_Main_Settings['post_title_featured'];
                        } elseif ($type == 5) {
                            $the_title = $midas_Main_Settings['post_title_manual'];
                        } else {
                            $the_title = '';
                        }
                        if (strpos($the_title, '%%') !== false) {
                            $the_title = midas_replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                        }
                        $my_post['post_title'] = $the_title;
                        $post_id = wp_update_post($my_post);
                        if ($post_id != 0) {
                            $updated++;
                            $image_failed = false;
                            if ($auto_image === 'on') {
                                if ($my_post['post_item_preview_img'] != '') {
                                    if(!midas_generate_featured_image($my_post['post_item_preview_img'], $post_id))
                                    {
                                        $image_failed = true;
                                        midas_log_to_file ('[AutoUpdater] midas_generate_featured_image failed!', $param, $type, $auto);
                                    }
                                }
                                else
                                {
                                    $image_failed = true;
                                }
                            }
                            if($image_failed || $auto_image !== 'on' || $type == 6)
                            {
                                $image_url = '';
                                if($type == 0 && isset($midas_Main_Settings['featured_image_default']))
                                {
                                    $image_url = $midas_Main_Settings['featured_image_default'];
                                }
                                elseif($type == 1 && isset($midas_Main_Settings['featured_image_user']))
                                {
                                    $image_url = $midas_Main_Settings['featured_image_user'];
                                }
                                elseif($type == 2 && isset($midas_Main_Settings['featured_image_popular']))
                                {
                                    $image_url = $midas_Main_Settings['featured_image_popular'];
                                }
                                elseif($type == 3 && isset($midas_Main_Settings['featured_image_random']))
                                {
                                    $image_url = $midas_Main_Settings['featured_image_random'];
                                }
                                elseif($type == 4 && isset($midas_Main_Settings['featured_image_featured']))
                                {
                                    $image_url = $midas_Main_Settings['featured_image_featured'];
                                }
                                elseif($type == 5 && isset($midas_Main_Settings['featured_image_manual']))
                                {
                                    $image_url = $midas_Main_Settings['featured_image_manual'];
                                }
                                elseif($type == 6 && isset($midas_Main_Settings['featured_image_grouped']))
                                {
                                    $image_url = $midas_Main_Settings['featured_image_grouped'];
                                }
                                if($image_url != '')
                                {
                                    $url_headers=get_headers($image_url, 1);
                                    if(isset($url_headers['Content-Type'])){
                                        $img_type=strtolower($url_headers['Content-Type']);
                                        $valid_image_type=array();
                                        $valid_image_type['image/png']='';
                                        $valid_image_type['image/jpg']='';
                                        $valid_image_type['image/jpeg']='';
                                        $valid_image_type['image/jpe']='';
                                        $valid_image_type['image/gif']='';
                                        $valid_image_type['image/tif']='';
                                        $valid_image_type['image/tiff']='';
                                        $valid_image_type['image/svg']='';
                                        $valid_image_type['image/ico']='';
                                        $valid_image_type['image/icon']='';
                                        $valid_image_type['image/x-icon']='';
                                        if(isset($valid_image_type[$img_type])){
                                            if(!midas_generate_featured_image($image_url, $post_id))
                                            {
                                                $image_failed = true;
                                                midas_log_to_file ('midas_generate_featured_image failed to deafault value: '. $image_url . '!', $param, $type, $auto);
                                            }
                                        }
                                    }
                                }
                            }
                            midas_updatePostMeta($post_id, $my_post, $param, $type, $envato_username);
                            if ($can_create_cat == 'on') {
                                $termid = midas_create_terms('category', '0', $my_post['post_item_cats']);
                                wp_set_post_terms($post_id, $termid, 'category');
                            }
                            if ($type == 0) {
                                if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            } 
                            elseif ($type == 1) {
                                if (isset($midas_Main_Settings['default_category_user']) && $midas_Main_Settings['default_category_user'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category_user'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            } elseif ($type == 2) {
                                if (isset($midas_Main_Settings['default_category_popular']) && $midas_Main_Settings['default_category_popular'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category_popular'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            } elseif ($type == 3) {
                                if (isset($midas_Main_Settings['default_category_random']) && $midas_Main_Settings['default_category_random'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category_random'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            } elseif ($type == 4) {
                                if (isset($midas_Main_Settings['default_category_featured']) && $midas_Main_Settings['default_category_featured'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category_featured'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            } elseif ($type == 5) {
                                if (isset($midas_Main_Settings['default_category_manual']) && $midas_Main_Settings['default_category_manual'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category_manual'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            } elseif ($type == 6) {
                                if (isset($midas_Main_Settings['default_category_grouped']) && $midas_Main_Settings['default_category_grouped'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category_grouped'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            } else {
                                if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                    $cats   = array();
                                    $cats[] = $midas_Main_Settings['default_category'];
                                    wp_set_post_categories($post_id, $cats, true);
                                }
                            }
                        }
                        else
                        {
                            midas_log_to_file ('[AutoUpdater] Failed to update post: ' . $my_post['post_title'] . '!', $param, $type, $auto);
                        }
                    }  
                }
            }
        }
    }
    catch (Exception $e) {
        midas_clearFromAutoList('auto_update', 'auto_update');
        midas_log_to_file ('[AutoUpdater] Exception thrown at auto update: ' . $e . '!', $param, $type, $auto);
        return 'fail';
    }
    midas_clearFromAutoList('auto_update', 'auto_update');
    if(isset($midas_Main_Settings['enable_detailed_logging']))
    {
        midas_log_to_file ('[AutoUpdater] Auto update process successful! Updated posts: ' . $updated, $param, $type, $auto);
    }
}
register_deactivation_hook(__FILE__, 'midas_my_deactivation');
function midas_my_deactivation() {
	wp_clear_scheduled_hook('midasaction');
    wp_clear_scheduled_hook('midasactionclear');
    wp_clear_scheduled_hook('midasactionupdate');
    $running = array();
    update_option('midas_running_list', $running);
    update_option('midas_auto_running_list', $running);
}
add_action('midasaction', 'midas_cron');
add_action('midasactionclear', 'midas_auto_clear_log' );
add_action('midasactionupdate', 'midas_auto_update_posts' );
if(is_admin())
{
    midas_cron_schedule();
}
function midas_cron_schedule()
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] === 'on') {      
        if (!wp_next_scheduled('midasaction')) {
            $rez = wp_schedule_event(time(), 'midas_cron', 'midasaction');
            if($rez === FALSE)
            {
                midas_log_to_file ('[Scheduler] Failed to schedule midasaction to midas_cron!', '0', 7, '1');
            }
        }
        
        if(isset($midas_Main_Settings['enable_logging']) && $midas_Main_Settings['enable_logging'] === 'on' && isset($midas_Main_Settings['auto_clear_logs']) && $midas_Main_Settings['auto_clear_logs'] !== 'No')
        {
            if (!wp_next_scheduled( 'midasactionclear')) 
            {
                $rez = wp_schedule_event(time(), $midas_Main_Settings['auto_clear_logs'], 'midasactionclear' );
                if($rez === FALSE)
                {
                    midas_log_to_file ('[Scheduler] Failed to schedule midasactionclear to ' . $midas_Main_Settings['auto_clear_logs'] . '!', '0', 7, '1');
                }
                add_option('midas_schedule_time', $midas_Main_Settings['auto_clear_logs']);
            }
            else
            {
                if (!get_option('midas_schedule_time')) {
                    wp_clear_scheduled_hook( 'midasactionclear' );
                    $rez = wp_schedule_event(time(), $midas_Main_Settings['auto_clear_logs'], 'midasactionclear' );
                    add_option('midas_schedule_time', $midas_Main_Settings['auto_clear_logs']);
                    if($rez === FALSE)
                    {
                        midas_log_to_file ('[Scheduler] Failed to schedule midasactionclear to ' . $midas_Main_Settings['auto_clear_logs'] . '!', '0', 7, '1');
                    }
                }
                else
                {
                    $the_time = get_option('midas_schedule_time');
                    if($the_time != $midas_Main_Settings['auto_clear_logs'])
                    {
                        wp_clear_scheduled_hook( 'midasactionclear' );
                        delete_option('midas_schedule_time');
                        $rez = wp_schedule_event(time(), $midas_Main_Settings['auto_clear_logs'], 'midasactionclear' );
                        add_option('midas_schedule_time', $midas_Main_Settings['auto_clear_logs']);
                        if($rez === FALSE)
                        {
                            midas_log_to_file ('[Scheduler] Failed to schedule midasactionclear to ' . $midas_Main_Settings['auto_clear_logs'] . '!', '0', 7, '1');
                        }
                    }
                }
            }
        }
        else
        {
            if (!wp_next_scheduled( 'midasactionclear' )) 
            {
                delete_option('midas_schedule_time');
            }
            else
            {
                wp_clear_scheduled_hook( 'midasactionclear' );
                delete_option('midas_schedule_time');
            }
        }
        
        if(isset($midas_Main_Settings['auto_update_posts']) && $midas_Main_Settings['auto_update_posts'] !== 'No')
        {
            if (!wp_next_scheduled( 'midasactionupdate')) 
            {
                $rez = wp_schedule_event(time(), $midas_Main_Settings['auto_update_posts'], 'midasactionupdate' );
                add_option('midas_schedule_update_time', $midas_Main_Settings['auto_update_posts']);
                if($rez === FALSE)
                {
                    midas_log_to_file ('[Scheduler] Failed to schedule midasactionupdate to ' . $midas_Main_Settings['auto_update_posts'] . '!', '0', 7, '1');
                }
            }
            else
            {
                if (!get_option('midas_schedule_update_time')) {
                    wp_clear_scheduled_hook( 'midasactionupdate' );
                    $rez = wp_schedule_event(time(), $midas_Main_Settings['auto_update_posts'], 'midasactionupdate' );
                    add_option('midas_schedule_update_time', $midas_Main_Settings['auto_update_posts']);
                    if($rez === FALSE)
                    {
                       midas_log_to_file ('[Scheduler] Failed to schedule midasactionupdate to ' . $midas_Main_Settings['auto_update_posts'] . '!', '0', 7, '1');
                    }
                }
                else
                {
                    $the_time = get_option('midas_schedule_update_time');
                    if($the_time != $midas_Main_Settings['auto_update_posts'])
                    {
                        wp_clear_scheduled_hook( 'midasactionupdate' );
                        delete_option('midas_schedule_update_time');
                        $rez = wp_schedule_event(time(), $midas_Main_Settings['auto_update_posts'], 'midasactionupdate' );
                        add_option('midas_schedule_update_time', $midas_Main_Settings['auto_update_posts']);
                        if($rez === FALSE)
                        {
                            midas_log_to_file ('[Scheduler] Failed to schedule midasactionupdate to ' . $midas_Main_Settings['auto_update_posts'] . '!', '0', 7, '1');
                        }
                    }
                }
            }
        }
        else
        {
            if (!wp_next_scheduled( 'midasactionupdate' )) 
            {
                delete_option('midas_schedule_update_time');
            }
            else
            {
                wp_clear_scheduled_hook( 'midasactionupdate' );
                delete_option('midas_schedule_update_time');
            }
        }
    }
    else 
    {
        if (wp_next_scheduled('midasaction')) {
            wp_clear_scheduled_hook('midasaction');
        }
        
        if (!wp_next_scheduled( 'midasactionclear' )) 
        {
            delete_option('midas_schedule_time');
        }
        else
        {
            wp_clear_scheduled_hook( 'midasactionclear' );
            delete_option('midas_schedule_time');
        }
        
        if (!wp_next_scheduled( 'midasactionupdate' )) 
        {
            delete_option('midas_schedule_update_time');
        }
        else
        {
            wp_clear_scheduled_hook( 'midasactionupdate' );
            delete_option('midas_schedule_update_time');
        }
    }   
}
function midas_cron()
{
    if (!get_option('midas_rules_list')) {
        $rules = array();
    } else {
        $rules = get_option('midas_rules_list');
    }
    if (!empty($rules)) {
        $cont = 0;
        foreach ($rules as $request => $bundle[]) {
            $bundle_values   = array_values($bundle);
            $myValues        = $bundle_values[$cont];
            $array_my_values = array_values($myValues);
            $market          = isset($array_my_values[0]) ? $array_my_values[0] : '';
            $schedule        = isset($array_my_values[1]) ? $array_my_values[1] : '';
            $max             = isset($array_my_values[2]) ? $array_my_values[2] : '';
            $active          = isset($array_my_values[3]) ? $array_my_values[3] : '';
            $last_run        = isset($array_my_values[4]) ? $array_my_values[4] : '';
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 0);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_user_rules_list')) {
        $rules2 = array();
    } else {
        $rules2 = get_option('midas_user_rules_list');
    }
    if (!empty($rules2)) {
        $cont = 0;
        foreach ($rules2 as $request2 => $bundle2[]) {
            $bundle_values2   = array_values($bundle2);
            $myValues2        = $bundle_values2[$cont];
            $array_my_values2 = array_values($myValues2);
            $user             = isset($array_my_values2[0]) ? $array_my_values2[0] : '';
            $market           = isset($array_my_values2[1]) ? $array_my_values2[1] : '';
            $schedule         = isset($array_my_values2[2]) ? $array_my_values2[2] : '';
            $max              = isset($array_my_values2[3]) ? $array_my_values2[3] : '';
            $active           = isset($array_my_values2[4]) ? $array_my_values2[4] : '';
            $last_run         = isset($array_my_values2[5]) ? $array_my_values2[5] : '';
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 1);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_popular')) {
        $rules3 = array();
    } else {
        $rules3 = get_option('midas_rules_list_popular');
    }
    if (!empty($rules3)) {
        $cont = 0;
        foreach ($rules3 as $request3 => $bundle3[]) {
            $bundle_values3   = array_values($bundle3);
            $myValues3        = $bundle_values3[$cont];
            $array_my_values3 = array_values($myValues3);
            $market           = isset($array_my_values3[0]) ? $array_my_values3[0] : '';
            $schedule         = isset($array_my_values3[1]) ? $array_my_values3[1] : '';
            $max              = isset($array_my_values3[2]) ? $array_my_values3[2] : '';
            $active           = isset($array_my_values3[3]) ? $array_my_values3[3] : '';
            $last_run         = isset($array_my_values3[4]) ? $array_my_values3[4] : '';
            $type             = isset($array_my_values3[5]) ? $array_my_values3[5] : '';
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 2);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_random')) {
        $rules4 = array();
    } else {
        $rules4 = get_option('midas_rules_list_random');
    }
    if (!empty($rules4)) {
        $cont = 0;
        foreach ($rules4 as $request4 => $bundle4[]) {
            $bundle_values4   = array_values($bundle4);
            $myValues4        = $bundle_values4[$cont];
            $array_my_values4 = array_values($myValues4);
            $market           = isset($array_my_values4[0]) ? $array_my_values4[0] : '';
            $schedule         = isset($array_my_values4[1]) ? $array_my_values4[1] : '';
            $max              = isset($array_my_values4[2]) ? $array_my_values4[2] : '';
            $active           = isset($array_my_values4[3]) ? $array_my_values4[3] : '';
            $last_run         = isset($array_my_values4[4]) ? $array_my_values4[4] : '';
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 3);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_featured')) {
        $rules5 = array();
    } else {
        $rules5 = get_option('midas_rules_list_featured');
    }
    if (!empty($rules5)) {
        $cont = 0;
        foreach ($rules5 as $request5 => $bundle5[]) {
            $bundle_values5   = array_values($bundle5);
            $myValues5        = $bundle_values5[$cont];
            $array_my_values5 = array_values($myValues5);
            $market           = isset($array_my_values5[0]) ? $array_my_values5[0] : '';
            $schedule         = isset($array_my_values5[1]) ? $array_my_values5[1] : '';
            $max              = isset($array_my_values5[2]) ? $array_my_values5[2] : '';
            $active           = isset($array_my_values5[3]) ? $array_my_values5[3] : '';
            $last_run         = isset($array_my_values5[4]) ? $array_my_values5[4] : '';
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 4);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_manual')) {
        $rules6 = array();
    } else {
        $rules6 = get_option('midas_rules_list_manual');
    }
    if (!empty($rules6)) {
        $cont = 0;
        foreach ($rules6 as $request6 => $bundle6[]) {
            $bundle_values6   = array_values($bundle6);
            $myValues6        = $bundle_values6[$cont];
            $array_my_values6 = array_values($myValues6);
            $ids              = isset($array_my_values6[0]) ? $array_my_values6[0] : '';
            $schedule         = isset($array_my_values6[1]) ? $array_my_values6[1] : '';
            $active           = isset($array_my_values6[2]) ? $array_my_values6[2] : '';
            $last_run         = isset($array_my_values6[3]) ? $array_my_values6[3] : '';
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 5);
                }
            }
            $cont = $cont + 1;
        }
    }
}
function midas_add_ajaxurl()
{
    
    echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
}
function midas_log_to_file ($str, $param, $type, $auto) {
  $midas_Main_Settings = get_option('midas_Main_Settings', false);
  if(isset($midas_Main_Settings['enable_logging']) && $midas_Main_Settings['enable_logging'] == 'on')
  {
    $d = date("j-M-Y H:i:s e");
    $the_type = '';
    if($type == 0)
    {
        $the_type = 'NewestMarketItems';
    }
    elseif($type == 1)
    {
        $the_type = 'NewestUserItems';
    }
    elseif($type == 2)
    {
        $the_type = 'NewestPopularItems';
    }
    elseif($type == 3)
    {
        $the_type = 'NewestRandomItems';
    }
    elseif($type == 4)
    {
        $the_type = 'NewestFeaturedItems';
    }
    elseif($type == 5)
    {
        $the_type = 'NewestManualItems';
    }
    elseif($type == 6)
    {
        $the_type = 'NewestGroupedItems';
    }
    else
    {
        $the_type = 'ScheduleJob';
    }
    error_log("[$d][" . (($auto == '1') ? 'ScheduledRun' : 'ManualRun') . "][" . $the_type . "][ID" . $param . "] " .  $str . "<br/>\r\n", 3, WP_CONTENT_DIR . '/midas_info.log');
  }
}
function midas_delete_all_posts()
{
    $failed       = false;
    $number = 0;
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    $query     = array(
        'post_status' => array(
            'publish',
            'draft',
            'pending',
            'trash',
            'private'
        ),
        'post_type' => array(
            'any'
        ),
        'numberposts' => -1
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        $index       = get_post_meta($post->ID, 'post_parent_rule', true);
        $parent_type = get_post_meta($post->ID, 'post_parent_type', true);
        if (isset($index) && $index !== '' && isset($parent_type) && $parent_type !== '') {
            $args = array(
                'post_parent' => $post->ID
            );
            $post_attachments = get_children($args);
            if(isset($post_attachments) && !empty($post_attachments)) {
                foreach ($post_attachments as $attachment) {
                    wp_delete_attachment($attachment->ID, true);
                }
            }
            $res = wp_delete_post($post->ID, true);
            if ($res === false) {
                $failed = true;
            }
            else
            {
                $number++;
            }
        }
    }
    if ($failed === true) {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[PostDelete] Failed to delete all posts!', 0, 0, 0);
        }
    } else {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[PostDelete] Successfuly deleted ' . $number . ' posts!', 0, 0, 0);
        }
    }
}
add_action('wp_head', 'midas_add_ajaxurl');
add_action('wp_ajax_midas_my_action', 'midas_my_action_callback');
function midas_my_action_callback()
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    $failed       = false;
    $type         = $_POST['type'];
    $del_id       = $_POST['id'];
    $how          = $_POST['how'];
    $force_delete = true;
    $number = 0;
    if ($how == 'trash') {
        $force_delete = false;
    }
    $query     = array(
        'post_status' => array(
            'publish',
            'draft',
            'pending',
            'trash',
            'private'
        ),
        'post_type' => array(
            'any'
        ),
        'numberposts' => -1
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        $index       = get_post_meta($post->ID, 'post_parent_rule', true);
        $parent_type = get_post_meta($post->ID, 'post_parent_type', true);
        if ($index == $del_id && $parent_type == $type) {
            $args = array(
                'post_parent' => $post->ID
            );
            $post_attachments = get_children($args);
            if(isset($post_attachments) && !empty($post_attachments)) {
                foreach ($post_attachments as $attachment) {
                    wp_delete_attachment($attachment->ID, true);
                }
            }
            $res = wp_delete_post($post->ID, $force_delete);
            if ($res === false) {
                $failed = true;
            }
            else
            {
                $number++;
            }
        }
    }
    if ($failed === true) {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[PostDelete] Failed to delete all posts for rule id: ' . $del_id . '!', $del_id, $type, 0);
        }
        echo 'failed';
    } else {
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('[PostDelete] Successfuly deleted ' . $number . ' posts for rule id: ' . $del_id . ' of type ' . $type . '!', $del_id, $type, 0);
        }
        echo 'ok';
    }
    die();
}
add_action('wp_ajax_midas_run_my_action', 'midas_run_my_action_callback');
function midas_run_my_action_callback()
{
    $run_id = $_POST['id'];
    $type   = $_POST['type'];
    echo midas_run_rule($run_id, intval($type), 0);
    die();
}

function midas_get_xml_value($xml, $field)
{
    if (!empty($xml->childNodes)) {
        foreach ($xml->childNodes as $xmlChild) {
            if ($xmlChild->nodeName == $field) {
                return $xmlChild->nodeValue;
            }
        }
    }
    return '';
}
add_action('wp_head', 'midas_head');
function midas_head()
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
        if (isset($midas_Main_Settings['links_add_ref']) && $midas_Main_Settings['links_add_ref'] !== 'none') {
            if ($midas_Main_Settings['links_add_ref'] == 'all') {
                
                add_filter('comment_author_link', 'midas_add_affiliate_link');
                add_filter('comment_author_text', 'midas_add_affiliate_link');
                add_filter('comment_author_text_rss', 'midas_add_affiliate_link');
                add_filter('the_excerpt', 'midas_add_affiliate_link');
                add_filter('the_excerpt_rss', 'midas_add_affiliate_link');
                add_filter('the_content', 'midas_add_affiliate_link');
                add_filter('the_content_rss', 'midas_add_affiliate_link');
                add_filter('the_meta_key', 'midas_add_affiliate_link');
                
            } else if ($midas_Main_Settings['links_add_ref'] == 'meta') {
                
                add_filter('the_excerpt', 'midas_add_affiliate_link');
                add_filter('the_excerpt_rss', 'midas_add_affiliate_link');
                add_filter('the_content', 'midas_add_affiliate_link');
                add_filter('the_content_rss', 'midas_add_affiliate_link');
                add_filter('the_meta_key', 'midas_add_affiliate_link');
                
            } else if ($midas_Main_Settings['links_add_ref'] == 'post') {
                
                add_filter('the_content', 'midas_add_affiliate_link');
                add_filter('the_content_rss', 'midas_add_affiliate_link');
                add_filter('the_meta_key', 'midas_add_affiliate_link');
                
            }
        }
        add_filter('the_content', 'midas_add_affiliate_keyword');
    }
}

function midas_endswith($string, $test) {
    $strlen = strlen($string);
    $testlen = strlen($test);
    if ($testlen > $strlen) return false;
    return substr_compare($string, $test, $strlen - $testlen, $testlen) === 0;
}

function midas_add_affiliate_link($content)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['user_name']) && $midas_Main_Settings['user_name'] != '')
    {
        preg_match_all('/((http(s?):\/\/(www\.)?)|(www\.))(photodune|codecanyon|themeforest|audiojungle|videohive|graphicriver|3docean|marketplace\.tutsplus|market.envato|help.market.envato)\.([a-zA-Z0-9:\/=+_-]+)(\.[a-zA-Z0-9_\/=+_-]+)*(\?[a-zA-Z0-9\?.&#;:\/=+_-]+)?/i', $content, $matches);
        foreach (array_unique($matches[0]) as $key => $match) {
            if(strpos(strtolower($match), 'ref=' . strtolower($midas_Main_Settings['user_name'])) === FALSE)
            {
                $substring_found = false;
                foreach (array_unique($matches[0]) as $key2 => $match2) {
                    if(strpos($match2, $match) !== false && $match2 != $match)
                    {
                        $substring_found = true;
                    }
                }
                if($substring_found == false)
                {
                    if(!midas_endswith($match, ".png") && !midas_endswith($match, ".jpg") && !midas_endswith($match, ".jpe") && !midas_endswith($match, ".gif") && !midas_endswith($match, ".tif") && !midas_endswith($match, ".tiff") && !midas_endswith($match, ".x-icon") && !midas_endswith($match, ".svg") && !midas_endswith($match, ".ico") && !midas_endswith($match, ".icon"))
                    {
                        if(strpos($match, "?") === FALSE)
                        {
                            $new_url = $match . '?ref=' . $midas_Main_Settings['user_name'];
                        }
                        else
                        {
                            $new_url = substr($match, 0, strpos($match, "?")) . '?ref=' . $midas_Main_Settings['user_name'];
                        }
                        $content = str_replace($match, midas_url_handle($new_url), $content);  
                    }
                }
                else
                {
                    if(!midas_endswith($match, ".png") && !midas_endswith($match, ".jpg") && !midas_endswith($match, ".jpe") && !midas_endswith($match, ".gif") && !midas_endswith($match, ".tif") && !midas_endswith($match, ".tiff") && !midas_endswith($match, ".x-icon") && !midas_endswith($match, ".svg") && !midas_endswith($match, ".ico") && !midas_endswith($match, ".icon"))
                    {
                        $content = preg_replace('/http(s?):\/\/(www.)?(photodune|codecanyon|themeforest|audiojungle|videohive|graphicriver|3docean|marketplace\.tutsplus)\.net\/?[^<\'"\n >]*/i', '$0?ref=' . $midas_Main_Settings['user_name'], $content);
                        $content = str_replace('?ref=' . $midas_Main_Settings['user_name'] . '?ref=' . $midas_Main_Settings['user_name'], '?ref=' . $midas_Main_Settings['user_name'], $content); 
                        break;
                    }
                }
            }            
        }
    }
    return $content;
}
function midas_add_affiliate_keyword($content)
{
    $rules  = get_option('midas_keyword_list');
    $output = '';
    if (!empty($rules)) {
        foreach ($rules as $request => $value) {
            $content = preg_replace('\'(?!((<.*?)|(<a.*?)))(\b' . $request . '\b)(?!(([^<>]*?)>)|([^>]*?</a>))\'i', '<a href="' . $value . '" target="_blank">' . $request . '</a>', $content);
        }
    }
    return $content;
}

function midas_clearFromList($param, $type)
{
    $running = get_option('midas_running_list');
    $key = array_search(array(
        $param => $type
    ), $running);
    if ($key !== FALSE) {
        unset($running[$key]);
        update_option('midas_running_list', $running);
    }
    else
    {
        midas_log_to_file ('[RunningList][ERROR] Failed to delete key from running list: ' . $param . ' -> ' . $type , $param, $type, 1);
    }
}

function midas_clearFromAutoList($param, $type)
{
    $running = get_option('midas_auto_running_list');
    $key = array_search(array(
        $param => $type
    ), $running);
    if ($key !== FALSE) {
        unset($running[$key]);
        update_option('midas_auto_running_list', $running);
    }
    else
    {
        midas_log_to_file ('[RunningList][ERROR] Failed to delete key from running list: ' . $param . ' -> ' . $type , $param, $type, 1);
    }
}

function midas_url_handle($href)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    $envatocash_google_key = get_option('envatocash-google-key');
    if (isset($midas_Main_Settings['links_hide']) && $midas_Main_Settings['links_hide'] == 'on') {
        $cloak_urls = true;
    } else {
        $cloak_urls = false;
    }
    if (isset($midas_Main_Settings['apiKey'])) {
        $apiKey = $midas_Main_Settings['apiKey'];
    } else {
        $apiKey = '';
    }
    if ($cloak_urls == true && $apiKey != '') {
        $longUrl  = trim($href);
        $postData = array(
            'longUrl' => $longUrl,
            'key' => $apiKey
        );
        $jsonData = json_encode($postData);
        if($jsonData === FALSE)
        {
            return $href;
        }
        $curlObj  = curl_init();
        if($curlObj === FALSE)
        {
            return $href;
        }
        curl_setopt($curlObj, CURLOPT_TIMEOUT_MS, 6000000); //in miliseconds
        curl_setopt($curlObj, CURLOPT_URL, 'https://www.googleapis.com/urlshortener/v1/url?key=' . $apiKey);
        curl_setopt($curlObj, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curlObj, CURLOPT_HEADER, 0);
        curl_setopt($curlObj, CURLOPT_HTTPHEADER, array(
            'Content-type:application/json'
        ));
        curl_setopt($curlObj, CURLOPT_POST, 1);
        curl_setopt($curlObj, CURLOPT_POSTFIELDS, $jsonData);
        $response = curl_exec($curlObj);
        if($response === FALSE)
        {
            curl_close($curlObj);
            return $href;
        }
        $json = json_decode($response);
        curl_close($curlObj);
        if (!isset($json->id) || $json->id == '') {
            return $href;
        } else {
            return $json->id;
        }
    } else {
        return $href;
    }
}
function midas_run_rule($param, $type = 0, $auto = 1)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['rule_timeout']) && $midas_Main_Settings['rule_timeout'] != '')
    {
        $timeout = intval($midas_Main_Settings['rule_timeout']);
    }
    else
    {
        $timeout = 3600;
    }
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', $timeout);
    @ini_set('ignore_user_abort', 1);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    ignore_user_abort(true);
    set_time_limit($timeout);
    $posts_inserted = 0;
    $auto_generate_comments = '0';
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
        try {
            $update_needed = '-1';
            $item_img     = '';
            $cont         = 0;
            $found        = 0;
            $user_name    = '';
            $marketplace  = '';
            $ids          = '';
            $schedule     = '';
            $max          = PHP_INT_MAX;
            $active       = '0';
            $last_run     = '';
            $ruleType     = 'week';
            $first        = false;
            $others       = array();
            $post_title   = '';
            $post_content = '';
            $list_item    = '';
            if (!get_option('midas_running_list')) {
                $running = array();
            } else {
                $running = get_option('midas_running_list');
            }
            if (!empty($running)) {
                if (in_array(array(
                    $param => $type
                ), $running)) {
                    midas_log_to_file ('Only one instance of this rule is allowed. Rule is already running!', $param, $type, $auto);
                    return 'fail';
                }
            }
            $running[] = array(
                $param => $type
            );
            update_option('midas_running_list', $running);
            if (isset($midas_Main_Settings['user_name'])) {
                $envato_username = $midas_Main_Settings['user_name'];
            } else {
                $envato_username = '';
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['submit_status'])) {
                    $post_status = $midas_Main_Settings['submit_status'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['submit_status_user'])) {
                    $post_status = $midas_Main_Settings['submit_status_user'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['submit_status_popular'])) {
                    $post_status = $midas_Main_Settings['submit_status_popular'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['submit_status_random'])) {
                    $post_status = $midas_Main_Settings['submit_status_random'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['submit_status_featured'])) {
                    $post_status = $midas_Main_Settings['submit_status_featured'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['submit_status_manual'])) {
                    $post_status = $midas_Main_Settings['submit_status_manual'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['submit_status_grouped'])) {
                    $post_status = $midas_Main_Settings['submit_status_grouped'];
                } else {
                    $post_status = 'publish';
                }
            } else {
                if (isset($midas_Main_Settings['submit_status'])) {
                    $post_status = $midas_Main_Settings['submit_status'];
                } else {
                    $post_status = 'publish';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['default_type'])) {
                    $post_type = $midas_Main_Settings['default_type'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['default_type_user'])) {
                    $post_type = $midas_Main_Settings['default_type_user'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['default_type_popular'])) {
                    $post_type = $midas_Main_Settings['default_type_popular'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['default_type_random'])) {
                    $post_type = $midas_Main_Settings['default_type_random'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['default_type_featured'])) {
                    $post_type = $midas_Main_Settings['default_type_featured'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['default_type_manual'])) {
                    $post_type = $midas_Main_Settings['default_type_manual'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['default_type_grouped'])) {
                    $post_type = $midas_Main_Settings['default_type_grouped'];
                } else {
                    $post_type = 'post';
                }
            } else {
                if (isset($midas_Main_Settings['default_type'])) {
                    $post_type = $midas_Main_Settings['default_type'];
                } else {
                    $post_type = 'post';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['enable_comments']) && $midas_Main_Settings['enable_comments'] == 'on') {
                    $accept_comments = 'open';
                    if (isset($midas_Main_Settings['auto_generate_comments'])) {
                        $auto_generate_comments = $midas_Main_Settings['auto_generate_comments'];
                    }
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['enable_comments_user']) && $midas_Main_Settings['enable_comments_user'] == 'on') {
                    $accept_comments = 'open';
                    if (isset($midas_Main_Settings['auto_generate_comments_user'])) {
                        $auto_generate_comments = $midas_Main_Settings['auto_generate_comments_user'];
                    }
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['enable_comments_popular']) && $midas_Main_Settings['enable_comments_popular'] == 'on') {
                    $accept_comments = 'open';
                    if (isset($midas_Main_Settings['auto_generate_comments_popular'])) {
                        $auto_generate_comments = $midas_Main_Settings['auto_generate_comments_popular'];
                    }
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['enable_comments_random']) && $midas_Main_Settings['enable_comments_random'] == 'on') {
                    $accept_comments = 'open';
                    if (isset($midas_Main_Settings['auto_generate_comments_random'])) {
                        $auto_generate_comments = $midas_Main_Settings['auto_generate_comments_random'];
                    }
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['enable_comments_featured']) && $midas_Main_Settings['enable_comments_featured'] == 'on') {
                    $accept_comments = 'open';
                    if (isset($midas_Main_Settings['auto_generate_comments_featured'])) {
                        $auto_generate_comments = $midas_Main_Settings['auto_generate_comments_featured'];
                    }
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['enable_comments_manual']) && $midas_Main_Settings['enable_comments_manual'] == 'on') {
                    $accept_comments = 'open';
                    if (isset($midas_Main_Settings['auto_generate_comments_manual'])) {
                        $auto_generate_comments = $midas_Main_Settings['auto_generate_comments_manual'];
                    }
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['enable_comments_grouped']) && $midas_Main_Settings['enable_comments_grouped'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } else {
                if (isset($midas_Main_Settings['enable_comments']) && $midas_Main_Settings['enable_comments'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['post_user_name'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['post_user_name_user'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_user'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['post_user_name_popular'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_popular'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['post_user_name_random'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_random'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['post_user_name_featured'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_featured'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['post_user_name_manual'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_manual'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['post_user_name_grouped'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_grouped'];
                } else {
                    $post_user_name = 1;
                }
            } else {
                if (isset($midas_Main_Settings['post_user_name'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name'];
                } else {
                    $post_user_name = 1;
                }
            }
            
            if ($type == 0) {
                if (isset($midas_Main_Settings['auto_categories'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['auto_categories_user'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_user'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['auto_categories_popular'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_popular'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['auto_categories_random'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_random'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['auto_categories_featured'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_featured'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['auto_categories_manual'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_manual'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['auto_categories_grouped'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_grouped'];
                } else {
                    $can_create_cat = 'off';
                }
            } else {
                if (isset($midas_Main_Settings['auto_categories'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories'];
                } else {
                    $can_create_cat = 'off';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['default_tags'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['default_tags_user'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_user'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['default_tags_popular'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_popular'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['default_tags_random'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_random'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['default_tags_featured'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_featured'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['default_tags_manual'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_manual'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['default_tags_grouped'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_grouped'];
                } else {
                    $item_create_tag = '';
                }
            } else {
                if (isset($midas_Main_Settings['default_tags'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags'];
                } else {
                    $item_create_tag = '';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['auto_image'])) {
                    $auto_image = $midas_Main_Settings['auto_image'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['auto_image_user'])) {
                    $auto_image = $midas_Main_Settings['auto_image_user'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['auto_image_popular'])) {
                    $auto_image = $midas_Main_Settings['auto_image_popular'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['auto_image_random'])) {
                    $auto_image = $midas_Main_Settings['auto_image_random'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['auto_image_featured'])) {
                    $auto_image = $midas_Main_Settings['auto_image_featured'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['auto_image_manual'])) {
                    $auto_image = $midas_Main_Settings['auto_image_manual'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['auto_image_grouped'])) {
                    $auto_image = $midas_Main_Settings['auto_image_grouped'];
                } else {
                    $auto_image = '';
                }
            } else {
                if (isset($midas_Main_Settings['auto_image'])) {
                    $auto_image = $midas_Main_Settings['auto_image'];
                } else {
                    $auto_image = '';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['auto_tags'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['auto_tags_user'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_user'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['auto_tags_popular'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_popular'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['auto_tags_random'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_random'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['auto_tags_featured'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_featured'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['auto_tags_manual'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_manual'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['auto_tags_grouped'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_grouped'];
                } else {
                    $can_create_tag = 'off';
                }
            } else {
                if (isset($midas_Main_Settings['auto_tags'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags'];
                } else {
                    $can_create_tag = 'off';
                }
            }
            if ($type == 0) {
                if (!get_option('midas_rules_list')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = isset($array_my_values[0]) ? $array_my_values[0] : '';
                            $schedule        = isset($array_my_values[1]) ? $array_my_values[1] : '';
                            $max             = isset($array_my_values[2]) ? $array_my_values[2] : '';
                            $active          = isset($array_my_values[3]) ? $array_my_values[3] : '';
                            $last_run        = isset($array_my_values[4]) ? $array_my_values[4] : '';
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No rules found for midas_rules_list!', $param, $type, $auto);
                    return 'fail';
                }
                if ($found == 0) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ($param . ' not found in midas_rules_list!', $param, $type, $auto);
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list', $rules);
                }
                $feed_uri = $marketplace;
            } elseif ($type == 1) {
                if (!get_option('midas_user_rules_list')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_user_rules_list');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $user_name       = isset($array_my_values[0]) ? $array_my_values[0] : '';
                            $marketplace     = isset($array_my_values[1]) ? $array_my_values[1] : '';
                            $schedule        = isset($array_my_values[2]) ? $array_my_values[2] : '';
                            $max             = isset($array_my_values[3]) ? $array_my_values[3] : '';
                            $active          = isset($array_my_values[4]) ? $array_my_values[4] : '';
                            $last_run        = isset($array_my_values[5]) ? $array_my_values[5] : '';
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No rules found for midas_user_rules_list!', $param, $type, $auto);
                    return 'fail';
                }
                if ($found == 0) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ($param . ' not found in midas_user_rules_list!', $param, $type, $auto);
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $user_name;
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_user_rules_list', $rules);
                }
                $feed_uri = 'https://' . $marketplace . '.net/feeds/users/' . $user_name . '.atom';
            } elseif ($type == 2) {
                if (!get_option('midas_rules_list_popular')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_popular');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = isset($array_my_values[0]) ? $array_my_values[0] : '';
                            $schedule        = isset($array_my_values[1]) ? $array_my_values[1] : '';
                            $max             = isset($array_my_values[2]) ? $array_my_values[2] : '';
                            $active          = isset($array_my_values[3]) ? $array_my_values[3] : '';
                            $last_run        = isset($array_my_values[4]) ? $array_my_values[4] : '';
                            $ruleType        = isset($array_my_values[5]) ? $array_my_values[5] : '';
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No rules found for midas_rules_list_popular!', $param, $type, $auto);
                    return 'fail';
                }
                if ($found == 0) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ($param . ' not found in midas_rules_list_popular!', $param, $type, $auto);
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $new_bundle[]  = $ruleType;
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_popular', $rules);
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/popular:' . $marketplace . '.json';
            } elseif ($type == 3) {
                if (!get_option('midas_rules_list_random')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_random');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = isset($array_my_values[0]) ? $array_my_values[0] : '';
                            $schedule        = isset($array_my_values[1]) ? $array_my_values[1] : '';
                            $max             = isset($array_my_values[2]) ? $array_my_values[2] : '';
                            $active          = isset($array_my_values[3]) ? $array_my_values[3] : '';
                            $last_run        = isset($array_my_values[4]) ? $array_my_values[4] : '';
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No rules found for midas_rules_list_random!', $param, $type, $auto);
                    return 'fail';
                }
                if ($found == 0) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ($param . ' not found in midas_rules_list_random!', $param, $type, $auto);
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_random', $rules);
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/random-new-files:' . $marketplace . '.json';
            } elseif ($type == 4) {
                if (!get_option('midas_rules_list_featured')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_featured');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = isset($array_my_values[0]) ? $array_my_values[0] : '';
                            $schedule        = isset($array_my_values[1]) ? $array_my_values[1] : '';
                            $max             = isset($array_my_values[2]) ? $array_my_values[2] : '';
                            $active          = isset($array_my_values[3]) ? $array_my_values[3] : '';
                            $last_run        = isset($array_my_values[4]) ? $array_my_values[4] : '';
                            $ruleType        = isset($array_my_values[5]) ? $array_my_values[5] : '';
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No rules found for midas_rules_list_featured!', $param, $type, $auto);
                    return 'fail';
                }
                if ($found == 0) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ($param . ' not found in midas_rules_list_featured!', $param, $type, $auto);
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $new_bundle[]  = $ruleType;
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_featured', $rules);
                }
                $feed_uri = 'https://marketplace.envato.com/api/edge/features:' . $marketplace . '.json';
            } elseif ($type == 5) {
                if (!get_option('midas_rules_list_manual')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_manual');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $ids             = isset($array_my_values[0]) ? $array_my_values[0] : '';
                            $schedule        = isset($array_my_values[1]) ? $array_my_values[1] : '';
                            $active          = isset($array_my_values[2]) ? $array_my_values[2] : '';
                            $last_run        = isset($array_my_values[3]) ? $array_my_values[3] : '';
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No rules found for midas_rules_list_manual!', $param, $type, $auto);
                    return 'fail';
                }
                if ($found == 0) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ($param . ' not found in midas_rules_list_manual!', $param, $type, $auto);
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $ids;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_manual', $rules);
                }
                $arr_ids = explode(",", $ids);
                foreach ($arr_ids as $one_id) {
                    if ($first === false) {
                        $first = trim($one_id);
                    } else {
                        $others[] = trim($one_id);
                    }
                }
                if ($first === false) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No first rule found in midas_rules_list_manual!', $param, $type, $auto);
                    return 'fail';
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $first . '.json';
                $max      = PHP_INT_MAX;
            } elseif ($type == 6) {
                if (!get_option('midas_rules_list_group')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_group');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $ids             = isset($array_my_values[0]) ? $array_my_values[0] : '';
                            $post_title      = isset($array_my_values[1]) ? $array_my_values[1] : '';
                            $post_content    = isset($array_my_values[2]) ? $array_my_values[2] : '';
                            $list_item       = isset($array_my_values[3]) ? $array_my_values[3] : '';
                            $last_run        = isset($array_my_values[4]) ? $array_my_values[4] : '';
                            $active          = '1';
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No rules found for midas_rules_list_group!', $param, $type, $auto);
                    return 'fail';
                }
                if ($found == 0) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ($param . ' not found in midas_rules_list_group!', $param, $type, $auto);
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $ids;
                    $new_bundle[]  = $post_title;
                    $new_bundle[]  = $post_content;
                    $new_bundle[]  = $list_item;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_group', $rules);
                }
                $arr_ids = explode(",", $ids);
                foreach ($arr_ids as $one_id) {
                    if ($first === false) {
                        $first = trim($one_id);
                    } else {
                        $others[] = trim($one_id);
                    }
                }
                if ($first === false) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('No first rule found in midas_rules_list_group!', $param, $type, $auto);
                    return 'fail';
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $first . '.json';
                $max      = PHP_INT_MAX;
            } else {
                midas_clearFromList($param, $type);
                midas_log_to_file ('Unknown rule type ' . $type . '!', $param, $type, $auto);
                return 'fail';
            }
            $newItems = file_get_contents($feed_uri);
            if ($newItems === false) {
                midas_clearFromList($param, $type);
                if($type == 1)
                {
                    midas_log_to_file ('Inexistent user name entered: ' . $user_name . '!', $param, $type, $auto);
                }
                else
                {
                    midas_log_to_file ('Failed to fetch feed_uri: ' . $feed_uri . '!', $param, $type, $auto);
                }
                return 'fail';
            }
            $post_array   = array();
            $posted_items = array();
            $query        = array(
                'post_status' => array(
                    'publish',
                    'draft',
                    'pending',
                    'trash',
                    'private'
                ),
                'post_type' => array(
                    'any'
                ),
                'numberposts' => -1
            );
            $post_list = get_posts($query);
            foreach ($post_list as $post) {
                $posted_items[] = get_post_meta($post->ID, 'post_item_id', true);
            }
            $counter = 1;
            if ($type == 0 || $type == 1) {
                $content_xml = new DOMDocument();
                if (!$content_xml->loadXML($newItems)) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('loadXML failed for ' . $feed_uri . '!', $param, $type, $auto);
                    return 'fail';
                }
                foreach ($content_xml->documentElement->childNodes as $item_xml) {
                    if ($counter <= (int) $max) {
                        $title = midas_get_xml_value($item_xml, 'title');
                        if ($title && $title != '') {
                            $content = midas_get_xml_value($item_xml, 'content');
                            $id_text = midas_get_xml_value($item_xml, 'id');
                            $id      = trim(str_replace(':Item/', '', substr($id_text, strpos($id_text, ':Item/'))));
                            $found   = 0;
                            if (in_array($id, $posted_items)) {
                                $found = 1;
                            }
                            if ($found == 0) {
                                $item_info = file_get_contents("https://marketplace.envato.com/api/v3/item:" . $id . ".json");
                                if ($item_info === false) {
                                    if(isset($midas_Main_Settings['enable_detailed_logging']))
                                    {
                                        midas_log_to_file ('file_get_contents failed for ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                                    }
                                    continue;
                                }
                                $json = json_decode($item_info, true);
                                if ($json === NULL) {
                                    if(isset($midas_Main_Settings['enable_detailed_logging']))
                                    {
                                        midas_log_to_file ('json_decode failed for ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                                    }
                                    continue;
                                }
                                if (!isset($json['item'])) {
                                    if(isset($midas_Main_Settings['enable_detailed_logging']))
                                    {
                                        midas_log_to_file ('json["item"] not set for ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                                    }
                                    continue;
                                }
                                $item_media = '';
                                if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                    $item_media = isset($json['item']['preview_url']) ? $json['item']['preview_url'] : '';
                                }
                                if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                    $item_media = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                }
                                $item_img                  = isset($json['item']['live_preview_url']) ? $json['item']['live_preview_url'] : '';
                                $item_video                = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                $item_thumb                = isset($json['item']['live_preview_url']) ? $json['item']['live_preview_url'] : '';
                                $item_url                  = isset($json['item']['url']) ? $json['item']['url'] : '';
                                $item_user                 = isset($json['item']['user']) ? $json['item']['user'] : '';
                                $item_cost                 = isset($json['item']['cost']) ? $json['item']['cost'] : '';
                                $item_cat                  = isset($json['item']['category']) ? $json['item']['category'] : '';
                                $item_tags                 = isset($json['item']['tags']) ? $json['item']['tags'] : '';
                                $item_uploaded             = isset($json['item']['uploaded_on']) ? $json['item']['uploaded_on'] : '';
                                $item_last_update          = isset($json['item']['last_update']) ? $json['item']['last_update'] : '';
                                $just_title                = isset($json['item']['item']) ? $json['item']['item'] : '';
                                $item_sales                = isset($json['item']['sales']) ? $json['item']['sales'] : '';
                                $item_rating               = isset($json['item']['rating']) ? $json['item']['rating'] : '';
                                $my_post                   = array();
                                $my_post['post_type']      = $post_type;
                                $my_post['comment_status'] = $accept_comments;
                                $my_post['post_status']    = $post_status;
                                $my_post['post_author']    = $post_user_name;
                                if ($can_create_tag == 'on') {
                                    $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                } else if ($item_create_tag != '') {
                                    $my_post['tags_input'] = $item_create_tag;
                                }
                                $my_post['post_item_id']             = $id;
                                $my_post['post_item_marketplace']    = $marketplace;
                                $my_post['post_item_user']           = $item_user;
                                $my_post['post_item_url']            = $item_url;
                                $my_post['post_item_thumbnail']      = $item_thumb;
                                $my_post['post_item_preview_img']    = $item_img;
                                $my_post['post_item_media_url']      = $item_media;
                                $my_post['post_item_cost']           = $item_cost;
                                $my_post['post_item_uploaded']       = $item_uploaded;
                                $my_post['post_item_cats']           = $item_cat;
                                $my_post['post_item_tags']           = $item_tags;
                                $my_post['market_item_last_updated'] = $item_last_update;
                                if ($type == 0) {
                                    $the_content = $midas_Main_Settings['post_content'];
                                } elseif ($type == 1) {
                                    $the_content = $midas_Main_Settings['post_content_user'];
                                } elseif ($type == 2) {
                                    $the_content = $midas_Main_Settings['post_content_popular'];
                                } elseif ($type == 3) {
                                    $the_content = $midas_Main_Settings['post_content_random'];
                                } elseif ($type == 4) {
                                    $the_content = $midas_Main_Settings['post_content_featured'];
                                } elseif ($type == 5) {
                                    $the_content = $midas_Main_Settings['post_content_manual'];
                                } else{
                                    $the_content = '';
                                }
                                if (strpos($the_content, '%%') !== false) {
                                    $the_content = midas_replaceContentShortcodes($the_content, $json['item'], $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                if (strpos($the_content, 'images/smileys/') !== false) {
                                    $the_content = midas_replaceContentSmileys($the_content);
                                }
                                $my_post['post_content'] = $the_content;
                                $my_post['post_excerpt']   = midas_getExcerpt($content);
                                if ($type == 0) {
                                    $the_title = $midas_Main_Settings['post_title'];
                                } elseif ($type == 1) {
                                    $the_title = $midas_Main_Settings['post_title_user'];
                                } elseif ($type == 2) {
                                    $the_title = $midas_Main_Settings['post_title_popular'];
                                } elseif ($type == 3) {
                                    $the_title = $midas_Main_Settings['post_title_random'];
                                } elseif ($type == 4) {
                                    $the_title = $midas_Main_Settings['post_title_featured'];
                                } elseif ($type == 5) {
                                    $the_title = $midas_Main_Settings['post_title_manual'];
                                } else {
                                    $the_title = '';
                                }
                                if (strpos($the_title, '%%') !== false) {
                                    $the_title = midas_replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                $my_post['post_title'] = $the_title;
                                $post_array[]          = $my_post;
                            } else {
                                $item_info = file_get_contents("https://marketplace.envato.com/api/v3/item:" . $id . ".json");
                                if ($item_info === false) {
                                    if(isset($midas_Main_Settings['enable_detailed_logging']))
                                    {
                                        midas_log_to_file ('file_get_contents failed for ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                                    }
                                    continue;
                                }
                                $json = json_decode($item_info, true);
                                if ($json === NULL) {
                                    if(isset($midas_Main_Settings['enable_detailed_logging']))
                                    {
                                        midas_log_to_file ('json_decode failed for ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                                    }
                                    continue;
                                }
                                if (!isset($json['item'])) {
                                    if(isset($midas_Main_Settings['enable_detailed_logging']))
                                    {
                                        midas_log_to_file ('json["item"] not set for ' . "https://marketplace.envato.com/api/v3/item:" . $id . ".json" . '!', $param, $type, $auto);
                                    }
                                    continue;
                                }
                                $item_last_update = isset($json['item']['last_update']) ? $json['item']['last_update'] : '';
                                foreach ($post_list as $post) {
                                    $item_id = get_post_meta($post->ID, 'post_item_id', true);
                                    if ($item_id == $id) {
                                        $item_in_post_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
                                        if ($item_in_post_updated != $item_last_update && $item_last_update != '') {
                                            $item_media = '';
                                            if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                                $item_media = isset($json['item']['preview_url']) ? $json['item']['preview_url'] : '';
                                            }
                                            if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                                $item_media = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                            }
                                            $item_img                  = isset($json['item']['live_preview_url']) ? $json['item']['live_preview_url'] : '';
                                            $item_video                = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                            $item_thumb                = isset($json['item']['thumbnail']) ? $json['item']['thumbnail'] : '';
                                            $item_url                  = isset($json['item']['url']) ? $json['item']['url'] : '';
                                            $item_user                 = isset($json['item']['user']) ? $json['item']['user'] : '';
                                            $item_cost                 = isset($json['item']['cost']) ? $json['item']['cost'] : '';
                                            $item_cat                  = isset($json['item']['category']) ? $json['item']['category'] : '';
                                            $item_tags                 = isset($json['item']['tags']) ? $json['item']['tags'] : '';
                                            $item_uploaded             = isset($json['item']['uploaded_on']) ? $json['item']['uploaded_on'] : '';
                                            $just_title                = isset($json['item']['item']) ? $json['item']['item'] : '';
                                            $item_sales                = isset($json['item']['sales']) ? $json['item']['sales'] : '';
                                            $item_rating               = isset($json['item']['rating']) ? $json['item']['rating'] : '';
                                            $my_post                   = array();
                                            $my_post['ID']             = $post->ID;
                                            $my_post['post_type']      = $post_type;
                                            $my_post['comment_status'] = $accept_comments;
                                            $my_post['post_status']    = $post_status;
                                            $my_post['post_author']    = $post_user_name;
                                            if ($can_create_tag == 'on') {
                                                $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                            } else if ($item_create_tag != '') {
                                                $my_post['tags_input'] = $item_create_tag;
                                            }
                                            $my_post['post_item_id']             = $id;
                                            $my_post['post_item_marketplace']    = $marketplace;
                                            $my_post['post_item_user']           = $item_user;
                                            $my_post['post_item_url']            = $item_url;
                                            $my_post['post_item_thumbnail']      = $item_thumb;
                                            $my_post['post_item_preview_img']    = $item_img;
                                            $my_post['post_item_media_url']      = $item_media;
                                            $my_post['post_item_cost']           = $item_cost;
                                            $my_post['post_item_uploaded']       = $item_uploaded;
                                            $my_post['post_item_cats']           = $item_cat;
                                            $my_post['post_item_tags']           = $item_tags;
                                            $my_post['market_item_last_updated'] = $item_last_update;
                                            if ($type == 0) {
                                                $the_content = $midas_Main_Settings['post_content'];
                                            } elseif ($type == 1) {
                                                $the_content = $midas_Main_Settings['post_content_user'];
                                            } elseif ($type == 2) {
                                                $the_content = $midas_Main_Settings['post_content_popular'];
                                            } elseif ($type == 3) {
                                                $the_content = $midas_Main_Settings['post_content_random'];
                                            } elseif ($type == 4) {
                                                $the_content = $midas_Main_Settings['post_content_featured'];
                                            } elseif ($type == 5) {
                                                $the_content = $midas_Main_Settings['post_content_manual'];
                                            } else{
                                                $the_content = '';
                                            }
                                            if (strpos($the_content, '%%') !== false) {
                                                $the_content = midas_replaceContentShortcodes($the_content, $json['item'], $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            if (strpos($the_content, 'images/smileys/') !== false) {
                                                $the_content = midas_replaceContentSmileys($the_content);
                                            }
                                            $my_post['post_content'] = $the_content;
                                            $my_post['post_excerpt']   = midas_getExcerpt($content);
                                            if ($type == 0) {
                                                $the_title = $midas_Main_Settings['post_title'];
                                            } elseif ($type == 1) {
                                                $the_title = $midas_Main_Settings['post_title_user'];
                                            } elseif ($type == 2) {
                                                $the_title = $midas_Main_Settings['post_title_popular'];
                                            }  elseif ($type == 3) {
                                                $the_title = $midas_Main_Settings['post_title_random'];
                                            } elseif ($type == 4) {
                                                $the_title = $midas_Main_Settings['post_title_featured'];
                                            } elseif ($type == 5) {
                                                $the_title = $midas_Main_Settings['post_title_manual'];
                                            } else {
                                                $the_title = '';
                                            }
                                            if (strpos($the_title, '%%') !== false) {
                                                $the_title = midas_replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            $my_post['post_title'] = $the_title;
                                            $post_id               = wp_update_post($my_post);
                                            if ($post_id != 0) {
                                                $image_failed = false;
                                                if ($auto_image === 'on') {
                                                    if ($my_post['post_item_preview_img'] != '') {
                                                        if(!midas_generate_featured_image($my_post['post_item_preview_img'], $post_id))
                                                        {
                                                            $image_failed = true;
                                                            midas_log_to_file ('midas_generate_featured_image failed!', $param, $type, $auto);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $image_failed = true;
                                                    }
                                                }
                                                if($image_failed || $auto_image !== 'on' || $type == 6)
                                                {
                                                    $image_url = '';
                                                    if($type == 0 && isset($midas_Main_Settings['featured_image_default']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_default'];
                                                    }
                                                    elseif($type == 1 && isset($midas_Main_Settings['featured_image_user']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_user'];
                                                    }
                                                    elseif($type == 2 && isset($midas_Main_Settings['featured_image_popular']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_popular'];
                                                    }
                                                    elseif($type == 3 && isset($midas_Main_Settings['featured_image_random']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_random'];
                                                    }
                                                    elseif($type == 4 && isset($midas_Main_Settings['featured_image_featured']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_featured'];
                                                    }
                                                    elseif($type == 5 && isset($midas_Main_Settings['featured_image_manual']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_manual'];
                                                    }
                                                    elseif($type == 6 && isset($midas_Main_Settings['featured_image_grouped']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_grouped'];
                                                    }
                                                    if($image_url != '')
                                                    {
                                                        $url_headers=get_headers($image_url, 1);
                                                        if(isset($url_headers['Content-Type'])){
                                                            $img_type=strtolower($url_headers['Content-Type']);
                                                            $valid_image_type=array();
                                                            $valid_image_type['image/png']='';
                                                            $valid_image_type['image/jpg']='';
                                                            $valid_image_type['image/jpeg']='';
                                                            $valid_image_type['image/jpe']='';
                                                            $valid_image_type['image/gif']='';
                                                            $valid_image_type['image/tif']='';
                                                            $valid_image_type['image/tiff']='';
                                                            $valid_image_type['image/svg']='';
                                                            $valid_image_type['image/ico']='';
                                                            $valid_image_type['image/icon']='';
                                                            $valid_image_type['image/x-icon']='';
                                                            if(isset($valid_image_type[$img_type])){
                                                                if(!midas_generate_featured_image($image_url, $post_id))
                                                                {
                                                                    $image_failed = true;
                                                                    midas_log_to_file ('midas_generate_featured_image failed to deafault value: '. $image_url . '!', $param, $type, $auto);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                midas_updatePostMeta($post_id, $my_post, $param, $type, $envato_username);
                                                
                                                if ($can_create_cat == 'on') {
                                                    $termid = midas_create_terms('category', '0', $my_post['post_item_cats']);
                                                    wp_set_post_terms($post_id, $termid, 'category');
                                                }
                                                if ($type == 0) {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 1) {
                                                    if (isset($midas_Main_Settings['default_category_user']) && $midas_Main_Settings['default_category_user'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_user'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 2) {
                                                    if (isset($midas_Main_Settings['default_category_popular']) && $midas_Main_Settings['default_category_popular'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_popular'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 3) {
                                                    if (isset($midas_Main_Settings['default_category_random']) && $midas_Main_Settings['default_category_random'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_random'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 4) {
                                                    if (isset($midas_Main_Settings['default_category_featured']) && $midas_Main_Settings['default_category_featured'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_featured'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 5) {
                                                    if (isset($midas_Main_Settings['default_category_manual']) && $midas_Main_Settings['default_category_manual'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_manual'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 6) {
                                                    if (isset($midas_Main_Settings['default_category_grouped']) && $midas_Main_Settings['default_category_grouped'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_grouped'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } else {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                                            {
                                                midas_log_to_file ("Skipping '" .$json['item']['item'] . "'(" . $json['item']['id'] . ") because item already has an updated post generated (Last update: " . $item_last_update . ") (postId: " . $post->ID . ")!", $param, $type, $auto);
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            $counter++;
                        }
                    }
                }
            } else {
                $feed_json = json_decode($newItems, true);
                if ($feed_json === NULL) {
                    midas_clearFromList($param, $type);
                    midas_log_to_file ('json_decode failed for ' . $feed_uri . '!', $param, $type, $auto);
                    return 'fail';
                }
                if ($type == 2) {
                    if (!isset($feed_json['popular'])) {
                        midas_clearFromList($param, $type);
                        midas_log_to_file ('feed_json["popular"] not set for ' . $feed_uri . '!', $param, $type, $auto);
                        return 'fail';
                    }
                    $new_json = $feed_json['popular'];
                    if ($ruleType == 'week') {
                        $interest_json = $new_json['items_last_week'];
                    } else {
                        $interest_json = $new_json['items_last_three_months'];
                    }
                } elseif ($type == 3) {
                    $interest_json = array();
                    if (!isset($feed_json['random-new-files'])) {
                        midas_clearFromList($param, $type);
                        midas_log_to_file ('feed_json["random-new-files"] not set for ' . $feed_uri . '!', $param, $type, $auto);
                        return 'fail';
                    }
                    $new_json      = $feed_json['random-new-files'];
                    foreach ($new_json as $key => $item) {
                        $item_info = file_get_contents("https://marketplace.envato.com/api/v3/item:" . $item['id'] . ".json");
                        if ($item_info === false) {
                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                            {
                                midas_log_to_file ("file_get_contents failed for" ."https://marketplace.envato.com/api/v3/item:" . $item['id'] . ".json", $param, $type, $auto);
                            }
                            continue;
                        }
                        $json = json_decode($item_info, true);
                        if ($json === NULL) {
                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                            {
                                midas_log_to_file ("json_decode failed for" ."https://marketplace.envato.com/api/v3/item:" . $item['id'] . ".json", $param, $type, $auto);
                            }
                            continue;
                        }
                        if (!isset($json['item'])) {
                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                            {
                                midas_log_to_file ("json[item] not set for https://marketplace.envato.com/api/v3/item:" . $item['id'] . ".json", $param, $type, $auto);
                            }
                            continue;
                        }
                        $interest_json[] = $json['item'];
                    }
                } elseif ($type == 4) {
                    $interest_json = array();
                    if (!isset($feed_json['features'])) {
                        midas_clearFromList($param, $type);
                        midas_log_to_file ('feed_json["features"] not set for ' . $feed_uri . '!', $param, $type, $auto);
                        return 'fail';
                    }
                    if ($ruleType == 'featured') {
                        $interest_json[] = $feed_json['features']['featured_file'];
                    } else {
                        $interest_json[] = $feed_json['features']['free_file'];
                    }
                } elseif ($type == 5) {
                    $rule_pids     = array();
                    $interest_json = array();
                    if (!isset($feed_json['item'])) {
                        midas_clearFromList($param, $type);
                        midas_log_to_file ('feed_json["item"] not set for ' . $feed_uri . '!', $param, $type, $auto);
                        return 'fail';
                    }
                    if (isset($feed_json['item']['id'])) {
                        $interest_json[] = $feed_json['item'];
                        $rule_pids[]     = $feed_json['item']['id'];
                    }
                    foreach ($others as $other) {
                        if ($other != '') {
                            $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $other . '.json';
                            $newItems = file_get_contents($feed_uri);
                            if ($newItems === false) {
                                if(isset($midas_Main_Settings['enable_detailed_logging']))
                                {
                                    midas_log_to_file ("file_get_contents failed for" .$feed_uri, $param, $type, $auto);
                                }
                                continue;
                            }
                            $feed_json_other = json_decode($newItems, true);
                            if ($feed_json_other === NULL) {
                                if(isset($midas_Main_Settings['enable_detailed_logging']))
                                {
                                    midas_log_to_file ("json_decode failed for" .$feed_uri, $param, $type, $auto);
                                }
                                continue;
                            }
                            if (!isset($feed_json_other['item'])) {
                                if(isset($midas_Main_Settings['enable_detailed_logging']))
                                {
                                    midas_log_to_file ("feed_json_other[item] not set for " .$feed_uri, $param, $type, $auto);
                                }
                                continue;
                            }
                            if (isset($feed_json_other['item']['id'])) {
                                $interest_json[] = $feed_json_other['item'];
                                $rule_pids[]     = $feed_json_other['item']['id'];
                            }
                        }
                    }
                    $post_item_ids = array();
                    foreach ($post_list as $post) {
                        if (get_post_meta($post->ID, 'post_parent_type', true) == $type && get_post_meta($post->ID, 'post_parent_rule', true) == $param) {
                            $post_item_ids[$post->ID] = get_post_meta($post->ID, 'post_item_id', true);
                        }
                    }
                    foreach ($post_item_ids as $key => $p_id) {
                        if (!in_array($p_id, $rule_pids)) {
                            $args = array(
                                'post_parent' => $key
                            );
                            $post_attachments = get_children($args);
                            if(isset($post_attachments) && !empty($post_attachments)) {
                                foreach ($post_attachments as $attachment) {
                                    wp_delete_attachment($attachment->ID, true);
                                }
                            }
                            wp_delete_post($key, true);
                            foreach ($post_list as $index => $post) {
                                if ($post->ID == $key) {
                                    unset($post_list[$index]);
                                    break;
                                }
                            }
                        }
                    }
                } elseif ($type == 6) {
                    $interest_json = array();
                    if (!isset($feed_json['item'])) {
                        midas_clearFromList($param, $type);
                        midas_log_to_file ('feed_json["item"] not set for ' . $feed_uri . '!', $param, $type, $auto);
                        return 'fail';
                    }
                    if (isset($feed_json['item']['id'])) {
                        $interest_json[] = $feed_json['item'];
                    }
                    foreach ($others as $other) {
                        if ($other != '') {
                            $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $other . '.json';
                            $newItems = file_get_contents($feed_uri);
                            if ($newItems === false) {
                                if(isset($midas_Main_Settings['enable_detailed_logging']))
                                {
                                    midas_log_to_file ("file_get_contents failed for" .$feed_uri, $param, $type, $auto);
                                }
                                continue;
                            }
                            $feed_json_other = json_decode($newItems, true);
                            if ($feed_json_other === NULL) {
                                if(isset($midas_Main_Settings['enable_detailed_logging']))
                                {
                                    midas_log_to_file ("json_decode failed for" .$feed_uri, $param, $type, $auto);
                                }
                                continue;
                            }
                            if (!isset($feed_json_other['item'])) {
                                if(isset($midas_Main_Settings['enable_detailed_logging']))
                                {
                                    midas_log_to_file ("feed_json_other[item] not set for" .$feed_uri, $param, $type, $auto);
                                }
                                continue;
                            }
                            if (isset($feed_json_other['item']['id'])) {
                                $interest_json[] = $feed_json_other['item'];
                            }
                        }
                    }
                    $my_post                   = array();
                    $my_post['post_type']      = $post_type;
                    $my_post['comment_status'] = $accept_comments;
                    $my_post['post_status']    = $post_status;
                    $my_post['post_author']    = $post_user_name;
                    if ($item_create_tag != '') {
                        $my_post['tags_input'] = $item_create_tag;
                    }
                    $my_post['post_item_id']             = 'group' . $param;
                    $my_post['post_item_marketplace']    = '';
                    $my_post['post_item_user']           = '';
                    $my_post['post_item_url']            = '';
                    $my_post['post_item_thumbnail']      = '';
                    $my_post['post_item_preview_img']    = '';
                    $my_post['post_item_media_url']      = '';
                    $my_post['post_item_cost']           = '';
                    $my_post['post_item_uploaded']       = '';
                    $my_post['post_item_cats']           = '';
                    $my_post['post_item_tags']           = '';
                    $my_post['market_item_last_updated'] = '';
                }
                $type6cnt           = 0;
                $type6_post_content = '';
                foreach ($interest_json as $key => $item) {
                    if ($counter <= (int) $max) {
                        $dom = new DOMDocument();
                        if (!isset($item['url'])) {
                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                            {
                                midas_log_to_file ('Item does not have url attribute: ' . $feed_uri . '!', $param, $type, $auto);
                            }
                            continue;
                        }
                        @$dom->loadHTMLFile($item['url']);
                        if ($dom === FALSE) {
                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                            {
                                midas_log_to_file ('loadHTMLFile failed for: ' . $item['url'] . '!', $param, $type, $auto);
                            }
                            continue;
                        }
                        $xpath   = new DOMXPath($dom);
                        $div     = $xpath->query('//div[@class="user-html"]');
                        if ($div === FALSE) {
                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                            {
                                midas_log_to_file ('xpath->query failed for: ' . $item['url'] . '!', $param, $type, $auto);
                            }
                            continue;
                        }
                        $div     = $div->item(0);
                        $content = $dom->saveXML($div);
                        if ($content === FALSE) {
                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                            {
                                midas_log_to_file ('saveXML failed for: ' . $item['url'] . '!', $param, $type, $auto);
                            }
                            continue;
                        }
                        if ($type !== 6) {
                            if ($type == 5)
                            {
                                $marketplace = $item['url'];
                            }
                            $id    = $item['id'];
                            $found = 0;
                            if (in_array($id, $posted_items)) {
                                $found = 1;
                            }
                            if ($found == 0) {
                                $item_media = '';
                                if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                    $item_media = isset($item['preview_url']) ? $item['preview_url'] : '';
                                }
                                if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                    $item_media = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                }
                                $item_img                  = isset($item['live_preview_url']) ? $item['live_preview_url'] : '';
                                $item_video                = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                $item_thumb                = isset($item['thumbnail']) ? $item['thumbnail'] : '';
                                $item_url                  = isset($item['url']) ? $item['url'] : '';
                                $item_user                 = isset($item['user']) ? $item['user'] : '';
                                $item_cost                 = isset($item['cost']) ? $item['cost'] : '';
                                $item_cat                  = isset($item['category']) ? $item['category'] : '';
                                $item_tags                 = isset($item['tags']) ? $item['tags'] : '';
                                $item_uploaded             = isset($item['uploaded_on']) ? $item['uploaded_on'] : '';
                                $item_last_update          = isset($item['last_update']) ? $item['last_update'] : '';
                                $just_title                = isset($item['item']) ? $item['item'] : '';
                                $item_sales                = isset($item['sales']) ? $item['sales'] : '';
                                $item_rating               = isset($item['rating']) ? $item['rating'] : '';
                                $my_post                   = array();
                                $my_post['post_type']      = $post_type;
                                $my_post['post_status']    = $post_status;
                                $my_post['post_author']    = $post_user_name;
                                if ($can_create_tag == 'on') {
                                    $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                } else if ($item_create_tag != '') {
                                    $my_post['tags_input'] = $item_create_tag;
                                }
                                $my_post['post_item_id']             = $id;
                                $my_post['post_item_marketplace']    = $marketplace;
                                $my_post['post_item_user']           = $item_user;
                                $my_post['post_item_url']            = $item_url;
                                $my_post['post_item_thumbnail']      = $item_thumb;
                                $my_post['post_item_preview_img']    = $item_img;
                                $my_post['post_item_media_url']      = $item_media;
                                $my_post['post_item_cost']           = $item_cost;
                                $my_post['post_item_uploaded']       = $item_uploaded;
                                $my_post['post_item_cats']           = $item_cat;
                                $my_post['post_item_tags']           = $item_tags;
                                $my_post['market_item_last_updated'] = $item_last_update;
                                if ($type == 0) {
                                    $the_content = $midas_Main_Settings['post_content'];
                                } elseif ($type == 1) {
                                    $the_content = $midas_Main_Settings['post_content_user'];
                                } elseif ($type == 2) {
                                    $the_content = $midas_Main_Settings['post_content_popular'];
                                } elseif ($type == 3) {
                                    $the_content = $midas_Main_Settings['post_content_random'];
                                } elseif ($type == 4) {
                                    $the_content = $midas_Main_Settings['post_content_featured'];
                                } elseif ($type == 5) {
                                    $the_content = $midas_Main_Settings['post_content_manual'];
                                }
                                if (strpos($the_content, '%%') !== false) {
                                    $the_content = midas_replaceContentShortcodes($the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                if (strpos($the_content, 'images/smileys/') !== false) {
                                    $the_content = midas_replaceContentSmileys($the_content);
                                }
                                $my_post['post_content'] = $the_content;
                                $my_post['post_excerpt']   = midas_getExcerpt($content);
                                if ($type == 0) {
                                    $the_title = $midas_Main_Settings['post_title'];
                                } elseif ($type == 1) {
                                    $the_title = $midas_Main_Settings['post_title_user'];
                                } elseif ($type == 2) {
                                    $the_title = $midas_Main_Settings['post_title_popular'];
                                } elseif ($type == 3) {
                                    $the_title = $midas_Main_Settings['post_title_random'];
                                } elseif ($type == 4) {
                                    $the_title = $midas_Main_Settings['post_title_featured'];
                                } elseif ($type == 5) {
                                    $the_title = $midas_Main_Settings['post_title_manual'];
                                }  else {
                                    $the_title = '';
                                }
                                if (strpos($the_title, '%%') !== false) {
                                    $the_title = midas_replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                $my_post['post_title'] = $the_title;
                                $post_array[]          = $my_post;
                            } else {
                                $item_last_update = isset($item['last_update']) ? $item['last_update'] : '';
                                foreach ($post_list as $post) {
                                    $item_id = get_post_meta($post->ID, 'post_item_id', true);
                                    if ($item_id == $id) {
                                        $item_in_post_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
                                        if ($item_in_post_updated != $item_last_update && $item_last_update != '') {
                                            $item_media = '';
                                            if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                                $item_media = isset($item['preview_url']) ? $item['preview_url'] : '';
                                            }
                                            if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                                $item_media = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                            }
                                            $item_img                  = isset($item['live_preview_url']) ? $item['live_preview_url'] : '';
                                            $item_video                = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                            $item_thumb                = isset($item['thumbnail']) ? $item['thumbnail'] : '';
                                            $item_url                  = isset($item['url']) ? $item['url'] : '';
                                            $item_user                 = isset($item['user']) ? $item['user'] : '';
                                            $item_cost                 = isset($item['cost']) ? $item['cost'] : '';
                                            $item_cat                  = isset($item['category']) ? $item['category'] : '';
                                            $item_tags                 = isset($item['tags']) ? $item['tags'] : '';
                                            $item_uploaded             = isset($item['uploaded_on']) ? $item['uploaded_on'] : '';
                                            $item_last_update          = isset($item['last_update']) ? $item['last_update'] : '';
                                            $just_title                = isset($item['item']) ? $item['item'] : '';
                                            $item_sales                = isset($item['sales']) ? $item['sales'] : '';
                                            $item_rating               = isset($item['rating']) ? $item['rating'] : '';
                                            $my_post                   = array();
                                            $my_post['ID']             = $post->ID;
                                            $my_post['post_type']      = $post_type;
                                            $my_post['comment_status'] = $accept_comments;
                                            $my_post['post_status']    = $post_status;
                                            $my_post['post_author']    = $post_user_name;
                                            if ($can_create_tag == 'on') {
                                                $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                            } else if ($item_create_tag != '') {
                                                $my_post['tags_input'] = $item_create_tag;
                                            }
                                            $my_post['post_item_id']             = $id;
                                            $my_post['post_item_marketplace']    = $marketplace;
                                            $my_post['post_item_user']           = $item_user;
                                            $my_post['post_item_url']            = $item_url;
                                            $my_post['post_item_thumbnail']      = $item_thumb;
                                            $my_post['post_item_preview_img']    = $item_img;
                                            $my_post['post_item_media_url']      = $item_media;
                                            $my_post['post_item_cost']           = $item_cost;
                                            $my_post['post_item_uploaded']       = $item_uploaded;
                                            $my_post['post_item_cats']           = $item_cat;
                                            $my_post['post_item_tags']           = $item_tags;
                                            $my_post['market_item_last_updated'] = $item_last_update;
                                            if ($type == 0) {
                                                $the_content = $midas_Main_Settings['post_content'];
                                            } elseif ($type == 1) {
                                                $the_content = $midas_Main_Settings['post_content_user'];
                                            } elseif ($type == 2) {
                                                $the_content = $midas_Main_Settings['post_content_popular'];
                                            } elseif ($type == 3) {
                                                $the_content = $midas_Main_Settings['post_content_random'];
                                            } elseif ($type == 4) {
                                                $the_content = $midas_Main_Settings['post_content_featured'];
                                            } elseif ($type == 5) {
                                                $the_content = $midas_Main_Settings['post_content_manual'];
                                            }
                                            if (strpos($the_content, '%%') !== false) {
                                                $the_content = midas_replaceContentShortcodes($the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            if (strpos($the_content, 'images/smileys/') !== false) {
                                                $the_content = midas_replaceContentSmileys($the_content);
                                            }
                                            $my_post['post_content'] = $the_content;
                                            $my_post['post_excerpt']   = midas_getExcerpt($content);
                                            if ($type == 0) {
                                                $the_title = $midas_Main_Settings['post_title'];
                                            } elseif ($type == 1) {
                                                $the_title = $midas_Main_Settings['post_title_user'];
                                            } elseif ($type == 2) {
                                                $the_title = $midas_Main_Settings['post_title_popular'];
                                            } elseif ($type == 3) {
                                                $the_title = $midas_Main_Settings['post_title_random'];
                                            } elseif ($type == 4) {
                                                $the_title = $midas_Main_Settings['post_title_featured'];
                                            } elseif ($type == 5) {
                                                $the_title = $midas_Main_Settings['post_title_manual'];
                                            }  else {
                                                $the_title = '';
                                            }
                                            if (strpos($the_title, '%%') !== false) {
                                                $the_title = midas_replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            $my_post['post_title'] = $the_title;
                                            $post_id               = wp_update_post($my_post);
                                            if ($post_id != 0) {
                                                $image_failed = false;
                                                if ($auto_image === 'on') {
                                                    if ($my_post['post_item_preview_img'] != '') {
                                                        if(!midas_generate_featured_image($my_post['post_item_preview_img'], $post_id))
                                                        {
                                                            $image_failed = true;
                                                            midas_log_to_file ('midas_generate_featured_image failed!', $param, $type, $auto);
                                                        }
                                                    }
                                                    else
                                                    {
                                                        $image_failed = true;
                                                    }
                                                }
                                                if($image_failed || $auto_image !== 'on' || $type == 6)
                                                {
                                                    $image_url = '';
                                                    if($type == 0 && isset($midas_Main_Settings['featured_image_default']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_default'];
                                                    }
                                                    elseif($type == 1 && isset($midas_Main_Settings['featured_image_user']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_user'];
                                                    }
                                                    elseif($type == 2 && isset($midas_Main_Settings['featured_image_popular']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_popular'];
                                                    }
                                                    elseif($type == 3 && isset($midas_Main_Settings['featured_image_random']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_random'];
                                                    }
                                                    elseif($type == 4 && isset($midas_Main_Settings['featured_image_featured']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_featured'];
                                                    }
                                                    elseif($type == 5 && isset($midas_Main_Settings['featured_image_manual']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_manual'];
                                                    }
                                                    elseif($type == 6 && isset($midas_Main_Settings['featured_image_grouped']))
                                                    {
                                                        $image_url = $midas_Main_Settings['featured_image_grouped'];
                                                    }
                                                    if($image_url != '')
                                                    {
                                                        $url_headers=get_headers($image_url, 1);
                                                        if(isset($url_headers['Content-Type'])){
                                                            $img_type=strtolower($url_headers['Content-Type']);
                                                            $valid_image_type=array();
                                                            $valid_image_type['image/png']='';
                                                            $valid_image_type['image/jpg']='';
                                                            $valid_image_type['image/jpeg']='';
                                                            $valid_image_type['image/jpe']='';
                                                            $valid_image_type['image/gif']='';
                                                            $valid_image_type['image/tif']='';
                                                            $valid_image_type['image/tiff']='';
                                                            $valid_image_type['image/svg']='';
                                                            $valid_image_type['image/ico']='';
                                                            $valid_image_type['image/icon']='';
                                                            $valid_image_type['image/x-icon']='';
                                                            if(isset($valid_image_type[$img_type])){
                                                                if(!midas_generate_featured_image($image_url, $post_id))
                                                                {
                                                                    $image_failed = true;
                                                                    midas_log_to_file ('midas_generate_featured_image failed to deafault value: '. $image_url . '!', $param, $type, $auto);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                midas_updatePostMeta($post_id, $my_post, $param, $type, $envato_username);
                                                
                                                if ($can_create_cat == 'on') {
                                                    $termid = midas_create_terms('category', '0', $my_post['post_item_cats']);
                                                    wp_set_post_terms($post_id, $termid, 'category');
                                                }
                                                if ($type == 0) {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 1) {
                                                    if (isset($midas_Main_Settings['default_category_user']) && $midas_Main_Settings['default_category_user'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_user'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 2) {
                                                    if (isset($midas_Main_Settings['default_category_popular']) && $midas_Main_Settings['default_category_popular'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_popular'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 3) {
                                                    if (isset($midas_Main_Settings['default_category_random']) && $midas_Main_Settings['default_category_random'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_random'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 4) {
                                                    if (isset($midas_Main_Settings['default_category_featured']) && $midas_Main_Settings['default_category_featured'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_featured'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 5) {
                                                    if (isset($midas_Main_Settings['default_category_manual']) && $midas_Main_Settings['default_category_manual'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_manual'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 6) {
                                                    if (isset($midas_Main_Settings['default_category_grouped']) && $midas_Main_Settings['default_category_grouped'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_grouped'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } else {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if(isset($midas_Main_Settings['enable_detailed_logging']))
                                            {
                                                midas_log_to_file ("Skipping '" .$item['item'] . "'(" . $item['id'] . ") because item already has an updated post generated (Last update: " . $item_last_update . ") (postId: " . $post->ID . ")!", $param, $type, $auto);
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            $counter++;
                        } else {
                            $id    = 'group' . $param;
                            $marketplace = $item['url'];
                            $found = 0;
                            if (in_array($id, $posted_items)) {
                                foreach ($post_list as $index => $post) {
                                    $item_id = get_post_meta($post->ID, 'post_item_id', true);
                                    if ($item_id == $id) {
                                        $update_needed = $post->ID;
                                        break;
                                    }
                                }
                            }
                            $item_media = '';
                            if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                $item_media = isset($item['preview_url']) ? $item['preview_url'] : '';
                            }
                            if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                $item_media = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                            }
                            $item_img         = isset($item['live_preview_url']) ? $item['live_preview_url'] : '';
                            $item_video       = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                            $item_thumb       = isset($item['thumbnail']) ? $item['thumbnail'] : '';
                            $item_url         = isset($item['url']) ? $item['url'] : '';
                            $item_user        = isset($item['user']) ? $item['user'] : '';
                            $item_cost        = isset($item['cost']) ? $item['cost'] : '';
                            $item_cat         = isset($item['category']) ? $item['category'] : '';
                            $item_tags        = isset($item['tags']) ? $item['tags'] : '';
                            $item_uploaded    = isset($item['uploaded_on']) ? $item['uploaded_on'] : '';
                            $item_last_update = isset($item['last_update']) ? $item['last_update'] : '';
                            $just_title       = isset($item['item']) ? $item['item'] : '';
                            $item_sales       = isset($item['sales']) ? $item['sales'] : '';
                            $item_rating      = isset($item['rating']) ? $item['rating'] : '';
                            $the_content      = $list_item;
                            
                            $type6cnt = count($interest_json);
                            if (strpos($the_content, '%%') !== false) {
                                $the_content = midas_replaceContentType6Shortcodes($type6cnt, $counter, $the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                            }
                            if (strpos($the_content, 'images/smileys/') !== false) {
                                $the_content = midas_replaceContentSmileys($the_content);
                            }
                            $type6_post_content .= $the_content . '<br/><br/>';
                            $my_post['post_item_marketplace']    .= $marketplace . "<br/>";
                            $my_post['post_item_user']           .= $item_user . "<br/>";
                            $my_post['post_item_url']            .= $item_url . "<br/>";
                            $my_post['post_item_thumbnail']      .= $item_thumb . "<br/>";
                            $my_post['post_item_preview_img']    .= $item_img . "<br/>";
                            $my_post['post_item_media_url']      .= $item_media . "<br/>";
                            $my_post['post_item_cost']           .= $item_cost . "<br/>";
                            $my_post['post_item_uploaded']       .= $item_uploaded . "<br/>";
                            $my_post['post_item_cats']           .= $item_cat . "<br/>";
                            $my_post['post_item_tags']           .= $item_tags . "<br/>";
                            $my_post['market_item_last_updated'] .= $item_last_update . "<br/>";
                            $counter++;
                        }
                    }
                }
            }
            if ($type == 6) {
                $final_content           = $post_content;
                $final_content           = str_replace('%%random_sentence%%', midas_random_sentence_generator(), $final_content);
                $final_content           = str_replace('%%random_sentence2%%', midas_random_sentence_generator(false), $final_content);
                $final_content           = str_replace('%%list_items%%', $type6_post_content, $final_content);
                $my_post['post_content'] = $final_content;
                $my_post['post_excerpt'] = midas_getExcerpt($final_content);
                $post_title = str_replace('%%random_sentence%%', midas_random_sentence_generator(), $post_title);
                $post_title = str_replace('%%random_sentence2%%', midas_random_sentence_generator(false), $post_title);
                $my_post['post_title']   = str_replace('%%total_item_count%%', $type6cnt, $post_title);
                $post_array2[]           = $my_post;
            } else {
                $post_array2 = array_reverse($post_array);
            }
            foreach ($post_array2 as $post) {
                if($type == 6 && $update_needed !== '-1')
                {
                    $post['ID'] = $update_needed;
                    $post_id = wp_update_post($post);
                }
                else
                {
                    $post_id = wp_insert_post($post);
                }
                
                if ($post_id != 0) {
                    $posts_inserted++;
                    $tax_rez = wp_set_object_terms( $post_id, $param . '-' . $type, 'midas_post' );
                    if ( is_wp_error( $tax_rez ) ) {
                        midas_log_to_file ('wp_set_object_terms failed for: ' . $post_id . '!', $param, $type, $auto);
                    }
                    $image_failed = false;
                    if ($auto_image === 'on' && $type != 6) {
                        if ($post['post_item_preview_img'] != '') {
                            if(!midas_generate_featured_image($post['post_item_preview_img'], $post_id))
                            {
                                $image_failed = true;
                                midas_log_to_file ('midas_generate_featured_image failed!', $param, $type, $auto);
                            }
                        }
                        else
                        {
                            $image_failed = true;
                        }
                    }
                    if($image_failed || $auto_image !== 'on' || $type == 6)
                    {
                        $image_url = '';
                        if($type == 0 && isset($midas_Main_Settings['featured_image_default']))
                        {
                            $image_url = $midas_Main_Settings['featured_image_default'];
                        }
                        elseif($type == 1 && isset($midas_Main_Settings['featured_image_user']))
                        {
                            $image_url = $midas_Main_Settings['featured_image_user'];
                        }
                        elseif($type == 2 && isset($midas_Main_Settings['featured_image_popular']))
                        {
                            $image_url = $midas_Main_Settings['featured_image_popular'];
                        }
                        elseif($type == 3 && isset($midas_Main_Settings['featured_image_random']))
                        {
                            $image_url = $midas_Main_Settings['featured_image_random'];
                        }
                        elseif($type == 4 && isset($midas_Main_Settings['featured_image_featured']))
                        {
                            $image_url = $midas_Main_Settings['featured_image_featured'];
                        }
                        elseif($type == 5 && isset($midas_Main_Settings['featured_image_manual']))
                        {
                            $image_url = $midas_Main_Settings['featured_image_manual'];
                        }
                        elseif($type == 6 && isset($midas_Main_Settings['featured_image_grouped']))
                        {
                            $image_url = $midas_Main_Settings['featured_image_grouped'];
                        }
                        if($image_url != '')
                        {
                            $url_headers=get_headers($image_url, 1);
                            if(isset($url_headers['Content-Type'])){
                                $img_type=strtolower($url_headers['Content-Type']);
                                $valid_image_type=array();
                                $valid_image_type['image/png']='';
                                $valid_image_type['image/jpg']='';
                                $valid_image_type['image/jpeg']='';
                                $valid_image_type['image/jpe']='';
                                $valid_image_type['image/gif']='';
                                $valid_image_type['image/tif']='';
                                $valid_image_type['image/tiff']='';
                                $valid_image_type['image/svg']='';
                                $valid_image_type['image/ico']='';
                                $valid_image_type['image/icon']='';
                                $valid_image_type['image/x-icon']='';
                                if(isset($valid_image_type[$img_type])){
                                    if(!midas_generate_featured_image($image_url, $post_id))
                                    {
                                        $image_failed = true;
                                        midas_log_to_file ('midas_generate_featured_image failed to deafault value: '. $image_url . '!', $param, $type, $auto);
                                    }
                                }
                            }
                        }
                    }
                    midas_addPostMeta($post_id, $post, $param, $type, $envato_username);
                    
                    if ($can_create_cat == 'on' && $type != 6) {
                        $termid = midas_create_terms('category', '0', $post['post_item_cats']);
                        wp_set_post_terms($post_id, $termid, 'category');
                    }
                    if ($type == 0) {
                        if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 1) {
                        if (isset($midas_Main_Settings['default_category_user']) && $midas_Main_Settings['default_category_user'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category_user'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 2) {
                        if (isset($midas_Main_Settings['default_category_popular']) && $midas_Main_Settings['default_category_popular'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category_popular'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 3) {
                        if (isset($midas_Main_Settings['default_category_random']) && $midas_Main_Settings['default_category_random'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category_random'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 4) {
                        if (isset($midas_Main_Settings['default_category_featured']) && $midas_Main_Settings['default_category_featured'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category_featured'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 5) {
                        if (isset($midas_Main_Settings['default_category_manual']) && $midas_Main_Settings['default_category_manual'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category_manual'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 6) {
                        if (isset($midas_Main_Settings['default_category_grouped']) && $midas_Main_Settings['default_category_grouped'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category_grouped'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } else {
                        if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    }
                    if(intval($auto_generate_comments) != 0 && $type != 6)
                    {
                        $comments_inserted = 1;
                        $feed_uri = 'https://marketplace.envato.com/feeds/items/' . $post['post_item_id'];
                        $newItems = file_get_contents($feed_uri);
                        if ($newItems === false) {
                            midas_log_to_file ('file_get_contents failed for: ' . 'https://marketplace.envato.com/feeds/items/' . $post['post_item_id'] . '.json' . '!', $param, $type, $auto);
                            continue;
                        }
                        $content_xml = new DOMDocument();
                        if (!$content_xml->loadXML($newItems)) {
                            midas_log_to_file ('loadXML failed for ' . $feed_uri . '!', $param, $type, $auto);
                            continue;
                        }
                        $content = '';
                        $author = '';
                        foreach ($content_xml->documentElement->childNodes as $item_xml) {
                            if($comments_inserted <= intval($auto_generate_comments))
                            {
                                $content = midas_get_xml_value($item_xml, 'content');
                                $author = midas_get_xml_value($item_xml, 'author');
                                
                                if(isset($content) && trim($content) != '' && isset($author) && trim($author) != '')
                                {
                                    $time = midas_get_xml_value($item_xml, 'published');
                                    if(!isset($time) || trim($time) == '')
                                    {
                                        $time = current_time('mysql');
                                    }
                                    $content = midas_replaceContentSmileys($content);
                                    $data = array(
                                        'comment_post_ID' => $post_id,
                                        'comment_author' => trim($author),
                                        'comment_author_email' => '',
                                        'comment_author_url' => '',
                                        'comment_content' => trim($content),
                                        'comment_type' => '',
                                        'comment_parent' => 0,
                                        'user_id' => 1,
                                        'comment_author_IP' => '127.0.0.1',
                                        'comment_agent' => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36',
                                        'comment_date' => $time,
                                        'comment_approved' => 1
                                    );
                                    $ret = wp_insert_comment($data);
                                    if($ret === FALSE)
                                    {
                                        midas_log_to_file ('wp_insert_comment failed for comment:' . trim($content) . ' on post id: ' . $post_id . '!', $param, $type, $auto);
                                    }
                                    else
                                    {
                                        $comments_inserted++;
                                    }
                                }
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                } else {
                    if($type == 6 && $update_needed !== '-1')
                    {
                        if(isset($midas_Main_Settings['enable_detailed_logging']))
                        {
                            midas_log_to_file ('Failed to update post into database! Title:' . $post['post_title'] . ', ID: ' . $update_needed . '!', $param, $type, $auto);
                        }
                    }
                    else
                    {
                        if(isset($midas_Main_Settings['enable_detailed_logging']))
                        {
                            midas_log_to_file ('Failed to insert post into database! Title:' . $post['post_title'] . '!', $param, $type, $auto);
                        }
                    }
                    continue;
                }
            }
        }
        catch (Exception $e) {
            midas_clearFromList($param, $type);
            midas_log_to_file ('Exception thrown ' . $e . '!', $param, $type, $auto);
            return 'fail';
        }
        if(isset($midas_Main_Settings['enable_detailed_logging']))
        {
            midas_log_to_file ('Rule succesfully run! ' . $posts_inserted . ' posts created!', $param, $type, $auto);
        }
        midas_clearFromList($param, $type);
    }
    return 'ok';
}

function midas_addPostMeta($post_id, $post, $param, $type, $envato_username)
{
    add_post_meta($post_id, 'post_creator_last_updated', $post['market_item_last_updated']);
    add_post_meta($post_id, 'post_item_id', $post['post_item_id']);
    add_post_meta($post_id, 'post_parent_rule', $param);
    add_post_meta($post_id, 'post_parent_type', $type);
    add_post_meta($post_id, 'post_thumbnail', $post['post_item_preview_img']);
    add_post_meta($post_id, 'post_item_marketplace', $post['post_item_marketplace']);
    add_post_meta($post_id, 'post_item_url', $post['post_item_url'] . '?ref=' . $envato_username);
    add_post_meta($post_id, 'post_item_user', $post['post_item_user']);
    add_post_meta($post_id, 'post_item_thumbnail', $post['post_item_thumbnail']);
    add_post_meta($post_id, 'post_item_media_url', $post['post_item_media_url']);
    add_post_meta($post_id, 'post_item_cost', $post['post_item_cost']);
    add_post_meta($post_id, 'post_item_uploaded', $post['post_item_uploaded']);
    add_post_meta($post_id, 'post_item_last_update', $post['market_item_last_updated']);
    add_post_meta($post_id, 'post_item_cats', $post['post_item_cats']);
    add_post_meta($post_id, 'post_item_tags', $post['post_item_tags']);
}

function midas_updatePostMeta($post_id, $post, $param, $type, $envato_username)
{
    update_post_meta($post_id, 'post_creator_last_updated', $post['market_item_last_updated']);
    update_post_meta($post_id, 'post_item_id', $post['post_item_id']);
    update_post_meta($post_id, 'post_parent_rule', $param);
    update_post_meta($post_id, 'post_parent_type', $type);
    update_post_meta($post_id, 'post_thumbnail', $post['post_item_preview_img']);
    update_post_meta($post_id, 'post_item_marketplace', $post['post_item_marketplace']);
    update_post_meta($post_id, 'post_item_url', $post['post_item_url'] . '?ref=' . $envato_username);
    update_post_meta($post_id, 'post_item_user', $post['post_item_user']);
    update_post_meta($post_id, 'post_item_thumbnail', $post['post_item_thumbnail']);
    update_post_meta($post_id, 'post_item_media_url', $post['post_item_media_url']);
    update_post_meta($post_id, 'post_item_cost', $post['post_item_cost']);
    update_post_meta($post_id, 'post_item_uploaded', $post['post_item_uploaded']);
    update_post_meta($post_id, 'post_item_last_update', $post['market_item_last_updated']);
    update_post_meta($post_id, 'post_item_cats', $post['post_item_cats']);
    update_post_meta($post_id, 'post_item_tags', $post['post_item_tags']);
}
function midas_replaceContentSmileys($the_content)
{
    $the_content = str_replace('/images/smileys/grin.png', 'https://codecanyon.net/images/smileys/grin.png', $the_content);
    $the_content = str_replace('/images/smileys/wink.png', 'https://codecanyon.net/images/smileys/wink.png', $the_content);
    $the_content = str_replace('/images/smileys/happy.png', 'https://codecanyon.net/images/smileys/happy.png', $the_content);
    $the_content = str_replace('/images/smileys/shocked.png', 'https://codecanyon.net/images/smileys/shocked.png', $the_content);
    $the_content = str_replace('/images/smileys/sad.png', 'https://codecanyon.net/images/smileys/sad.png', $the_content);
    $the_content = str_replace('/images/smileys/cool.png', 'https://codecanyon.net/images/smileys/cool.png', $the_content);
    return $the_content;
}
function midas_replaceContentShortcodes($the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    $the_content = str_replace('%%random_sentence%%', midas_random_sentence_generator(), $the_content);
    $the_content = str_replace('%%random_sentence2%%', midas_random_sentence_generator(false), $the_content);
    $the_content = str_replace('%%see_more_button%%', midas_getSeeMoreButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%video_preview_button%%', midas_getVideoPreviewButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%video_preview%%', midas_getVideoPreview($item, $envato_username), $the_content);
    $the_content = str_replace('%%buy_now_button%%', midas_getBuyNowButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%item_screenshots_button%%', midas_getScreenshotsButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%item_rotating_preview_button%%', midas_getRotatingPreviewButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%live_preview_button%%', midas_getLiveLink($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%generate_item_intro%%', midas_getIntro($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%generate_item_thumbnail%%', midas_getThumbnail($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_preview%%', midas_getItemImageOrMedia($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_title%%', $just_title, $the_content);
    $the_content = str_replace('%%item_description%%', $content, $the_content);
    $the_content = str_replace('%%item_id%%', $id, $the_content);
    $the_content = str_replace('%%item_media_url%%', $item_media, $the_content);
    $the_content = str_replace('%%item_img_url%%', $item_img, $the_content);
    $the_content = str_replace('%%item_video_url%%', $item_video, $the_content);
    $the_content = str_replace('%%item_thumb_url%%', $item_thumb, $the_content);
    $the_content = str_replace('%%item_url%%', $item_url, $the_content);
    $the_content = str_replace('%%item_user%%', $item_user, $the_content);
    $the_content = str_replace('%%item_cost%%', $item_cost, $the_content);
    $the_content = str_replace('%%item_cat%%', $item_cat, $the_content);
    $the_content = str_replace('%%item_tags%%', $item_tags, $the_content);
    $the_content = str_replace('%%item_uploaded%%', $item_uploaded, $the_content);
    $the_content = str_replace('%%item_last_update%%', $item_last_update, $the_content);
    $the_content = str_replace('%%item_sales%%', $item_sales, $the_content);
    $the_content = str_replace('%%item_rating%%', $item_rating, $the_content);
    $the_content = str_replace('%%item_description_plain_text%%', midas_getPlainContent($content), $the_content);
    return $the_content;
}

function midas_replaceContentType6Shortcodes($total, $counter, $the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    $the_content = str_replace('%%total_item_count%%', $total, $the_content);
    $the_content = str_replace('%%random_sentence%%', midas_random_sentence_generator(), $the_content);
    $the_content = str_replace('%%random_sentence2%%', midas_random_sentence_generator(false), $the_content);
    $the_content = str_replace('%%current_counter%%', $counter, $the_content);
    $the_content = str_replace('%%see_more_button%%', midas_getSeeMoreButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%buy_now_button%%', midas_getBuyNowButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%video_preview_button%%', midas_getVideoPreviewButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%video_preview%%', midas_getVideoPreview($item, $envato_username), $the_content);
    $the_content = str_replace('%%item_screenshots_button%%', midas_getScreenshotsButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%item_rotating_preview_button%%', midas_getRotatingPreviewButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%live_preview_button%%', midas_getLiveLink($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%generate_item_intro%%', midas_getIntro($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%generate_item_thumbnail%%', midas_getThumbnail($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_preview%%', midas_getItemImageOrMedia($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_title%%', $just_title, $the_content);
    $the_content = str_replace('%%item_description%%', $content, $the_content);
    $the_content = str_replace('%%item_id%%', $id, $the_content);
    $the_content = str_replace('%%item_media_url%%', $item_media, $the_content);
    $the_content = str_replace('%%item_img_url%%', $item_img, $the_content);
    $the_content = str_replace('%%item_video_url%%', $item_video, $the_content);
    $the_content = str_replace('%%item_thumb_url%%', $item_thumb, $the_content);
    $the_content = str_replace('%%item_url%%', $item_url, $the_content);
    $the_content = str_replace('%%item_user%%', $item_user, $the_content);
    $the_content = str_replace('%%item_cost%%', $item_cost, $the_content);
    $the_content = str_replace('%%item_cat%%', $item_cat, $the_content);
    $the_content = str_replace('%%item_tags%%', $item_tags, $the_content);
    $the_content = str_replace('%%item_uploaded%%', $item_uploaded, $the_content);
    $the_content = str_replace('%%item_last_update%%', $item_last_update, $the_content);
    $the_content = str_replace('%%item_sales%%', $item_sales, $the_content);
    $the_content = str_replace('%%item_rating%%', $item_rating, $the_content);
    $the_content = str_replace('%%item_description_plain_text%%', midas_getPlainContent($content), $the_content);
    return $the_content;
}

function midas_replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    $the_title = str_replace('%%random_sentence%%', midas_random_sentence_generator(), $the_title);
    $the_title = str_replace('%%random_sentence2%%', midas_random_sentence_generator(false), $the_title);
    $the_title = str_replace('%%item_title%%', $just_title, $the_title);
    $the_title = str_replace('%%item_description%%', $content, $the_title);
    $the_title = str_replace('%%item_id%%', $id, $the_title);
    $the_title = str_replace('%%item_user%%', $item_user, $the_title);
    $the_title = str_replace('%%item_cost%%', $item_cost, $the_title);
    $the_title = str_replace('%%item_cat%%', $item_cat, $the_title);
    $the_title = str_replace('%%item_tags%%', $item_tags, $the_title);
    $the_title = str_replace('%%item_uploaded%%', $item_uploaded, $the_title);
    $the_title = str_replace('%%item_last_update%%', $item_last_update, $the_title);
    $the_title = str_replace('%%item_sales%%', $item_sales, $the_title);
    $the_title = str_replace('%%item_rating%%', $item_rating, $the_title);
    return $the_title;
}

function midas_generate_featured_image($image_url, $post_id)
{
    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($image_url);
    if($image_data === FALSE)
    {
        return false;
    }
    $filename = basename($image_url);
    $filename = str_replace('%', '-', $filename);
    $filename = str_replace('#', '-', $filename);
    $filename = str_replace('&', '-', $filename);
    $filename = str_replace('{', '-', $filename);
    $filename = str_replace('}', '-', $filename);
    $filename = str_replace('\\', '-', $filename);
    $filename = str_replace('<', '-', $filename);
    $filename = str_replace('>', '-', $filename);
    $filename = str_replace('*', '-', $filename);
    $filename = str_replace('?', '-', $filename);
    $filename = str_replace('/', '-', $filename);
    $filename = str_replace('$', '-', $filename);
    $filename = str_replace('\'', '-', $filename);
    $filename = str_replace('"', '-', $filename);
    $filename = str_replace(':', '-', $filename);
    $filename = str_replace('@', '-', $filename);
    $filename = str_replace('+', '-', $filename);
    $filename = str_replace('|', '-', $filename);
    $filename = str_replace('=', '-', $filename);
    $filename = str_replace('`', '-', $filename);
    if (wp_mkdir_p($upload_dir['path'] . '/' . $post_id))
        $file = $upload_dir['path'] . '/' . $post_id . '/' . $filename;
    else
        $file = $upload_dir['basedir'] . '/' . $post_id . '/' . $filename;
    $ret = file_put_contents($file, $image_data);
    if($ret === FALSE)
    {
        return false;
    }
    $wp_filetype = wp_check_filetype($filename, null);
    $attachment  = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id   = wp_insert_attachment($attachment, $file, $post_id);
    if($attach_id === 0)
    {
        return false;
    }
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
    $res1        = wp_update_attachment_metadata($attach_id, $attach_data);
    if($res1 === FALSE)
    {
        return false;
    }
    $res2        = set_post_thumbnail($post_id, $attach_id);
    if($res2 === FALSE)
    {
        return false;
    }
    return true;
}

function midas_hour_diff($date1, $date2)
{
    $date1 = new DateTime($date1);
    $date2 = new DateTime($date2);
    
    $number1 = (int) $date1->format('U');
    $number2 = (int) $date2->format('U');
    return ($number1 - $number2) / 60 / 60;
}

function midas_add_hour($date, $hour)
{
    $date1 = new DateTime($date);
    $date1->modify("$hour hours");
    foreach ($date1 as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return $date;
}

function midas_get_date_now($param = 'now')
{
    $date = new DateTime($param);
    foreach ($date as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return '';
}

function midas_create_terms($taxonomy, $parent, $terms_str)
{
    $terms          = explode('/', $terms_str);
    $categories     = array();
    $parent_term_id = $parent;
    foreach ($terms as $term) {
        $res = term_exists($term, $taxonomy);
        if ($res != NULL && $res != 0 && count($res) > 0 && isset($res['term_id'])) {
            $parent_term_id = $res['term_id'];
            $categories[]   = $parent_term_id;
        } else {
            $new_term = wp_insert_term($term, $taxonomy, array(
                'parent' => $parent_term_id
            ));
            if ($new_term != NULL && $new_term != 0 && count($new_term) > 0 && isset($new_term['term_id'])) {
                $parent_term_id = $new_term['term_id'];
                $categories[]   = $parent_term_id;
            }
        }
    }
    
    return $categories;
}

add_shortcode("midas_author", "midas_author");
function midas_author($atts)
{
    $user = isset( $atts['user'] )? $atts['user'] : '';
    if($user == '')
    {
        return '';
    }
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['rule_timeout']) && $midas_Main_Settings['rule_timeout'] != '')
    {
        $timeout = intval($midas_Main_Settings['rule_timeout']);
    }
    else
    {
        $timeout = 3600;
    }
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', $timeout);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    set_time_limit($timeout);
        
        if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
            if (isset($midas_Main_Settings['user_name'])) {
                    $envato_username = $midas_Main_Settings['user_name'];
                } else {
                    $envato_username = '';
                }
            $thumbnail = isset( $atts['thumbnail'] )? true : false;
            $image = isset( $atts['image'] )? true : false;
            $country = isset( $atts['country'] )? true : false;
            $sales = isset( $atts['sales'] )? true : false;
            $location = isset( $atts['location'] )? true : false;
            $followers = isset( $atts['followers'] )? true : false;
            
            $user = trim($user,'"');
            $user = trim($user,"'");
            $user = trim($user);
            $feed_uri = 'https://marketplace.envato.com/api/v3/user:' . $user . '.json';
            $newItems = file_get_contents($feed_uri);
            if ($newItems === false) {
                return '';
            }
            $feed_json = json_decode($newItems, true);
            if ($feed_json === NULL) {
                return '';
            }
            if (!isset($feed_json['user']) || !isset($feed_json['user']['username'])) {
                return '';
            }
            $authorCode ='<p>';
            if($thumbnail && isset($feed_json['user']['image']))
            {
                $authorCode .= '<div style="display:inline-block;float:left;"><a class="fancybox" rel="group" href="' . $feed_json['user']['image'] . '"><img src="' . $feed_json['user']['image'] . '" alt="envato user"></a></div>';
            }
            $authorCode .= '<a href="https://themeforest.net/user/' . $user . '?ref=' . $envato_username . '"><span style="font-size:1.3em;"><b>&nbsp;' . $feed_json['user']['username'] . '</b></span></a><br/>';
            if($image && isset($feed_json['user']['homepage_image']))
            {
                 $authorCode .= '<br/><br/><br/><a class="fancybox" rel="group" href="' . $feed_json['user']['homepage_image'] . '"><img src="' . $feed_json['user']['homepage_image'] . '" alt="envato user"></a><br/>';
            }
            if($country && isset($feed_json['user']['country']))
            {
                if($feed_json['user']['country'] != '')
                {
                    $authorCode .='<b>Country: </b>' . $feed_json['user']['country'] . '<br/>';
                }
            }
            if($sales && isset($feed_json['user']['sales']))
            {
                $authorCode .= '<b>Sales: </b>' . $feed_json['user']['sales'] . '<br/>';
            }
            if($location && isset($feed_json['user']['location']))
            {
                $authorCode .= '<b>Location: </b>' . $feed_json['user']['location'] . '<br/>';
            }
            if($followers && isset($feed_json['user']['followers']))
            {
                $authorCode .= '<b>Followers: </b>' . $feed_json['user']['followers'];
            }
            $authorCode .= '</p>';
            return $authorCode;
        }
        else
        {
            return '';
        }
}

add_shortcode("midas_item", "midas_item");
function midas_item($atts)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['rule_timeout']) && $midas_Main_Settings['rule_timeout'] != '')
    {
        $timeout = intval($midas_Main_Settings['rule_timeout']);
    }
    else
    {
        $timeout = 3600;
    }
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', $timeout);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    set_time_limit($timeout);
    
        $item = isset( $atts['item'] )? $atts['item'] : '';
        if($item == '')
        {
            return '';
        }
        if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
            if (isset($midas_Main_Settings['user_name'])) {
                    $envato_username = $midas_Main_Settings['user_name'];
                } else {
                    $envato_username = '';
                }
            $thumbnail = isset( $atts['thumbnail'] )? true : false;
            $image = isset( $atts['image'] )? true : false;
            $sales = isset( $atts['sales'] )? true : false;
            $author = isset( $atts['author'] )? true : false;
            $rating = isset( $atts['rating'] )? true : false;
            $cost = isset( $atts['cost'] )? true : false;
            $tags = isset( $atts['tags'] )? true : false;
            $category = isset( $atts['category'] )? true : false;
            $uploaded_on = isset( $atts['uploaded_on'] )? true : false;
            $last_update = isset( $atts['last_update'] )? true : false;
            
            $item = trim($item,'"');
            $item = trim($item,"'");
            $item = trim($item);
            $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $item . '.json';
            $newItems = file_get_contents($feed_uri);
            if ($newItems === false) {
                return '';
            }
            $feed_json = json_decode($newItems, true);
            if ($feed_json === NULL) {
                return '';
            }
            if (!isset($feed_json['item']) || !isset($feed_json['item']['id']) || !isset($feed_json['item']['url'])) {
                return '';
            }
            $authorCode ='<p>';
            if($thumbnail && isset($feed_json['item']['thumbnail']))
            {
                $authorCode .= '<div style="display:inline-block;float:left;"><a class="fancybox" rel="group" href="' . $feed_json['item']['thumbnail'] . '"><img src="' . $feed_json['item']['thumbnail'] . '" alt="envato item"></a></div>';
            }
            if(isset($feed_json['item']['item']))
            {
                $authorCode .= '<a href="' . $feed_json['item']['url'] . '?ref=' . $envato_username . '" target="_blank"><span style="font-size:1.3em;"><b>&nbsp;' . $feed_json['item']['item'] . '</b></span></a><br/>';
            }
            if($image && isset($feed_json['item']['live_preview_url']))
            {
                 $authorCode .= '<br/><br/><br/><a class="fancybox" rel="group" href="' . $feed_json['item']['live_preview_url'] . '"><img src="' . $feed_json['item']['live_preview_url'] . '" alt="envato item"></a><br/>';
            }
            if($author && isset($feed_json['item']['user']))
            {
                $authorCode .= '<b>Author: </b>' . $feed_json['item']['user'] . '<br/>';
            }
            if($cost && isset($feed_json['item']['cost']))
            {
                $authorCode .= '<b>Cost: </b>' . $feed_json['item']['cost'] . '$<br/>';
            }
            if($sales && isset($feed_json['item']['sales']))
            {
                $authorCode .= '<b>Sales: </b>' . $feed_json['item']['sales'] . '<br/>';
            }
            if($rating && isset($feed_json['item']['rating']))
            {
                $authorCode .= '<b>Rating: </b>' . $feed_json['item']['rating'] . '<br/>';
            }
            if($uploaded_on && isset($feed_json['item']['uploaded_on']))
            {
                $authorCode .= '<b>Uploaded on: </b>' . $feed_json['item']['uploaded_on'] . '<br/>';
            }
            if($last_update && isset($feed_json['item']['last_update']))
            {
                $authorCode .= '<b>Last Update: </b>' . $feed_json['item']['last_update'] . '<br/>';
            }
            if($category && isset($feed_json['item']['category']))
            {
                $authorCode .= '<b>Category: </b>' . $feed_json['item']['category'] . '<br/>';
            }
            if($tags && isset($feed_json['item']['tags']))
            {
                $authorCode .= '<b>Tags: </b>' . $feed_json['item']['tags'] . '<br/>';
            }
            $authorCode .= '</p>';
            return $authorCode;
        }
        else
        {
            return '';
        }
}

add_shortcode("midas_item_card", "midas_item_card");
function midas_item_card($atts)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['rule_timeout']) && $midas_Main_Settings['rule_timeout'] != '')
    {
        $timeout = intval($midas_Main_Settings['rule_timeout']);
    }
    else
    {
        $timeout = 3600;
    }
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', $timeout);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    set_time_limit($timeout);
        $item = isset( $atts['item'] )? $atts['item'] : '';
        if($item == '')
        {
            return '';
        }
        if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
            if (isset($midas_Main_Settings['user_name'])) {
                    $envato_username = $midas_Main_Settings['user_name'];
                } else {
                    $envato_username = '';
                }
            
            $item = trim($item,'"');
            $item = trim($item,"'");
            $item = trim($item);
            $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $item . '.json';
            $newItems = file_get_contents($feed_uri);
            if ($newItems === false) {
                return '';
            }
            $feed_json = json_decode($newItems, true);
            if ($feed_json === NULL) {
                return '';
            }
            if (!isset($feed_json['item']) || !isset($feed_json['item']['id']) || !isset($feed_json['item']['url'])) {
                return '';
            }
            $authorCode = '<div style="display:inline-block;">' . midas_getIntro($feed_json['item']['url'], $feed_json['item'], $envato_username) . '</div>';
            return $authorCode;
        }
        else
        {
            return '';
        }
}

add_shortcode("midas_item_thumbnail", "midas_item_thumbnail");
function midas_item_thumbnail($atts)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['rule_timeout']) && $midas_Main_Settings['rule_timeout'] != '')
    {
        $timeout = intval($midas_Main_Settings['rule_timeout']);
    }
    else
    {
        $timeout = 3600;
    }
    @ini_set('safe_mode','Off'); 
    @ini_set('max_execution_time', $timeout);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    set_time_limit($timeout);
        $item = isset( $atts['item'] )? $atts['item'] : '';
        if($item == '')
        {
            return '';
        }
        if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
            if (isset($midas_Main_Settings['user_name'])) {
                    $envato_username = $midas_Main_Settings['user_name'];
                } else {
                    $envato_username = '';
                }
            
            $item = trim($item,'"');
            $item = trim($item,"'");
            $item = trim($item);
            $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $item . '.json';
            $newItems = file_get_contents($feed_uri);
            if ($newItems === false) {
                return '';
            }
            $feed_json = json_decode($newItems, true);
            if ($feed_json === NULL) {
                return '';
            }
            if (!isset($feed_json['item']) || !isset($feed_json['item']['id']) || !isset($feed_json['item']['url'])) {
                return '';
            }
            $authorCode = '<div style="display:inline-block;">' . midas_getThumbnail($feed_json['item']['url'], $feed_json['item'], $envato_username) . '</div>';
            return $authorCode;
        }
        else
        {
            return '';
        }
}

function midas_getExcerpt($the_content)
{
    $preview = wp_trim_words($the_content, 55);
    $preview = strip_tags($preview);
    return $preview;
}

function midas_getPlainContent($the_content)
{
    $preview = wp_trim_words($the_content, 999999);
    $preview = strip_tags($preview);
    return $preview;
}
function midas_getItemImageOrMedia($marketplace, $json, $ref_user, $disable_style = false)
{
    $preview = '';
    if($marketplace == '')
    {
        if (isset($json['url'])) {
            $marketplace = $json['url'];
        }
    }
    if($disable_style == false)
    {
        $styling = 'position: relative;display: inline-block;max-width: 100%;';
    }
    else
    {
        $styling = 'max-width: initial;';
    }
    if ((substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') && isset($json['preview_type']) && isset($json['preview_url'])) {
        $preview = '[audio preload="auto" autoplay="0" loop="on" src="' . $json['preview_url'] . '"]';
        $preview = do_shortcode($preview);
    }
    elseif (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
        if (isset($json['live_preview_video_url']) && !midas_endswith($json['live_preview_video_url'], '.flv')) {
            $preview = '[video preload="auto" autoplay="0" loop="on" src="' . $json['live_preview_video_url'] . '" width="440"]';
            $preview = do_shortcode($preview);
        }
        else
        {
            if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
            {
                $preview = '<a href="' . $json['live_preview_url'] . '" class="fancybox" rel="group"><img style="' . $styling . '" src="' . $json['live_preview_url'] . '"></a>';
            }
        }
    }
    elseif ($marketplace == '')
    {
        if (isset($json['url'])) {
            if (substr($json['url'], 0, 23) == 'https://audiojungle.net')
            {
                if(isset($json['live_preview_url']))
                {
                    $preview = '[audio preload="auto" autoplay="0" loop="on" src="' . $json['live_preview_url'] . '"]';
                    $preview = do_shortcode($preview);
                }
                elseif(isset($json['preview_url']))
                {
                    $preview = '[audio preload="auto" autoplay="0" loop="on" src="' . $json['preview_url'] . '"]';
                    $preview = do_shortcode($preview);
                }
            }
            elseif (substr($json['url'], 0, 21) == 'https://videohive.net') {
                if(isset($json['live_preview_video_url']) && !midas_endswith($json['live_preview_video_url'], '.flv'))
                {
                    $preview = '[video preload="auto" autoplay="0" loop="on" src="' . $json['live_preview_video_url'] . '" width="440"]';
                    $preview = do_shortcode($preview);
                }
                elseif(isset($json['live_preview_url']))
                {
                    $preview = '<a class="fancybox" rel="group" href="' . $json['live_preview_url'] . '"><img style="' . $styling . '"  src="' . $json['live_preview_url'] . '"></a>';
                }
            }
            else
            {
                $preview = '<a class="fancybox" rel="group" href="' . $json['live_preview_url'] . '"><img style="' . $styling . '"  src="' . $json['live_preview_url'] . '"></a>';
            }
        }
    }
    elseif (isset($json['live_preview_url'])) {
        $preview = '<a class="fancybox" rel="group" href="' . $json['live_preview_url'] . '"><img style="' . $styling . '"  src="' . $json['live_preview_url'] . '"></a>';
    }
    return $preview;
}

function midas_getSeeMoreButton($json, $ref_user)
{
    $link = '';
    if (isset($json['url'])) {
        $link = '<a style="white-space: nowrap" href="' . $json['url'] . '?ref=' . $ref_user . '" class="button purchase" target="_blank">See More on Envato</a>';
    }
    return $link;
}

function midas_getVideoPreview($json, $ref_user)
{
    $link = '';
    if (isset($json['live_preview_video_url']) && !midas_endswith($json['live_preview_video_url'], '.flv')) {
        $link = '[video preload="auto" autoplay="0" loop="on" src="' . $json['live_preview_video_url'] . '" width="440"]';
        $link = do_shortcode($link);
    } 
    return $link;
}
function midas_getVideoPreviewButton($json, $ref_user)
{
    $link = '';
    if (isset($json['live_preview_video_url'])) {
        $link = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" class="button fancybox" data-type="swf" href="//cdn.jsdelivr.net/jwplayer/5.10/player.swf?file=' . $json['live_preview_video_url'] . '&autostart=true">Video Preview</a>';
    } 
    return $link;
}

function midas_getBuyNowButton($json, $ref_user)
{
    $link = '';
    if (isset($json['url'])) {
        $link = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['url'] . '?license=regular&open_purchase_for_item_id=' . $json['id'] . '&purchasable=source&ref=' . $ref_user . '" class="button purchase" target="_blank">Buy Now</a>';
    }
    return $link;
}
function midas_check_http_header_error($str)
{
    if(strpos($str, '404 Not Found') !== FALSE || strpos($str, '400 Bad Request') !== FALSE || strpos($str, '401 Unauthorized') !== FALSE || strpos($str, '402 Payment Required') !== FALSE || strpos($str, '403 Forbidden') !== FALSE || strpos($str, '405 Method Not Allowed') !== FALSE || strpos($str, '406 Not Acceptable') !== FALSE || strpos($str, '407 Proxy Authentication Required') !== FALSE || strpos($str, '408 Request Time-out') !== FALSE || strpos($str, '409 Conflict') !== FALSE || strpos($str, '410 Gone') !== FALSE || strpos($str, '411 Length Required') !== FALSE || strpos($str, '412 Precondition Failed') !== FALSE || strpos($str, '413 Payload Too Large') !== FALSE || strpos($str, '414 URI Too Long') !== FALSE || strpos($str, '415 Unsupported Media Type') !== FALSE || strpos($str, '416 Range Not Satisfiable') !== FALSE || strpos($str, '417 Expectation Failed') !== FALSE || strpos($str, '418 I\'m a teapot') !== FALSE || strpos($str, '421 Misdirected Request') !== FALSE || strpos($str, '422 Unprocessable Entity') !== FALSE || strpos($str, '423 Locked') !== FALSE || strpos($str, '424 Failed Dependency') !== FALSE || strpos($str, '426 Upgrade Required') !== FALSE || strpos($str, '428 Precondition Required') !== FALSE || strpos($str, '429 Too Many Requests') !== FALSE || strpos($str, '431 Request Header Fields Too Large') !== FALSE || strpos($str, '451 Unavailable For Legal Reasons') !== FALSE)
    {
        return true;
    }
    if(strpos($str, '500 Internal Server Error') !== FALSE || strpos($str, '501 Not Implemented') !== FALSE || strpos($str, '502 Bad Gateway') !== FALSE || strpos($str, '503 Service Unavailable') !== FALSE || strpos($str, '504 Gateway Time-out') !== FALSE || strpos($str, '505 HTTP Version Not Supported') !== FALSE || strpos($str, '506 Variant Also Negotiates') !== FALSE || strpos($str, '507 Insufficient Storage') !== FALSE || strpos($str, '508 Loop Detected') !== FALSE || strpos($str, '510 Not Extended') !== FALSE || strpos($str, '511 Network Authentication Required') !== FALSE)
    {
        return true;
    }
    return false;
}
function midas_getScreenshotsButton($json, $ref_user)
{
    $link = '';
    if (isset($json['url'])) {
        $index = strrpos($json['url'], '/');
        if($index !== FALSE)
        {
            $newstr = substr_replace($json['url'], '/screenshots', $index, 0);
            $file_headers = @get_headers($newstr);
            if(!$file_headers || midas_check_http_header_error($file_headers[0])) {
                return $link;
            }
        }
        else
        {
            return $link;
        }
        $link = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $newstr . '?ref=' . $ref_user . '" class="button purchase" target="_blank">Screenshots</a>';
    }
    return $link;
}
function midas_getRotatingPreviewButton($json, $ref_user)
{
    $link = '';
    if (isset($json['url'])) {
        if (substr($json['url'], 0, 19) == 'https://3docean.net')
        {
            $index = strrpos($json['url'], '/');
            if($index !== FALSE)
            {
                $newstr = substr_replace($json['url'], '/rotating_preview', $index, 0);
                $file_headers = @get_headers($newstr);
                if(!$file_headers || midas_check_http_header_error($file_headers[0])) {
                    return $link;
                }
            }
            else
            {
                return $link;
            }
            $link = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $newstr . '?ref=' . $ref_user . '" class="button purchase" target="_blank">3D Preview</a>';
        }
    }
    return $link;
}

add_action('admin_head', 'midas_my_custom_fonts');

function midas_my_custom_fonts() {
  echo '<style>#taxonomy-midas_post{width:100px;}}</style>';
}

add_action( 'init', 'midas_create_taxonomy', 0 );

function midas_create_taxonomy() {
	$labels = array(
		'name'                       => _x( 'Midas Post Types', 'taxonomy general name', 'textdomain' ),
		'singular_name'              => _x( 'Midas Post Type', 'taxonomy singular name', 'textdomain' ),
		'search_items'               => __( 'Search Midas Post Types', 'textdomain' ),
		'popular_items'              => __( 'Popular Midas Post Types', 'textdomain' ),
		'all_items'                  => __( 'All Midas Post Types', 'textdomain' ),
		'parent_item'                => null,
		'parent_item_colon'          => null,
		'edit_item'                  => __( 'Edit Midas Post Types', 'textdomain' ),
		'update_item'                => __( 'Update Midas Post Types', 'textdomain' ),
		'add_new_item'               => __( 'Add New Midas Post Type', 'textdomain' ),
		'new_item_name'              => __( 'New Midas Post Type Name', 'textdomain' ),
		'separate_items_with_commas' => __( 'Separate Midas Posts Type with commas', 'textdomain' ),
		'add_or_remove_items'        => __( 'Add or remove Midas Posts Type', 'textdomain' ),
		'choose_from_most_used'      => __( 'Choose from the most used Midas Post Types', 'textdomain' ),
		'not_found'                  => __( 'No Midas Post Types found.', 'textdomain' ),
		'menu_name'                  => __( 'Midas Post Types', 'textdomain' ),
	);

	$args = array(
		'hierarchical'          => false,
        'description'           => 'Midas Post Type',
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => array( 'slug' => 'midas_post' ),
	);
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if(isset($midas_Main_Settings['enable_detailed_logging']) && $midas_Main_Settings['enable_detailed_logging'] == 'on')
    {
        register_shutdown_function('midas_shutdown');
    }
    
	register_taxonomy( 'midas_post', array('post', 'page'), $args );
}

function midas_getLiveLink($marketplace, $json, $ref_user)
{
    $preview = '';
    if($marketplace == '')
    {
        if(isset($json['url']))
        {
            $marketplace = $json['url'];
        }
    }
    if ((substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') && isset($json['preview_type']) && isset($json['preview_url'])) {
        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['preview_url'] . '?ref=' . $ref_user . '" class="button fancybox" rel="group">Live Preview</a>';
    }
    elseif ((substr($marketplace, 0, 19) == 'https://3docean.net' || $marketplace == '3docean') && isset($json['url'])) {
        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['url'] . '?ref=' . $ref_user . '" class="button fancybox" rel="group">Live Preview</a>';
    }
    elseif ((substr($marketplace, 0, 23) == 'https://photodune.net' || $marketplace == 'photodune') && isset($json['url'])) {
        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['url'] . '?ref=' . $ref_user . '" class="button fancybox" rel="group">Live Preview</a>';
    }
    elseif ((substr($marketplace, 0, 24) == 'https://graphicriver.net' || $marketplace == 'graphicriver') && isset($json['url'])) {
        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['url'] . '?ref=' . $ref_user . '" class="button fancybox" rel="group">Live Preview</a>';
    }
    elseif (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
        if (isset($json['live_preview_video_url'])) {
            $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_video_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
        }
        else
        {
            if (isset($json['url'])) {
                $index = strrpos($json['url'], '/');
                if($index !== FALSE)
                {
                    $newstr = substr_replace($json['url'], '/full_screen_preview', $index, 0);
                    $newstr = str_replace('https://', 'http://preview.', $newstr);
                    $file_headers = @get_headers($newstr);
                    if(!$file_headers || midas_check_http_header_error($file_headers[0])) {
                        if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
                        {
                            $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                        }
                    }
                    else
                    {
                        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $newstr . '?ref=' . $ref_user . '" class="button purchase" target="_blank">Live Preview</a>';
                    }
                }
                else
                {
                    if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
                    {
                        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                    }
                }
            }
            else
            {
                if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
                {
                    $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                }
            }
        }
    } else{
        
        if (isset($json['url'])) 
        {
            if (substr($json['url'], 0, 23) == 'https://audiojungle.net')
            {
                $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['url'] . '?ref=' . $ref_user . '" class="button purchase" target="_blank">Live Preview</a>';
                return $preview;
            }
        }
        if($marketplace == '')
        {
            if (isset($json['url'])) {
                $index = strrpos($json['url'], '/');
                if($index !== FALSE)
                {
                    $newstr = substr_replace($json['url'], '/full_screen_preview', $index, 0);
                    $newstr = str_replace('https://', 'http://preview.', $newstr);
                    $file_headers = @get_headers($newstr);
                    if(!$file_headers || midas_check_http_header_error($file_headers[0])) {
                        if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
                        {
                            $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                        }
                        else
                        {
                            $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                        }
                    }
                    else
                    {
                        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $newstr . '?ref=' . $ref_user . '" class="button purchase" target="_blank">Live Preview</a>';
                    }
                }
                else
                {
                    $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['url'] . '?ref=' . $ref_user . '" class="button purchase" target="_blank">Live Preview</a>';
                }  
            }
        }
        else
        {
            if (isset($json['url'])) {
                $index = strrpos($json['url'], '/');
                if($index !== FALSE)
                {
                    $newstr = substr_replace($json['url'], '/full_screen_preview', $index, 0);
                    $newstr = str_replace('https://', 'http://preview.', $newstr);
                    $file_headers = @get_headers($newstr);
                    if(!$file_headers || midas_check_http_header_error($file_headers[0])) {
                        if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
                        {
                            $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                        }
                    }
                    else
                    {
                        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $newstr . '?ref=' . $ref_user . '" class="button purchase" target="_blank">Live Preview</a>';
                    }
                }
                else
                {
                    if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
                    {
                        $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                    }
                }
            }
            else
            {
                if(isset($json['live_preview_url']) && $json['live_preview_url'] != '')
                {
                    $preview = '<a style="white-space: nowrap;display: inline-block;padding: 10px 12px 11px;" href="' . $json['live_preview_url'] . '" class="button fancybox" rel="group">Live Preview</a>';
                }
            }
        }
    }
    return $preview;
}

function midas_getIntro($marketplace, $json, $ref_user)
{
    $media     = midas_getItemImageOrMedia($marketplace, $json, $ref_user);
    $link      = midas_getBuyNowButton($json, $ref_user);
    $screenshots = midas_getScreenshotsButton($json, $ref_user);
    $preview3d = midas_getRotatingPreviewButton($json, $ref_user);
    $live_link = midas_getLiveLink($marketplace, $json, $ref_user);
    $video_preview = midas_getVideoPreviewButton($json, $ref_user);
    $preview   = '<div id="midas_img_div" name="midas_img_div"><div id="midas_img_wrap" name="midas_img_wrap"><div style="padding-bottom: 10px;">' . $media . '</div><div id="midas_buttons_wrap" name="midas_buttons_wrap">';
    if($live_link != '')
    {
        $preview .= $live_link;
    }
    if($link != '')
    {
        $preview .= '&nbsp;' . $link;
    }
    if($screenshots != '')
    {
        $preview .= '&nbsp;' . $screenshots;
    }
    if($video_preview != '')
    {
        $preview .= '&nbsp;' . $video_preview;
    }
    if($preview3d != '')
    {
        $preview .= '&nbsp;' . $preview3d;
    }
    $preview .= '</div></div><p><span style="margin-left: 10px;"><b>Author: ' . $json['user'] . '</b></span><span style="display: block;float: right;margin-right: 10px;"><b>Price: $' . $json['cost'] . '</b></span></p></div><br/>';
    return $preview;
}

function midas_getThumbnail($marketplace, $json, $ref_user)
{
    $media     = midas_getItemImageOrMedia($marketplace, $json, $ref_user, true);
    
    $preview   = '<ul class="midas_enlarge"><li><img src="' . $json['thumbnail'] . '" alt="thumbnail" /><span>' . $media . '<a href="' . $json['url'] . '?ref=' . $ref_user . '" target="_blank" style="text-decoration:none;"><table cellspacing="0" cellpadding="0" style="margin-bottom:0px;border: none;"><tr><td style="border: none;"><div style="color:white;font-size: 1.5em;text-align:left;"><b>' . $json['item'] . '</b></div></td><td style="border: none;vertical-align:middle;text-align:center;width:15%;" rowspan="3"><div style="color:white;"><div style="float:left;font-size: 2.3em;"><b>$' . str_replace(".00", "", $json['cost']) . '</div></b></div></td></tr><tr><td style="border: none;"><div style="color:#111;text-align:left;">by: ' . $json['user'] . '</div></td></tr><tr><td style="border: none;"><div style="color:#aaa;text-align:left;">' . $json['category'] . '</div></td></tr></table></a></span></li></ul>';
    return $preview;
}

register_activation_hook(__FILE__, 'midas_activation_callback');
function midas_activation_callback($defaults = FALSE)
{
    if (!get_option('midas_Main_Settings') || $defaults === TRUE) {
        $midas_Main_Settings = array(
            'midas_enabled' => 'on',
            'auto_update_posts' => 'No',
            'submit_status' => 'publish',
            'default_category' => 'midas_no_category_12345678',
            'default_type' => 'post',
            'default_tags' => '',
            'user_name' => '',
            'auto_categories' => '',
            'auto_tags' => '',
            'auto_image' => '',
            'enable_comments' => '',
            'auto_generate_comments' => '0',
            'auto_generate_comments_user' => '0',
            'auto_generate_comments_featured' => '0',
            'auto_generate_comments_popular' => '0',
            'auto_generate_comments_random' => '0',
            'auto_generate_comments_manual' => '0',
            'post_user_name' => '',
            'links_add_ref' => '',
            'links_hide' => '',
            'apiKey' => '',
            'post_title' => '%%item_title%%',
            'post_content' => '%%generate_item_intro%% %%item_description%%',
            'post_title_user' => '%%item_title%%',
            'post_content_user' => '%%generate_item_intro%% %%item_description%%',
            'post_title_popular' => '%%item_title%%',
            'post_content_popular' => '%%generate_item_intro%% %%item_description%%',
            'post_title_random' => '%%item_title%%',
            'post_content_random' => '%%generate_item_intro%% %%item_description%%',
            'post_title_featured' => '%%item_title%%',
            'post_content_featured' => '%%generate_item_intro%% %%item_description%%',
            'post_title_manual' => '%%item_title%%',
            'post_content_manual' => '%%generate_item_intro%% %%item_description%%',
            'enable_metabox' => 'on',
            'submit_status_user' => 'publish',
            'default_category_user' => 'midas_no_category_12345678',
            'default_type_user' => 'post',
            'default_tags_user' => '',
            'auto_categories_user' => '',
            'auto_tags_user' => '',
            'auto_image_user' => '',
            'enable_comments_user' => '',
            'post_user_name_user' => '',
            'submit_status_popular' => 'publish',
            'default_category_popular' => 'midas_no_category_12345678',
            'default_type_popular' => 'post',
            'default_tags_popular' => '',
            'auto_categories_popular' => '',
            'auto_tags_popular' => '',
            'auto_image_popular' => '',
            'enable_comments_popular' => '',
            'post_user_name_popular' => '',
            'submit_status_random' => 'publish',
            'default_category_random' => 'midas_no_category_12345678',
            'default_type_random' => 'post',
            'default_tags_random' => '',
            'auto_categories_random' => '',
            'auto_tags_random' => '',
            'auto_image_random' => '',
            'enable_comments_random' => '',
            'post_user_name_random' => '',
            'submit_status_featured' => 'publish',
            'default_category_featured' => 'midas_no_category_12345678',
            'default_type_featured' => 'post',
            'default_tags_featured' => '',
            'auto_categories_featured' => '',
            'auto_tags_featured' => '',
            'auto_image_featured' => '',
            'enable_comments_featured' => '',
            'post_user_name_featured' => '',
            'submit_status_manual' => 'publish',
            'default_category_manual' => 'midas_no_category_12345678',
            'default_type_manual' => 'post',
            'default_tags_manual' => '',
            'auto_categories_manual' => '',
            'auto_tags_manual' => '',
            'auto_image_manual' => '',
            'enable_comments_manual' => '',
            'post_user_name_manual' => '',
            'submit_status_grouped' => 'publish',
            'default_category_grouped' => 'midas_no_category_12345678',
            'default_type_grouped' => 'post',
            'default_tags_grouped' => '',
            'auto_categories_grouped' => '',
            'auto_tags_grouped' => '',
            'auto_image_grouped' => '',
            'enable_comments_grouped' => '',
            'enable_logging' => 'on',
            'enable_detailed_logging' => '',
            'auto_clear_logs' => 'weekly',
            'post_user_name_grouped' => '',
            'featured_image_default' => '',
            'featured_image_user' => '',
            'featured_image_featured' => '',
            'featured_image_random' => '',
            'featured_image_popular' => '',
            'featured_image_manual' => '',
            'featured_image_grouped' => '',
            'rule_timeout' => '3600',
            'sentence_list' => 'This is one %adjective %noun %sentence_ending
This is another %adjective %noun %sentence_ending
I %love_it %nouns , because they are %adjective %sentence_ending
My %family says this plugin is %adjective %sentence_ending
These %nouns are %adjective %sentence_ending',
            'sentence_list2' => 'Meet this %adjective %noun %sentence_ending
This is the %adjective %noun ever%sentence_ending
I %love_it %nouns , because they are the %adjective %sentence_ending
My %family says this plugin is very %adjective %sentence_ending
These %nouns are quite %adjective %sentence_ending',
            'variable_list' => 'adjective_very => %adjective;very %adjective;

adjective => clever;interesting;smart;huge;astonishing;unbelievable;nice;adorable;beautiful;elegant;fancy;glamorous;magnificent;helpful;awesome

noun_with_adjective => %noun;%adjective %noun

noun => plugin;WordPress plugin;item;ingredient;component;constituent;module;add-on;plug-in;addon;extension

nouns => plugins;WordPress plugins;items;ingredients;components;constituents;modules;add-ons;plug-ins;addons;extensions

love_it => love;adore;like;be mad for;be wild about;be nuts about;be crazy about

family => %adjective %family_members;%family_members

family_members => grandpa;brother;sister;mom;dad;grandma

sentence_ending => .;!;!!'
        );
        if($defaults === FALSE)
        {
            add_option('midas_Main_Settings', $midas_Main_Settings);
        }
        else
        {
            update_option('midas_Main_Settings', $midas_Main_Settings);
        }
    }
}

register_activation_hook(__FILE__, 'midas_check_version');
function midas_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.0';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
    
    //alter deprecated.php - remove hardcoded timeout
    $file2 = ABSPATH . '/wp-includes/deprecated.php';
    if (file_exists($file2)) {
        $text2 = file_get_contents($file2);
    } else {
        $text2 = "";
    }
    if($text2 != "" && $text2 !== FALSE)
    {
        if (strpos($text2, '@set_time_limit( 60 );') !== false) {
            $text2 = str_replace('@set_time_limit( 60 );', '//@set_time_limit(60);', $text2);
            $rez = file_put_contents($file2, $text2);
            if($rez === FALSE)
            {
                midas_log_to_file("[CRITICAL] Failed to update deprecated.php!", '0', 7, '1');
            }
        }
    }
    //same for wp-config
    /*
    $file3 = ABSPATH . '/wp-config.php';
    if (file_exists($file3)) {
        $text3 = file_get_contents($file3);
    } else {
        $text3 = "";
    }
    if($text3 != "" && $text3 !== FALSE)
    {
        if (strpos($text3, '@set_time_limit(0);') === FALSE) {
            $text3 = '@set_time_limit(0);';
            $rez = file_put_contents($file3, $text3, FILE_APPEND);
            if($rez === FALSE)
            {
                midas_log_to_file("[CRITICAL] Failed to update wp-config.php!", '0', 7, '1');
            }
        }
    }
    */
}

add_action('admin_init', 'midas_register_mysettings');
function midas_register_mysettings()
{
    register_setting('midas_option_group', 'midas_Main_Settings');
}

function midas_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function midas_get_file_url($url)
{
    return midas_get_plugin_url() . '/' . $url;
}

add_action('admin_enqueue_scripts', 'midas_admin_load_files');
function midas_admin_load_files()
{
    wp_register_style('midas-browser-style', plugins_url('styles/midas-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('midas-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('midas-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('midas-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('midas-settings-app', plugins_url('res/midas-angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('midas-ajax-app', plugins_url('res/midas-my-action-callback.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
    wp_enqueue_style('thickbox');
}

add_action('wp_enqueue_scripts', 'midas_wp_load_files');
function midas_wp_load_files()
{
    wp_enqueue_style( 'midas_jplayer_css', plugins_url('res/jplayer/jplayer.css', __FILE__) );
    wp_enqueue_style( 'midas_fancybox_css', plugins_url('res/fancybox/jquery.fancybox.css', __FILE__) );
    wp_enqueue_script('midas_fancybox', plugins_url('res/fancybox/jquery.fancybox.pack.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('midas_fancybox_init', plugins_url('res/fancybox_init.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('midas_jplayer', plugins_url('res/jplayer/jplayer.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_style( 'midas_thumbnail_css', plugins_url('styles/midas-thumbnail.css', __FILE__) );
}

function midas_random_sentence_generator($first = true)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if($first == false)
    {
        $r_sentences = $midas_Main_Settings['sentence_list2'];
    }
    else
    {
        $r_sentences = $midas_Main_Settings['sentence_list'];
    }
    $r_variables = $midas_Main_Settings['variable_list'];
    $r_sentences = trim($r_sentences);
    $r_variables = trim($r_variables, ';');
    $r_variables = trim($r_variables);
    $r_sentences = str_replace("\r\n", "\n", $r_sentences);
    $r_sentences = str_replace("\r", "\n", $r_sentences);
    $r_sentences = explode("\n", $r_sentences);
    $r_variables = str_replace("\r\n", "\n", $r_variables);
    $r_variables = str_replace("\r", "\n", $r_variables);
    $r_variables = explode("\n", $r_variables);
    $r_vars = array();
    for($x=0; $x < count($r_variables); $x++){
        $var = explode("=>", trim($r_variables[$x]));
        if(isset($var[1]))
        {
            $key = strtolower(trim($var[0]));
            $words = explode(";", trim($var[1]));
            $r_vars[$key] = $words;
        }
    }
    $max_s = count($r_sentences)-1;
    $rand_s = rand(0, $max_s);
    $sentence = $r_sentences[$rand_s];
    $sentence = str_replace(' ,', ',', ucfirst(midas_replace_words($sentence, $r_vars)));
    $sentence = str_replace(' .', '.', $sentence);
    $sentence = str_replace(' !', '!', $sentence);
    $sentence = str_replace(' ?', '?', $sentence);
    $sentence = trim($sentence);
    return $sentence;
}

function midas_get_word($key, $r_vars){
    if (isset($r_vars[$key])){
 
        $words = $r_vars[$key];
        $w_max = count($words)-1;
        $w_rand = rand(0, $w_max);
        return midas_replace_words(trim($words[$w_rand]), $r_vars);
    }
    else {
        return "";
    }
 
}

function midas_replace_words($sentence, $r_vars){
 
    if (str_replace('%', '', $sentence) == $sentence)
        return $sentence;
 
    $words = explode(" ", $sentence);
 
    $new_sentence = array();
    for($w=0; $w < count($words); $w++){
 
        $word = trim($words[$w]);
 
        if ($word != ''){
            if (preg_match('/^%(.*)$/', $word, $m)){
                $varkey = trim($m[1]);
                $new_sentence[] = midas_get_word($varkey, $r_vars);
            }
            else {
                $new_sentence[] = $word;
            }
        }
    }
    return implode(" ", $new_sentence);    
}

require(dirname(__FILE__) . "/res/midas-main.php");
require(dirname(__FILE__) . "/res/midas-newest-post-rules.php");
require(dirname(__FILE__) . "/res/midas-newest-user.php");
require(dirname(__FILE__) . "/res/midas-popular-items.php");
require(dirname(__FILE__) . "/res/midas-random-items.php");
require(dirname(__FILE__) . "/res/midas-featured-items.php");
require(dirname(__FILE__) . "/res/midas-manual-items.php");
require(dirname(__FILE__) . "/res/midas-group-items.php");
require(dirname(__FILE__) . "/res/midas-logs.php");
?>