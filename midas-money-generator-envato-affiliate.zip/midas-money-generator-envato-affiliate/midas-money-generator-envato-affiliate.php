<?php
/** 
Plugin Name: Hand of Midas - Envato Affiliate Money Generator Plugin
Plugin URI: http://codecanyon.net/user/coderevolution/portfolio
Description: This plugin will generate money for you, even in your sleep.
Author: CodeRevolution
Version: 1.0
Author URI: https://codecanyon.net/user/coderevolution
*/

require "update-checker/plugin-update-checker.php";
$fwdu3dcarPUC = PucFactory::buildUpdateChecker("https://rawgit.com/sfatfarma/midas/master/info.json", __FILE__, "midas-money-generator-envato-affiliate");
add_action('admin_menu', 'midas_register_my_custom_menu_page');
function midas_register_my_custom_menu_page()
{
    add_menu_page('Hand of Midas Envato Affiliate', 'Hand of Midas Envato Affiliate', 'manage_options', 'midas_admin_settings', 'midas_admin_settings', plugins_url('images/icon.png', __FILE__));
    add_submenu_page('midas_admin_settings', 'Main Settings', 'Main Settings', 'manage_options', 'midas_admin_settings');
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
        add_submenu_page('midas_admin_settings', 'Newest Market Item Rules', 'Newest Market Item Rules', 'manage_options', 'midas_newest_post_rules', 'midas_newest_post_rules');
        add_submenu_page('midas_admin_settings', 'New Items From User Rules', 'New Items From User Rules', 'manage_options', 'midas_newest_user', 'midas_newest_user');
        add_submenu_page('midas_admin_settings', 'New Items From Popular Items', 'New Items From Popular Items', 'manage_options', 'midas_popular_items', 'midas_popular_items');
        add_submenu_page('midas_admin_settings', 'New Items From Random Items', 'New Items From Random Items', 'manage_options', 'midas_random_items', 'midas_random_items');
        add_submenu_page('midas_admin_settings', 'New Items From Featured Items', 'New Items From Featured Items', 'manage_options', 'midas_featured_items', 'midas_featured_items');
        add_submenu_page('midas_admin_settings', 'New Items From Manual IDs', 'New Items From Manual IDs', 'manage_options', 'midas_manual_items', 'midas_manual_items');
        add_submenu_page('midas_admin_settings', 'New Items From Grouped IDs', 'New Items From Grouped IDs', 'manage_options', 'midas_group_items', 'midas_group_items');
    }
}
$plugin = plugin_basename(__FILE__);
add_filter("plugin_action_links_$plugin", 'midas_add_settings_link');
function midas_add_settings_link($links)
{
    $settings_link = '<a href="admin.php?page=midas_admin_settings">' . __('Settings') . '</a>';
    array_push($links, $settings_link);
    return $links;
}
add_action('add_meta_boxes', 'midas_add_meta_box');
function midas_add_meta_box()
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] === 'on') {
        if (isset($midas_Main_Settings['enable_metabox']) && $midas_Main_Settings['enable_metabox'] == 'on') {
            add_meta_box('midas_meta_box_function_add', 'Hand of Midas Auto Generated Post Information', 'midas_meta_box_function', 'post', 'advanced', 'default');
            add_meta_box('midas_meta_box_function_add', 'Hand of Midas Auto Generated Post Information', 'midas_meta_box_function', 'page', 'advanced', 'default');
        }
    }
}

function midas_meta_box_function($post)
{
    $post_creator_last_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
    $post_item_id              = get_post_meta($post->ID, 'post_item_id', true);
    $post_parent_rule          = get_post_meta($post->ID, 'post_parent_rule', true);
    $post_parent_type          = get_post_meta($post->ID, 'post_parent_type', true);
    $post_thumbnail            = get_post_meta($post->ID, 'post_thumbnail', true);
    $post_item_marketplace     = get_post_meta($post->ID, 'post_item_marketplace', true);
    $post_item_url             = get_post_meta($post->ID, 'post_item_url', true);
    $post_item_user            = get_post_meta($post->ID, 'post_item_user', true);
    $post_item_thumbnail       = get_post_meta($post->ID, 'post_item_thumbnail', true);
    $post_item_media_url       = get_post_meta($post->ID, 'post_item_media_url', true);
    $post_item_cost            = get_post_meta($post->ID, 'post_item_cost', true);
    $post_item_uploaded        = get_post_meta($post->ID, 'post_item_uploaded', true);
    $post_item_last_update     = get_post_meta($post->ID, 'post_item_last_update', true);
    $post_item_cats            = get_post_meta($post->ID, 'post_item_cats', true);
    $post_item_tags            = get_post_meta($post->ID, 'post_item_tags', true);
    if (isset($post_item_id) && $post_item_id != '') {
        $ech = '<table><tr><td><b>Item Last Updated:</b></td><td>&nbsp;' . $post_creator_last_updated . '</td></tr>';
        $ech .= '<tr><td><b>Item ID:</b></td><td>&nbsp;' . $post_item_id . '</td></tr>';
        $ech .= '<tr><td><b>Post Created by Rule Type:</b></td><td>&nbsp;';
        if ($post_parent_type == '0') {
            $ech .= 'Newest Market Item Rules';
        } elseif ($post_parent_type == '1') {
            $ech .= 'Newest Items for User Rules';
        } elseif ($post_parent_type == '2') {
            $ech .= 'Newest Items from Popular Feeds';
        } elseif ($post_parent_type == '3') {
            $ech .= 'Newest Items from Random Feeds';
        } elseif ($post_parent_type == '4') {
            $ech .= 'Newest Items from Featured Feeds';
        } elseif ($post_parent_type == '5') {
            $ech .= 'Newest Items from Manula ID Input';
        }
        $ech .= '</td></tr>';
        $ech .= '<tr><td><b>Parent Rule ID:</b></td><td>&nbsp;' . $post_parent_rule . '</td></tr>';
        $ech .= '<tr><td><b>Post Preview Image URL:</b></td><td>&nbsp;' . $post_thumbnail . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Marketplace:</b></td><td>&nbsp;' . $post_item_marketplace . '</td></tr>';
        $ech .= '<tr><td><b>Post Item URL:</b></td><td>&nbsp;' . $post_item_url . '</td></tr>';
        $ech .= '<tr><td><b>Post Item User:</b></td><td>&nbsp;' . $post_item_user . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Thumbnail:</b></td><td>&nbsp;' . $post_item_thumbnail . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Media URL:</b></td><td>&nbsp;' . $post_item_media_url . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Cost:</b></td><td>&nbsp;' . $post_item_cost . '$</td></tr>';
        $ech .= '<tr><td><b>Post Item Upload Date:</b></td><td>&nbsp;' . $post_item_uploaded . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Last Updated Date:</b></td><td>&nbsp;' . $post_item_last_update . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Categories:</b></td><td>&nbsp;' . $post_item_cats . '</td></tr>';
        $ech .= '<tr><td><b>Post Item Tags:</b></td><td>&nbsp;' . $post_item_tags . '</td></tr>';
        $ech .= '</table><br/>';
    } else {
        $ech = 'This is not an automatically generated post.';
    }
    echo $ech;
}

function midas_debug_to_console($data)
{
    
    if (is_array($data))
        $output = "<script>console.log( 'Debug Objects: " . implode(',', $data) . "' );</script>";
    else
        $output = "<script>console.log( 'Debug Objects: " . $data . "' );</script>";
    
    echo $output;
}
add_filter('cron_schedules', 'midas_add_cron_schedule');
function midas_add_cron_schedule($schedules)
{
    $schedules['midas_cron'] = array(
        'interval' => 3600,
        'display' => __('Midas Cron')
    );
    $schedules['weekly']     = array(
        'interval' => 604800,
        'display' => __('Once Weekly')
    );
    $schedules['monthly']    = array(
        'interval' => 2592000,
        'display' => __('Once Monthly')
    );
    return $schedules;
}
midas_cron_schedule();
function midas_cron_schedule()
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] === 'on') {
        add_action('midasaction', 'midas_cron');
        if (!wp_next_scheduled('midasaction')) {
            wp_schedule_event(time(), 'midas_cron', 'midasaction');
        }
    } else {
        if (wp_next_scheduled('midasaction')) {
            wp_clear_scheduled_hook('midasaction');
        }
    }
}
function midas_cron()
{
    if (!get_option('midas_rules_list')) {
        $rules = array();
    } else {
        $rules = get_option('midas_rules_list');
    }
    if (!empty($rules)) {
        $cont = 0;
        foreach ($rules as $request => $bundle[]) {
            $bundle_values   = array_values($bundle);
            $myValues        = $bundle_values[$cont];
            $array_my_values = array_values($myValues);
            $market          = $array_my_values[0];
            $schedule        = $array_my_values[1];
            $max             = $array_my_values[2];
            $active          = $array_my_values[3];
            $last_run        = $array_my_values[4];
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 0);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_user_rules_list')) {
        $rules2 = array();
    } else {
        $rules2 = get_option('midas_user_rules_list');
    }
    if (!empty($rules2)) {
        $cont = 0;
        foreach ($rules2 as $request2 => $bundle2[]) {
            $bundle_values2   = array_values($bundle2);
            $myValues2        = $bundle_values2[$cont];
            $array_my_values2 = array_values($myValues2);
            $user             = $array_my_values2[0];
            $market           = $array_my_values2[1];
            $schedule         = $array_my_values2[2];
            $max              = $array_my_values2[3];
            $active           = $array_my_values2[4];
            $last_run         = $array_my_values2[5];
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 1);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_popular')) {
        $rules3 = array();
    } else {
        $rules3 = get_option('midas_rules_list_popular');
    }
    if (!empty($rules3)) {
        $cont = 0;
        foreach ($rules3 as $request3 => $bundle3[]) {
            $bundle_values3   = array_values($bundle3);
            $myValues3        = $bundle_values3[$cont];
            $array_my_values3 = array_values($myValues3);
            $market           = $array_my_values3[0];
            $schedule         = $array_my_values3[1];
            $max              = $array_my_values3[2];
            $active           = $array_my_values3[3];
            $last_run         = $array_my_values3[4];
            $type             = $array_my_values3[5];
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 2);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_random')) {
        $rules4 = array();
    } else {
        $rules4 = get_option('midas_rules_list_random');
    }
    if (!empty($rules4)) {
        $cont = 0;
        foreach ($rules4 as $request4 => $bundle4[]) {
            $bundle_values4   = array_values($bundle4);
            $myValues4        = $bundle_values4[$cont];
            $array_my_values4 = array_values($myValues4);
            $market           = $array_my_values4[0];
            $schedule         = $array_my_values4[1];
            $max              = $array_my_values4[2];
            $active           = $array_my_values4[3];
            $last_run         = $array_my_values4[4];
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 3);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_featured')) {
        $rules5 = array();
    } else {
        $rules5 = get_option('midas_rules_list_featured');
    }
    if (!empty($rules5)) {
        $cont = 0;
        foreach ($rules5 as $request5 => $bundle5[]) {
            $bundle_values5   = array_values($bundle5);
            $myValues5        = $bundle_values5[$cont];
            $array_my_values5 = array_values($myValues5);
            $market           = $array_my_values5[0];
            $schedule         = $array_my_values5[1];
            $max              = $array_my_values5[2];
            $active           = $array_my_values5[3];
            $last_run         = $array_my_values5[4];
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 4);
                }
            }
            $cont = $cont + 1;
        }
    }
    if (!get_option('midas_rules_list_manual')) {
        $rules6 = array();
    } else {
        $rules6 = get_option('midas_rules_list_manual');
    }
    if (!empty($rules6)) {
        $cont = 0;
        foreach ($rules6 as $request6 => $bundle6[]) {
            $bundle_values6   = array_values($bundle6);
            $myValues6        = $bundle_values6[$cont];
            $array_my_values6 = array_values($myValues6);
            $ids              = $array_my_values6[0];
            $schedule         = $array_my_values6[1];
            $active           = $array_my_values6[2];
            $last_run         = $array_my_values6[3];
            
            if ($active == '1') {
                $now             = midas_get_date_now();
                $nextrun         = midas_add_hour($last_run, $schedule);
                $midas_hour_diff = (int) midas_hour_diff($now, $nextrun);
                if ($midas_hour_diff >= 0) {
                    midas_run_rule($cont, 5);
                }
            }
            $cont = $cont + 1;
        }
    }
}
function midas_add_ajaxurl()
{
    
    echo '<script type="text/javascript">
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
        </script>';
}
add_action('wp_head', 'midas_add_ajaxurl');
add_action('wp_ajax_midas_my_action', 'midas_my_action_callback');
function midas_my_action_callback()
{
    $failed       = false;
    $type         = $_POST['type'];
    $del_id       = $_POST['id'];
    $how          = $_POST['how'];
    $force_delete = true;
    if ($how == 'trash') {
        $force_delete = false;
    }
    $query     = array(
        'post_status' => array(
            'any'
        ),
        'post_type' => array(
            'any'
        ),
        'numberposts' => -1
    );
    $post_list = get_posts($query);
    foreach ($post_list as $post) {
        $index       = get_post_meta($post->ID, 'post_parent_rule', true);
        $parent_type = get_post_meta($post->ID, 'post_parent_type', true);
        if ($index == $del_id && $parent_type == $type) {
            $res = wp_delete_post($post->ID, $force_delete);
            if ($res === false) {
                $failed = true;
            }
        }
    }
    if ($failed === true) {
        echo 'failed';
    } else {
        echo 'ok';
    }
    die();
}
add_action('wp_ajax_midas_run_my_action', 'midas_run_my_action_callback');
function midas_run_my_action_callback()
{
    $run_id = $_POST['id'];
    $type   = $_POST['type'];
    echo midas_run_rule($run_id, intval($type));
    die();
}

function midas_get_xml_value($xml, $field)
{
    if (!empty($xml->childNodes)) {
        foreach ($xml->childNodes as $xmlChild) {
            if ($xmlChild->nodeName == $field) {
                return $xmlChild->nodeValue;
            }
        }
    }
    return '';
}
add_action('wp_head', 'midas_head');

function midas_head()
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
        if (isset($midas_Main_Settings['links_add_ref']) && $midas_Main_Settings['links_add_ref'] !== 'none') {
            if ($midas_Main_Settings['links_add_ref'] == 'all') {
                
                add_filter('comment_author_link', 'midas_add_affiliate_link');
                add_filter('comment_author_text', 'midas_add_affiliate_link');
                add_filter('comment_author_text_rss', 'midas_add_affiliate_link');
                add_filter('the_excerpt', 'midas_add_affiliate_link');
                add_filter('the_excerpt_rss', 'midas_add_affiliate_link');
                add_filter('the_content', 'midas_add_affiliate_link');
                add_filter('the_content_rss', 'midas_add_affiliate_link');
                add_filter('the_meta_key', 'midas_add_affiliate_link');
                
            } else if ($midas_Main_Settings['links_add_ref'] == 'meta') {
                
                add_filter('the_excerpt', 'midas_add_affiliate_link');
                add_filter('the_excerpt_rss', 'midas_add_affiliate_link');
                add_filter('the_content', 'midas_add_affiliate_link');
                add_filter('the_content_rss', 'midas_add_affiliate_link');
                add_filter('the_meta_key', 'midas_add_affiliate_link');
                
            } else if ($midas_Main_Settings['links_add_ref'] == 'post') {
                
                add_filter('the_content', 'midas_add_affiliate_link');
                add_filter('the_content_rss', 'midas_add_affiliate_link');
                add_filter('the_meta_key', 'midas_add_affiliate_link');
                
            }
        }
        add_filter('the_content', 'midas_add_affiliate_keyword');
    }
}

function midas_add_affiliate_link($content)
{
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    
    preg_match_all('/((http(s?):\/\/(www\.)?)|(www\.))(photodune|codecanyon|themeforest|audiojungle|videohive|graphicriver|3docean|marketplace\.tutsplus)\.([a-zA-Z0-9:\/=+_-]+)(\?[a-zA-Z0-9\?.&#;:\/=+_-]+)?/i', $content, $matches);
    
    foreach (array_unique($matches[0]) as $key => $match) {
        
        $new_url = 'http' . $matches[3][$key] . '://' . $matches[4][$key] . $matches[5][$key] . $matches[6][$key] . '.' . $matches[7][$key] . '?ref=' . $midas_Main_Settings['user_name'];
        
        $content = str_replace($match, midas_url_handle($new_url), $content);
        
    }
    
    return $content;
    
}

function midas_add_affiliate_keyword($content)
{
    $rules  = get_option('midas_keyword_list');
    $output = '';
    if (!empty($rules)) {
        foreach ($rules as $request => $value) {
            $content = preg_replace('\'(?!((<.*?)|(<a.*?)))(\b' . $request . '\b)(?!(([^<>]*?)>)|([^>]*?</a>))\'i', '<a href="' . $value . '" target="_blank">' . $request . '</a>', $content);
        }
    }
    return $content;
}

function midas_url_handle($href)
{
    
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    $envatocash_google_key = get_option('envatocash-google-key');
    if (isset($midas_Main_Settings['links_hide']) && $midas_Main_Settings['links_hide'] == 'on') {
        $cloak_urls = true;
    } else {
        $cloak_urls = false;
    }
    if (isset($midas_Main_Settings['apiKey'])) {
        $apiKey = $midas_Main_Settings['apiKey'];
    } else {
        $apiKey = '';
    }
    if ($cloak_urls == true && $apiKey != '') {
        $longUrl  = trim($href);
        $postData = array(
            'longUrl' => $longUrl,
            'key' => $apiKey
        );
        $jsonData = json_encode($postData);
        $curlObj  = curl_init();
        curl_setopt($curlObj, CURLOPT_TIMEOUT_MS, 600000); //in miliseconds
        curl_setopt($curlObj, CURLOPT_URL, 'https://www.googleapis.com/urlshortener/v1/url?key=' . $apiKey);
        curl_setopt($curlObj, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlObj, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curlObj, CURLOPT_HEADER, 0);
        curl_setopt($curlObj, CURLOPT_HTTPHEADER, array(
            'Content-type:application/json'
        ));
        curl_setopt($curlObj, CURLOPT_POST, 1);
        curl_setopt($curlObj, CURLOPT_POSTFIELDS, $jsonData);
        $response = curl_exec($curlObj);
        $json     = json_decode($response);
        curl_close($curlObj);
        if (!isset($json->id) || $json->id == '') {
            return $href;
        } else {
            return $json->id;
        }
    } else {
        return $href;
    }
}


function midas_run_rule($param, $type = 0)
{
    @ini_set('max_execution_time', 0);
    @ini_set('user_agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    ignore_user_abort(true);
    set_time_limit(0);
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled']) && $midas_Main_Settings['midas_enabled'] == 'on') {
        try {
            $item_img     = '';
            $cont         = 0;
            $found        = 0;
            $user_name    = '';
            $marketplace  = '';
            $ids          = '';
            $schedule     = '';
            $max          = PHP_INT_MAX;
            $active       = 'off';
            $last_run     = '';
            $ruleType     = 'week';
            $first        = false;
            $others       = array();
            $post_title   = '';
            $post_content = '';
            $list_item    = '';
            if (!get_option('midas_running_list')) {
                $running = array();
            } else {
                $running = get_option('midas_running_list');
            }
            if (!empty($running)) {
                if (in_array(array(
                    $param => $type
                ), $running)) {
                    return 'fail';
                }
            }
            $running[] = array(
                $param => $type
            );
            update_option('midas_running_list', $running);
            if (isset($midas_Main_Settings['user_name'])) {
                $envato_username = $midas_Main_Settings['user_name'];
            } else {
                $envato_username = '';
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['submit_status'])) {
                    $post_status = $midas_Main_Settings['submit_status'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['submit_status_user'])) {
                    $post_status = $midas_Main_Settings['submit_status_user'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['submit_status_popular'])) {
                    $post_status = $midas_Main_Settings['submit_status_popular'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['submit_status_random'])) {
                    $post_status = $midas_Main_Settings['submit_status_random'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['submit_status_featured'])) {
                    $post_status = $midas_Main_Settings['submit_status_featured'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['submit_status_manual'])) {
                    $post_status = $midas_Main_Settings['submit_status_manual'];
                } else {
                    $post_status = 'publish';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['submit_status_grouped'])) {
                    $post_status = $midas_Main_Settings['submit_status_grouped'];
                } else {
                    $post_status = 'publish';
                }
            } else {
                if (isset($midas_Main_Settings['submit_status'])) {
                    $post_status = $midas_Main_Settings['submit_status'];
                } else {
                    $post_status = 'publish';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['default_type'])) {
                    $post_type = $midas_Main_Settings['default_type'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['default_type_user'])) {
                    $post_type = $midas_Main_Settings['default_type_user'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['default_type_popular'])) {
                    $post_type = $midas_Main_Settings['default_type_popular'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['default_type_random'])) {
                    $post_type = $midas_Main_Settings['default_type_random'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['default_type_featured'])) {
                    $post_type = $midas_Main_Settings['default_type_featured'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['default_type_manual'])) {
                    $post_type = $midas_Main_Settings['default_type_manual'];
                } else {
                    $post_type = 'post';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['default_type_grouped'])) {
                    $post_type = $midas_Main_Settings['default_type_grouped'];
                } else {
                    $post_type = 'post';
                }
            } else {
                if (isset($midas_Main_Settings['default_type'])) {
                    $post_type = $midas_Main_Settings['default_type'];
                } else {
                    $post_type = 'post';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['enable_comments']) && $midas_Main_Settings['enable_comments'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['enable_comments_user']) && $midas_Main_Settings['enable_comments_user'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['enable_comments_popular']) && $midas_Main_Settings['enable_comments_popular'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['enable_comments_random']) && $midas_Main_Settings['enable_comments_random'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['enable_comments_featured']) && $midas_Main_Settings['enable_comments_featured'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['enable_comments_manual']) && $midas_Main_Settings['enable_comments_manual'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['enable_comments_grouped']) && $midas_Main_Settings['enable_comments_grouped'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            } else {
                if (isset($midas_Main_Settings['enable_comments']) && $midas_Main_Settings['enable_comments'] == 'on') {
                    $accept_comments = 'open';
                } else {
                    $accept_comments = 'closed';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['post_user_name'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['post_user_name_user'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_user'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['post_user_name_popular'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_popular'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['post_user_name_random'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_random'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['post_user_name_featured'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_featured'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['post_user_name_manual'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_manual'];
                } else {
                    $post_user_name = 1;
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['post_user_name_grouped'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name_grouped'];
                } else {
                    $post_user_name = 1;
                }
            } else {
                if (isset($midas_Main_Settings['post_user_name'])) {
                    $post_user_name = $midas_Main_Settings['post_user_name'];
                } else {
                    $post_user_name = 1;
                }
            }
            
            if ($type == 0) {
                if (isset($midas_Main_Settings['auto_categories'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['auto_categories_user'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_user'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['auto_categories_popular'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_popular'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['auto_categories_random'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_random'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['auto_categories_featured'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_featured'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['auto_categories_manual'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_manual'];
                } else {
                    $can_create_cat = 'off';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['auto_categories_grouped'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories_grouped'];
                } else {
                    $can_create_cat = 'off';
                }
            } else {
                if (isset($midas_Main_Settings['auto_categories'])) {
                    $can_create_cat = $midas_Main_Settings['auto_categories'];
                } else {
                    $can_create_cat = 'off';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['default_tags'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['default_tags_user'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_user'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['default_tags_popular'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_popular'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['default_tags_random'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_random'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['default_tags_featured'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_featured'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['default_tags_manual'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_manual'];
                } else {
                    $item_create_tag = '';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['default_tags_grouped'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags_grouped'];
                } else {
                    $item_create_tag = '';
                }
            } else {
                if (isset($midas_Main_Settings['default_tags'])) {
                    $item_create_tag = $midas_Main_Settings['default_tags'];
                } else {
                    $item_create_tag = '';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['auto_image'])) {
                    $auto_image = $midas_Main_Settings['auto_image'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['auto_image_user'])) {
                    $auto_image = $midas_Main_Settings['auto_image_user'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['auto_image_popular'])) {
                    $auto_image = $midas_Main_Settings['auto_image_popular'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['auto_image_random'])) {
                    $auto_image = $midas_Main_Settings['auto_image_random'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['auto_image_featured'])) {
                    $auto_image = $midas_Main_Settings['auto_image_featured'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['auto_image_manual'])) {
                    $auto_image = $midas_Main_Settings['auto_image_manual'];
                } else {
                    $auto_image = '';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['auto_image_grouped'])) {
                    $auto_image = $midas_Main_Settings['auto_image_grouped'];
                } else {
                    $auto_image = '';
                }
            } else {
                if (isset($midas_Main_Settings['auto_image'])) {
                    $auto_image = $midas_Main_Settings['auto_image'];
                } else {
                    $auto_image = '';
                }
            }
            if ($type == 0) {
                if (isset($midas_Main_Settings['auto_tags'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 1) {
                if (isset($midas_Main_Settings['auto_tags_user'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_user'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 2) {
                if (isset($midas_Main_Settings['auto_tags_popular'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_popular'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 3) {
                if (isset($midas_Main_Settings['auto_tags_random'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_random'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 4) {
                if (isset($midas_Main_Settings['auto_tags_featured'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_featured'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 5) {
                if (isset($midas_Main_Settings['auto_tags_manual'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_manual'];
                } else {
                    $can_create_tag = 'off';
                }
            } elseif ($type == 6) {
                if (isset($midas_Main_Settings['auto_tags_grouped'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags_grouped'];
                } else {
                    $can_create_tag = 'off';
                }
            } else {
                if (isset($midas_Main_Settings['auto_tags'])) {
                    $can_create_tag = $midas_Main_Settings['auto_tags'];
                } else {
                    $can_create_tag = 'off';
                }
            }
            if ($type == 0) {
                if (!get_option('midas_rules_list')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = $array_my_values[0];
                            $schedule        = $array_my_values[1];
                            $max             = $array_my_values[2];
                            $active          = $array_my_values[3];
                            $last_run        = $array_my_values[4];
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($found == 0) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list', $rules);
                }
                $feed_uri = $marketplace;
            } elseif ($type == 1) {
                if (!get_option('midas_user_rules_list')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_user_rules_list');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $user_name       = $array_my_values[0];
                            $marketplace     = $array_my_values[1];
                            $schedule        = $array_my_values[2];
                            $max             = $array_my_values[3];
                            $active          = $array_my_values[4];
                            $last_run        = $array_my_values[5];
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($found == 0) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $user_name;
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_user_rules_list', $rules);
                }
                $feed_uri = 'https://' . $marketplace . '.net/feeds/users/' . $user_name . '.atom';
            } elseif ($type == 2) {
                if (!get_option('midas_rules_list_popular')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_popular');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = $array_my_values[0];
                            $schedule        = $array_my_values[1];
                            $max             = $array_my_values[2];
                            $active          = $array_my_values[3];
                            $last_run        = $array_my_values[4];
                            $ruleType        = $array_my_values[5];
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($found == 0) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $new_bundle[]  = $ruleType;
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_popular', $rules);
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/popular:' . $marketplace . '.json';
            } elseif ($type == 3) {
                if (!get_option('midas_rules_list_random')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_random');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = $array_my_values[0];
                            $schedule        = $array_my_values[1];
                            $max             = $array_my_values[2];
                            $active          = $array_my_values[3];
                            $last_run        = $array_my_values[4];
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($found == 0) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_random', $rules);
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/random-new-files:' . $marketplace . '.json';
            } elseif ($type == 4) {
                if (!get_option('midas_rules_list_featured')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_featured');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $marketplace     = $array_my_values[0];
                            $schedule        = $array_my_values[1];
                            $max             = $array_my_values[2];
                            $active          = $array_my_values[3];
                            $last_run        = $array_my_values[4];
                            $ruleType        = $array_my_values[5];
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($found == 0) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $marketplace;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $max;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $new_bundle[]  = $ruleType;
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_featured', $rules);
                }
                $feed_uri = 'https://marketplace.envato.com/api/edge/features:' . $marketplace . '.json';
            } elseif ($type == 5) {
                if (!get_option('midas_rules_list_manual')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_manual');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $ids             = $array_my_values[0];
                            $schedule        = $array_my_values[1];
                            $active          = $array_my_values[2];
                            $last_run        = $array_my_values[3];
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($found == 0) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $ids;
                    $new_bundle[]  = $schedule;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_manual', $rules);
                }
                $arr_ids = explode(",", $ids);
                foreach ($arr_ids as $one_id) {
                    if ($first === false) {
                        $first = trim($one_id);
                    } else {
                        $others[] = trim($one_id);
                    }
                }
                if ($first === false) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $first . '.json';
                $max      = PHP_INT_MAX;
            } elseif ($type == 6) {
                if (!get_option('midas_rules_list_group')) {
                    $rules = array();
                } else {
                    $rules = get_option('midas_rules_list_group');
                }
                if (!empty($rules)) {
                    foreach ($rules as $request => $bundle[]) {
                        if ($cont == $param) {
                            $bundle_values   = array_values($bundle);
                            $myValues        = $bundle_values[$cont];
                            $array_my_values = array_values($myValues);
                            $ids             = $array_my_values[0];
                            $post_title      = $array_my_values[1];
                            $post_content    = $array_my_values[2];
                            $list_item       = $array_my_values[3];
                            $active          = $array_my_values[4];
                            $last_run        = $array_my_values[5];
                            $found           = 1;
                            break;
                        }
                        $cont = $cont + 1;
                    }
                } else {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($found == 0) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                } else {
                    $new_bundle    = array();
                    $new_bundle[]  = $ids;
                    $new_bundle[]  = $post_title;
                    $new_bundle[]  = $post_content;
                    $new_bundle[]  = $list_item;
                    $new_bundle[]  = $active;
                    $new_bundle[]  = midas_get_date_now();
                    $rules[$param] = $new_bundle;
                    update_option('midas_rules_list_group', $rules);
                }
                $arr_ids = explode(",", $ids);
                foreach ($arr_ids as $one_id) {
                    if ($first === false) {
                        $first = trim($one_id);
                    } else {
                        $others[] = trim($one_id);
                    }
                }
                if ($first === false) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $first . '.json';
                $max      = PHP_INT_MAX;
            } else {
                if (($key = array_search(array(
                    $param => $type
                ), $running)) !== false) {
                    unset($running[$key]);
                    update_option('midas_running_list', $running);
                }
                return 'fail';
            }
            $newItems = file_get_contents($feed_uri);
            if ($newItems === false) {
                if (($key = array_search(array(
                    $param => $type
                ), $running)) !== false) {
                    unset($running[$key]);
                    update_option('midas_running_list', $running);
                }
                return 'fail';
            }
            $post_array   = array();
            $posted_items = array();
            $query        = array(
                'post_status' => array(
                    'any'
                ),
                'post_type' => array(
                    'any'
                ),
                'numberposts' => -1
            );
            
            $post_list = get_posts($query);
            foreach ($post_list as $post) {
                $posted_items[] = get_post_meta($post->ID, 'post_item_id', true);
            }
            $counter = 1;
            if ($type == 0 || $type == 1) {
                $content_xml = new DOMDocument();
                if (!$content_xml->loadXML($newItems)) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                foreach ($content_xml->documentElement->childNodes as $item_xml) {
                    if ($counter <= (int) $max) {
                        $title = midas_get_xml_value($item_xml, 'title');
                        if ($title && $title != '') {
                            $content = midas_get_xml_value($item_xml, 'content');
                            $id_text = midas_get_xml_value($item_xml, 'id');
                            $id      = trim(str_replace(':Item/', '', substr($id_text, strpos($id_text, ':Item/'))));
                            $found   = 0;
                            if (in_array($id, $posted_items)) {
                                $found = 1;
                            }
                            if ($found == 0) {
                                $item_info = file_get_contents("https://marketplace.envato.com/api/v3/item:" . $id . ".json");
                                if ($item_info === false) {
                                    continue;
                                }
                                $json = json_decode($item_info, true);
                                if ($json === NULL) {
                                    continue;
                                }
                                $item_media = '';
                                if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                    $item_media = isset($json['item']['preview_url']) ? $json['item']['preview_url'] : '';
                                }
                                if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                    $item_media = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                }
                                //TODO check if these are set, if not, do not query them
                                $item_img                  = isset($json['item']['live_preview_url']) ? $json['item']['live_preview_url'] : '';
                                $item_video                = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                $item_thumb                = $json['item']['thumbnail'];
                                $item_url                  = $json['item']['url'];
                                $item_user                 = $json['item']['user'];
                                $item_cost                 = $json['item']['cost'];
                                $item_cat                  = $json['item']['category'];
                                $item_tags                 = $json['item']['tags'];
                                $item_uploaded             = $json['item']['uploaded_on'];
                                $item_last_update          = $json['item']['last_update'];
                                $just_title                = $json['item']['item'];
                                $item_sales                = $json['item']['sales'];
                                $item_rating               = $json['item']['rating'];
                                $preview_media             = midas_getIntro($marketplace, $json['item'], $envato_username);
                                $my_post                   = array();
                                $my_post['post_type']      = $post_type;
                                $my_post['comment_status'] = $accept_comments;
                                $my_post['post_excerpt']   = midas_getExcerpt($marketplace, $json['item']);
                                $my_post['post_status']    = $post_status;
                                $my_post['post_author']    = $post_user_name;
                                if ($can_create_tag == 'on') {
                                    $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                } else if ($item_create_tag != '') {
                                    $my_post['tags_input'] = $item_create_tag;
                                }
                                $my_post['post_item_id']             = $id;
                                $my_post['post_item_marketplace']    = $marketplace;
                                $my_post['post_item_user']           = $item_user;
                                $my_post['post_item_url']            = $item_url;
                                $my_post['post_item_thumbnail']      = $item_thumb;
                                $my_post['post_item_preview_img']    = $item_img;
                                $my_post['post_item_media_url']      = $item_media;
                                $my_post['post_item_cost']           = $item_cost;
                                $my_post['post_item_uploaded']       = $item_uploaded;
                                $my_post['post_item_cats']           = $item_cat;
                                $my_post['post_item_tags']           = $item_tags;
                                $my_post['market_item_last_updated'] = $item_last_update;
                                if ($type == 0) {
                                    $the_content = $midas_Main_Settings['post_content'];
                                } elseif ($type == 1) {
                                    $the_content = $midas_Main_Settings['post_content_user'];
                                } elseif ($type == 2) {
                                    $the_content = $midas_Main_Settings['post_content_popular'];
                                }
                                
                                if (strpos($the_content, '%%') !== false) {
                                    $the_content = replaceContentShortcodes($the_content, $json['item'], $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                $my_post['post_content'] = $the_content;
                                if ($type == 0) {
                                    $the_title = $midas_Main_Settings['post_title'];
                                } elseif ($type == 1) {
                                    $the_title = $midas_Main_Settings['post_title_user'];
                                } elseif ($type == 2) {
                                    $the_title = $midas_Main_Settings['post_title_popular'];
                                }
                                if (strpos($the_title, '%%') !== false) {
                                    $the_title = replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                $my_post['post_title'] = $the_title;
                                $post_array[]          = $my_post;
                            } else {
                                $item_info = file_get_contents("https://marketplace.envato.com/api/v3/item:" . $id . ".json");
                                if ($item_info === false) {
                                    continue;
                                }
                                $json = json_decode($item_info, true);
                                if ($json === NULL) {
                                    continue;
                                }
                                $item_last_update = $json['item']['last_update'];
                                foreach ($post_list as $post) {
                                    $item_id = get_post_meta($post->ID, 'post_item_id', true);
                                    if ($item_id == $id) {
                                        $item_in_post_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
                                        if ($item_in_post_updated != $item_last_update) {
                                            $item_media = '';
                                            if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                                $item_media = isset($json['item']['preview_url']) ? $json['item']['preview_url'] : '';
                                            }
                                            if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                                $item_media = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                            }
                                            $item_img                  = isset($json['item']['live_preview_url']) ? $json['item']['live_preview_url'] : '';
                                            $item_video                = isset($json['item']['live_preview_video_url']) ? $json['item']['live_preview_video_url'] : '';
                                            $item_thumb                = $json['item']['thumbnail'];
                                            $item_url                  = $json['item']['url'];
                                            $item_user                 = $json['item']['user'];
                                            $item_cost                 = $json['item']['cost'];
                                            $item_cat                  = $json['item']['category'];
                                            $item_tags                 = $json['item']['tags'];
                                            $item_uploaded             = $json['item']['uploaded_on'];
                                            $item_last_update          = $json['item']['last_update'];
                                            $just_title                = $json['item']['item'];
                                            $item_sales                = $json['item']['sales'];
                                            $item_rating               = $json['item']['rating'];
                                            $preview_media             = midas_getIntro($marketplace, $json['item'], $envato_username);
                                            $my_post                   = array();
                                            $my_post['ID']             = $post->ID;
                                            $my_post['post_type']      = $post_type;
                                            $my_post['comment_status'] = $accept_comments;
                                            $my_post['post_excerpt']   = midas_getExcerpt($marketplace, $json['item']);
                                            $my_post['post_status']    = $post_status;
                                            $my_post['post_author']    = $post_user_name;
                                            if ($can_create_tag == 'on') {
                                                $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                            } else if ($item_create_tag != '') {
                                                $my_post['tags_input'] = $item_create_tag;
                                            }
                                            $my_post['post_item_id']             = $id;
                                            $my_post['post_item_marketplace']    = $marketplace;
                                            $my_post['post_item_user']           = $item_user;
                                            $my_post['post_item_url']            = $item_url;
                                            $my_post['post_item_thumbnail']      = $item_thumb;
                                            $my_post['post_item_preview_img']    = $item_img;
                                            $my_post['post_item_media_url']      = $item_media;
                                            $my_post['post_item_cost']           = $item_cost;
                                            $my_post['post_item_uploaded']       = $item_uploaded;
                                            $my_post['post_item_cats']           = $item_cat;
                                            $my_post['post_item_tags']           = $item_tags;
                                            $my_post['market_item_last_updated'] = $item_last_update;
                                            if ($type == 0) {
                                                $the_content = $midas_Main_Settings['post_content'];
                                            } elseif ($type == 1) {
                                                $the_content = $midas_Main_Settings['post_content_user'];
                                            } elseif ($type == 2) {
                                                $the_content = $midas_Main_Settings['post_content_popular'];
                                            }
                                            
                                            if (strpos($the_content, '%%') !== false) {
                                                $the_content = replaceContentShortcodes($the_content, $json['item'], $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            $my_post['post_content'] = $the_content;
                                            if ($type == 0) {
                                                $the_title = $midas_Main_Settings['post_title'];
                                            } elseif ($type == 1) {
                                                $the_title = $midas_Main_Settings['post_title_user'];
                                            } elseif ($type == 2) {
                                                $the_title = $midas_Main_Settings['post_title_popular'];
                                            }
                                            if (strpos($the_title, '%%') !== false) {
                                                $the_title = replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            $my_post['post_title'] = $the_title;
                                            $post_id               = wp_update_post($my_post);
                                            if ($post_id != 0) {
                                                if ($auto_image === 'on') {
                                                    if ($my_post['post_item_preview_img'] != '') {
                                                        midas_generate_featured_image($my_post['post_item_preview_img'], $post_id);
                                                    }
                                                }
                                                updatePostMeta($post_id, $my_post, $param, $type, $envato_username);
                                                
                                                if ($can_create_cat == 'on') {
                                                    $termid = midas_create_terms('category', '0', $my_post['post_item_cats']);
                                                    wp_set_post_terms($post_id, $termid, 'category');
                                                }
                                                if ($type == 0) {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 1) {
                                                    if (isset($midas_Main_Settings['default_category_user']) && $midas_Main_Settings['default_category_user'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_user'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 2) {
                                                    if (isset($midas_Main_Settings['default_category_popular']) && $midas_Main_Settings['default_category_popular'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_popular'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 3) {
                                                    if (isset($midas_Main_Settings['default_category_random']) && $midas_Main_Settings['default_category_random'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_random'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 4) {
                                                    if (isset($midas_Main_Settings['default_category_featured']) && $midas_Main_Settings['default_category_featured'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_featured'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 5) {
                                                    if (isset($midas_Main_Settings['default_category_manual']) && $midas_Main_Settings['default_category_manual'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_manual'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 6) {
                                                    if (isset($midas_Main_Settings['default_category_grouped']) && $midas_Main_Settings['default_category_grouped'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_grouped'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } else {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            $counter++;
                        }
                    }
                }
            } else {
                $feed_json = json_decode($newItems, true);
                if ($feed_json === NULL) {
                    if (($key = array_search(array(
                        $param => $type
                    ), $running)) !== false) {
                        unset($running[$key]);
                        update_option('midas_running_list', $running);
                    }
                    return 'fail';
                }
                if ($type == 2) {
                    $new_json = $feed_json['popular'];
                    if ($ruleType == 'week') {
                        $interest_json = $new_json['items_last_week'];
                    } else {
                        $interest_json = $new_json['items_last_three_months'];
                    }
                } elseif ($type == 3) {
                    $interest_json = array();
                    $new_json      = $feed_json['random-new-files'];
                    foreach ($new_json as $key => $item) {
                        $item_info = file_get_contents("https://marketplace.envato.com/api/v3/item:" . $item['id'] . ".json");
                        if ($item_info === false) {
                            continue;
                        }
                        $json = json_decode($item_info, true);
                        if ($json === NULL) {
                            continue;
                        }
                        $interest_json[] = $json['item'];
                    }
                } elseif ($type == 4) {
                    $interest_json = array();
                    //at the moment (of coding, this json contains only 1 item of these types)
                    if ($ruleType == 'featured') {
                        $interest_json[] = $feed_json['features']['featured_file'];
                    } else {
                        $interest_json[] = $feed_json['features']['free_file'];
                    }
                } elseif ($type == 5) {
                    $rule_pids     = array();
                    $interest_json = array();
                    if (isset($feed_json['item']['id'])) {
                        $interest_json[] = $feed_json['item'];
                        $rule_pids[]     = $feed_json['item']['id'];
                    }
                    foreach ($others as $other) {
                        if ($other != '') {
                            $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $other . '.json';
                            $newItems = file_get_contents($feed_uri);
                            if ($newItems === false) {
                                continue;
                            }
                            $feed_json_other = json_decode($newItems, true);
                            if ($feed_json_other === NULL) {
                                continue;
                            }
                            if (isset($feed_json_other['item']['id'])) {
                                $interest_json[] = $feed_json_other['item'];
                                $rule_pids[]     = $feed_json_other['item']['id'];
                            }
                        }
                    }
                    $post_item_ids = array();
                    foreach ($post_list as $post) {
                        if (get_post_meta($post->ID, 'post_parent_type', true) == $type && get_post_meta($post->ID, 'post_parent_rule', true) == $param) {
                            $post_item_ids[$post->ID] = get_post_meta($post->ID, 'post_item_id', true);
                        }
                    }
                    foreach ($post_item_ids as $key => $p_id) {
                        if (!in_array($p_id, $rule_pids)) {
                            wp_delete_post($key, true);
                            foreach ($post_list as $index => $post) {
                                if ($post->ID == $key) {
                                    unset($post_list[$index]);
                                    break;
                                }
                            }
                        }
                    }
                } elseif ($type == 6) {
                    $interest_json = array();
                    if (isset($feed_json['item']['id'])) {
                        $interest_json[] = $feed_json['item'];
                    }
                    foreach ($others as $other) {
                        if ($other != '') {
                            $feed_uri = 'https://marketplace.envato.com/api/v3/item:' . $other . '.json';
                            $newItems = file_get_contents($feed_uri);
                            if ($newItems === false) {
                                continue;
                            }
                            $feed_json_other = json_decode($newItems, true);
                            if ($feed_json_other === NULL) {
                                continue;
                            }
                            if (isset($feed_json_other['item']['id'])) {
                                $interest_json[] = $feed_json_other['item'];
                            }
                        }
                    }
                    // post variable
                    $my_post                   = array();
                    $my_post['post_type']      = $post_type;
                    $my_post['comment_status'] = $accept_comments;
                    $my_post['post_excerpt']   = 'Hand of Midas Money Generator Envato Affiliate WordPress Plugin Generated Post';
                    $my_post['post_status']    = $post_status;
                    $my_post['post_author']    = $post_user_name;
                    if ($item_create_tag != '') {
                        $my_post['tags_input'] = $item_create_tag;
                    }
                    $my_post['post_item_id']             = 'group' . $param;
                    $my_post['post_item_marketplace']    = 'mixed_post';
                    $my_post['post_item_user']           = 'mixed_post';
                    $my_post['post_item_url']            = 'mixed_post';
                    $my_post['post_item_thumbnail']      = 'mixed_post';
                    $my_post['post_item_preview_img']    = 'mixed_post';
                    $my_post['post_item_media_url']      = 'mixed_post';
                    $my_post['post_item_cost']           = 'mixed_post';
                    $my_post['post_item_uploaded']       = 'mixed_post';
                    $my_post['post_item_cats']           = 'mixed_post';
                    $my_post['post_item_tags']           = 'mixed_post';
                    $my_post['market_item_last_updated'] = 'mixed_post';
                }
                $type6cnt           = 0;
                $type6_post_content = '';
                foreach ($interest_json as $key => $item) {
                    if ($counter <= (int) $max) {
                        $dom = new DOMDocument();
                        @$dom->loadHTMLFile($item['url']);
                        $xpath   = new DOMXPath($dom);
                        $div     = $xpath->query('//div[@class="user-html"]');
                        $div     = $div->item(0);
                        $content = $dom->saveXML($div);
                        if ($type !== 6) {
                            $id    = $item['id'];
                            $found = 0;
                            if (in_array($id, $posted_items)) {
                                $found = 1;
                            }
                            if ($found == 0) {
                                $item_media = '';
                                if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                    $item_media = isset($item['preview_url']) ? $item['preview_url'] : '';
                                }
                                if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                    $item_media = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                }
                                $item_img                  = isset($item['live_preview_url']) ? $item['live_preview_url'] : '';
                                $item_video                = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                $item_thumb                = $item['thumbnail'];
                                $item_url                  = $item['url'];
                                $item_user                 = $item['user'];
                                $item_cost                 = $item['cost'];
                                $item_cat                  = $item['category'];
                                $item_tags                 = $item['tags'];
                                $item_uploaded             = $item['uploaded_on'];
                                $item_last_update          = $item['last_update'];
                                $just_title                = $item['item'];
                                $item_sales                = $item['sales'];
                                $item_rating               = $item['rating'];
                                $preview_media             = midas_getIntro($marketplace, $item, $envato_username);
                                $my_post                   = array();
                                $my_post['post_type']      = $post_type;
                                $my_post['comment_status'] = $accept_comments;
                                $my_post['post_excerpt']   = midas_getExcerpt($marketplace, $item);
                                $my_post['post_status']    = $post_status;
                                $my_post['post_author']    = $post_user_name;
                                if ($can_create_tag == 'on') {
                                    $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                } else if ($item_create_tag != '') {
                                    $my_post['tags_input'] = $item_create_tag;
                                }
                                $my_post['post_item_id']             = $id;
                                $my_post['post_item_marketplace']    = $marketplace;
                                $my_post['post_item_user']           = $item_user;
                                $my_post['post_item_url']            = $item_url;
                                $my_post['post_item_thumbnail']      = $item_thumb;
                                $my_post['post_item_preview_img']    = $item_img;
                                $my_post['post_item_media_url']      = $item_media;
                                $my_post['post_item_cost']           = $item_cost;
                                $my_post['post_item_uploaded']       = $item_uploaded;
                                $my_post['post_item_cats']           = $item_cat;
                                $my_post['post_item_tags']           = $item_tags;
                                $my_post['market_item_last_updated'] = $item_last_update;
                                if ($type == 0) {
                                    $the_content = $midas_Main_Settings['post_content'];
                                } elseif ($type == 1) {
                                    $the_content = $midas_Main_Settings['post_content_user'];
                                } elseif ($type == 2) {
                                    $the_content = $midas_Main_Settings['post_content_popular'];
                                } elseif ($type == 3) {
                                    $the_content = $midas_Main_Settings['post_content_random'];
                                } elseif ($type == 4) {
                                    $the_content = $midas_Main_Settings['post_content_featured'];
                                } elseif ($type == 5) {
                                    $the_content = $midas_Main_Settings['post_content_manual'];
                                }
                                if (strpos($the_content, '%%') !== false) {
                                    $the_content = replaceContentShortcodes($the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                $my_post['post_content'] = $the_content;
                                if ($type == 0) {
                                    $the_title = $midas_Main_Settings['post_title'];
                                } elseif ($type == 1) {
                                    $the_title = $midas_Main_Settings['post_title_user'];
                                } elseif ($type == 2) {
                                    $the_title = $midas_Main_Settings['post_title_popular'];
                                } elseif ($type == 3) {
                                    $the_title = $midas_Main_Settings['post_title_random'];
                                } elseif ($type == 4) {
                                    $the_title = $midas_Main_Settings['post_title_featured'];
                                } elseif ($type == 5) {
                                    $the_title = $midas_Main_Settings['post_title_manual'];
                                }
                                if (strpos($the_title, '%%') !== false) {
                                    $the_title = replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                }
                                $my_post['post_title'] = $the_title;
                                $post_array[]          = $my_post;
                            } else {
                                $item_last_update = $item['last_update'];
                                foreach ($post_list as $post) {
                                    $item_id = get_post_meta($post->ID, 'post_item_id', true);
                                    if ($item_id == $id) {
                                        $item_in_post_updated = get_post_meta($post->ID, 'post_creator_last_updated', true);
                                        if ($item_in_post_updated != $item_last_update) {
                                            $item_media = '';
                                            if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                                $item_media = isset($item['preview_url']) ? $item['preview_url'] : '';
                                            }
                                            if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                                $item_media = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                            }
                                            $item_img                  = isset($item['live_preview_url']) ? $item['live_preview_url'] : '';
                                            $item_video                = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                                            $item_thumb                = $item['thumbnail'];
                                            $item_url                  = $item['url'];
                                            $item_user                 = $item['user'];
                                            $item_cost                 = $item['cost'];
                                            $item_cat                  = $item['category'];
                                            $item_tags                 = $item['tags'];
                                            $item_uploaded             = $item['uploaded_on'];
                                            $item_last_update          = $item['last_update'];
                                            $just_title                = $item['item'];
                                            $item_sales                = $item['sales'];
                                            $item_rating               = $item['rating'];
                                            $preview_media             = midas_getIntro($marketplace, $item, $envato_username);
                                            $my_post                   = array();
                                            $my_post['ID']             = $post->ID;
                                            $my_post['post_type']      = $post_type;
                                            $my_post['comment_status'] = $accept_comments;
                                            $my_post['post_excerpt']   = midas_getExcerpt($marketplace, $item);
                                            $my_post['post_status']    = $post_status;
                                            $my_post['post_author']    = $post_user_name;
                                            if ($can_create_tag == 'on') {
                                                $my_post['tags_input'] = ($item_create_tag != '' ? $item_create_tag . ',' : '') . $item_tags;
                                            } else if ($item_create_tag != '') {
                                                $my_post['tags_input'] = $item_create_tag;
                                            }
                                            $my_post['post_item_id']             = $id;
                                            $my_post['post_item_marketplace']    = $marketplace;
                                            $my_post['post_item_user']           = $item_user;
                                            $my_post['post_item_url']            = $item_url;
                                            $my_post['post_item_thumbnail']      = $item_thumb;
                                            $my_post['post_item_preview_img']    = $item_img;
                                            $my_post['post_item_media_url']      = $item_media;
                                            $my_post['post_item_cost']           = $item_cost;
                                            $my_post['post_item_uploaded']       = $item_uploaded;
                                            $my_post['post_item_cats']           = $item_cat;
                                            $my_post['post_item_tags']           = $item_tags;
                                            $my_post['market_item_last_updated'] = $item_last_update;
                                            if ($type == 0) {
                                                $the_content = $midas_Main_Settings['post_content'];
                                            } elseif ($type == 1) {
                                                $the_content = $midas_Main_Settings['post_content_user'];
                                            } elseif ($type == 2) {
                                                $the_content = $midas_Main_Settings['post_content_popular'];
                                            } elseif ($type == 3) {
                                                $the_content = $midas_Main_Settings['post_content_random'];
                                            } elseif ($type == 4) {
                                                $the_content = $midas_Main_Settings['post_content_featured'];
                                            } elseif ($type == 5) {
                                                $the_content = $midas_Main_Settings['post_content_manual'];
                                            }
                                            if (strpos($the_content, '%%') !== false) {
                                                $the_content = replaceContentShortcodes($the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            $my_post['post_content'] = $the_content;
                                            if ($type == 0) {
                                                $the_title = $midas_Main_Settings['post_title'];
                                            } elseif ($type == 1) {
                                                $the_title = $midas_Main_Settings['post_title_user'];
                                            } elseif ($type == 2) {
                                                $the_title = $midas_Main_Settings['post_title_popular'];
                                            } elseif ($type == 3) {
                                                $the_title = $midas_Main_Settings['post_title_random'];
                                            } elseif ($type == 4) {
                                                $the_title = $midas_Main_Settings['post_title_featured'];
                                            } elseif ($type == 5) {
                                                $the_title = $midas_Main_Settings['post_title_manual'];
                                            }
                                            if (strpos($the_title, '%%') !== false) {
                                                $the_title = replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                                            }
                                            $my_post['post_title'] = $the_title;
                                            $post_id               = wp_update_post($my_post);
                                            if ($post_id != 0) {
                                                if ($auto_image === 'on') {
                                                    if ($my_post['post_item_preview_img'] != '') {
                                                        midas_generate_featured_image($my_post['post_item_preview_img'], $post_id);
                                                    }
                                                }
                                                updatePostMeta($post_id, $my_post, $param, $type, $envato_username);
                                                
                                                if ($can_create_cat == 'on') {
                                                    $termid = midas_create_terms('category', '0', $my_post['post_item_cats']);
                                                    wp_set_post_terms($post_id, $termid, 'category');
                                                }
                                                if ($type == 0) {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 1) {
                                                    if (isset($midas_Main_Settings['default_category_user']) && $midas_Main_Settings['default_category_user'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_user'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 2) {
                                                    if (isset($midas_Main_Settings['default_category_popular']) && $midas_Main_Settings['default_category_popular'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_popular'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 3) {
                                                    if (isset($midas_Main_Settings['default_category_random']) && $midas_Main_Settings['default_category_random'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_random'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 4) {
                                                    if (isset($midas_Main_Settings['default_category_featured']) && $midas_Main_Settings['default_category_featured'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_featured'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 5) {
                                                    if (isset($midas_Main_Settings['default_category_manual']) && $midas_Main_Settings['default_category_manual'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_manual'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 6) {
                                                    if (isset($midas_Main_Settings['default_category_grouped']) && $midas_Main_Settings['default_category_grouped'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_grouped'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } else {
                                                    if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                }
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            $counter++;
                        } else {
                            $id    = 'group' . $param;
                            $found = 0;
                            if (in_array($id, $posted_items)) {
                                foreach ($post_list as $index => $post) {
                                    $item_id = get_post_meta($post->ID, 'post_item_id', true);
                                    if ($item_id == $id) {
                                        wp_delete_post($post->ID, true);
                                        unset($post_list[$index]);
                                        break;
                                    }
                                }
                            }
                            $item_media = '';
                            if (substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') {
                                $item_media = isset($item['preview_url']) ? $item['preview_url'] : '';
                            }
                            if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
                                $item_media = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                            }
                            $item_img         = isset($item['live_preview_url']) ? $item['live_preview_url'] : '';
                            $item_video       = isset($item['live_preview_video_url']) ? $item['live_preview_video_url'] : '';
                            $item_thumb       = $item['thumbnail'];
                            $item_url         = $item['url'];
                            $item_user        = $item['user'];
                            $item_cost        = $item['cost'];
                            $item_cat         = $item['category'];
                            $item_tags        = $item['tags'];
                            $item_uploaded    = $item['uploaded_on'];
                            $item_last_update = $item['last_update'];
                            $just_title       = $item['item'];
                            $item_sales       = $item['sales'];
                            $item_rating      = $item['rating'];
                            $preview_media    = midas_getIntro($marketplace, $item, $envato_username);
                            $the_content      = $list_item;
                            
                            $type6cnt = count($interest_json);
                            if (strpos($the_content, '%%') !== false) {
                                $the_content = replaceContentType6Shortcodes($type6cnt, $counter, $the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating);
                            }
                            $type6_post_content .= $the_content . '<br/><br/>';
                            $counter++;
                        }
                    }
                }
            }
            if ($type == 6) {
                $final_content           = $post_content;
                $final_content           = str_replace('%%list_items%%', $type6_post_content, $final_content);
                $my_post['post_content'] = $final_content;
                $my_post['post_title']   = str_replace('%%total_item_count%%', $type6cnt, $post_title);
                $post_array2[]           = $my_post;
            } else {
                $post_array2 = array_reverse($post_array);
            }
            foreach ($post_array2 as $post) {
                $post_id = wp_insert_post($post);
                if ($post_id != 0) {
                    if ($auto_image === 'on' && $type != 6) {
                        if ($post['post_item_preview_img'] != '') {
                            midas_generate_featured_image($post['post_item_preview_img'], $post_id);
                        }
                    }
                    addPostMeta($post_id, $post, $param, $type, $envato_username);
                    
                    if ($can_create_cat == 'on' && $type != 6) {
                        $termid = midas_create_terms('category', '0', $post['post_item_cats']);
                        wp_set_post_terms($post_id, $termid, 'category');
                    }
                    if ($type == 0) {
                        if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 1) {
                        if (isset($midas_Main_Settings['default_category_user']) && $midas_Main_Settings['default_category_user'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category_user'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    } elseif ($type == 2) {
                                                    if (isset($midas_Main_Settings['default_category_popular']) && $midas_Main_Settings['default_category_popular'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_popular'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 3) {
                                                    if (isset($midas_Main_Settings['default_category_random']) && $midas_Main_Settings['default_category_random'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_random'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 4) {
                                                    if (isset($midas_Main_Settings['default_category_featured']) && $midas_Main_Settings['default_category_featured'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_featured'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 5) {
                                                    if (isset($midas_Main_Settings['default_category_manual']) && $midas_Main_Settings['default_category_manual'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_manual'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } elseif ($type == 6) {
                                                    if (isset($midas_Main_Settings['default_category_grouped']) && $midas_Main_Settings['default_category_grouped'] !== 'midas_no_category_12345678') {
                                                        $cats   = array();
                                                        $cats[] = $midas_Main_Settings['default_category_grouped'];
                                                        wp_set_post_categories($post_id, $cats, true);
                                                    }
                                                } else {
                        if (isset($midas_Main_Settings['default_category']) && $midas_Main_Settings['default_category'] !== 'midas_no_category_12345678') {
                            $cats   = array();
                            $cats[] = $midas_Main_Settings['default_category'];
                            wp_set_post_categories($post_id, $cats, true);
                        }
                    }
                } else {
                    continue;
                }
            }
        }
        catch (Exception $e) {
            if (($key = array_search(array(
                $param => $type
            ), $running)) !== false) {
                unset($running[$key]);
                update_option('midas_running_list', $running);
            }
            return 'fail';
        }
        if (($key = array_search(array(
            $param => $type
        ), $running)) !== false) {
            unset($running[$key]);
            update_option('midas_running_list', $running);
        }
    }
    return 'ok';
}

function addPostMeta($post_id, $post, $param, $type, $envato_username)
{
    add_post_meta($post_id, 'post_creator_last_updated', $post['market_item_last_updated']);
    add_post_meta($post_id, 'post_item_id', $post['post_item_id']);
    add_post_meta($post_id, 'post_parent_rule', $param);
    add_post_meta($post_id, 'post_parent_type', $type);
    add_post_meta($post_id, 'post_thumbnail', $post['post_item_preview_img']);
    add_post_meta($post_id, 'post_item_marketplace', $post['post_item_marketplace']);
    add_post_meta($post_id, 'post_item_url', $post['post_item_url'] . '?ref=' . $envato_username);
    add_post_meta($post_id, 'post_item_user', $post['post_item_user']);
    add_post_meta($post_id, 'post_item_thumbnail', $post['post_item_thumbnail']);
    add_post_meta($post_id, 'post_item_media_url', $post['post_item_media_url']);
    add_post_meta($post_id, 'post_item_cost', $post['post_item_cost']);
    add_post_meta($post_id, 'post_item_uploaded', $post['post_item_uploaded']);
    add_post_meta($post_id, 'post_item_last_update', $post['market_item_last_updated']);
    add_post_meta($post_id, 'post_item_cats', $post['post_item_cats']);
    add_post_meta($post_id, 'post_item_tags', $post['post_item_tags']);
}

function updatePostMeta($post_id, $post, $param, $type, $envato_username)
{
    update_post_meta($post_id, 'post_creator_last_updated', $post['market_item_last_updated']);
    update_post_meta($post_id, 'post_item_id', $post['post_item_id']);
    update_post_meta($post_id, 'post_parent_rule', $param);
    update_post_meta($post_id, 'post_parent_type', $type);
    update_post_meta($post_id, 'post_thumbnail', $post['post_item_preview_img']);
    update_post_meta($post_id, 'post_item_marketplace', $post['post_item_marketplace']);
    update_post_meta($post_id, 'post_item_url', $post['post_item_url'] . '?ref=' . $envato_username);
    update_post_meta($post_id, 'post_item_user', $post['post_item_user']);
    update_post_meta($post_id, 'post_item_thumbnail', $post['post_item_thumbnail']);
    update_post_meta($post_id, 'post_item_media_url', $post['post_item_media_url']);
    update_post_meta($post_id, 'post_item_cost', $post['post_item_cost']);
    update_post_meta($post_id, 'post_item_uploaded', $post['post_item_uploaded']);
    update_post_meta($post_id, 'post_item_last_update', $post['market_item_last_updated']);
    update_post_meta($post_id, 'post_item_cats', $post['post_item_cats']);
    update_post_meta($post_id, 'post_item_tags', $post['post_item_tags']);
}

function replaceContentShortcodes($the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    $the_content = str_replace('%%see_more_button%%', midas_getSeeMoreButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%buy_now_button%%', midas_getBuyNowButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%live_preview_button%%', midas_getLiveLink($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%generate_item_intro%%', midas_getIntro($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_preview%%', midas_getItemPrev($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_title%%', $just_title, $the_content);
    $the_content = str_replace('%%item_description%%', $content, $the_content);
    $the_content = str_replace('%%item_id%%', $id, $the_content);
    $the_content = str_replace('%%item_media%%', $item_media, $the_content);
    $the_content = str_replace('%%item_img%%', $item_img, $the_content);
    $the_content = str_replace('%%item_video%%', $item_video, $the_content);
    $the_content = str_replace('%%item_thumb%%', $item_thumb, $the_content);
    $the_content = str_replace('%%item_url%%', $item_url, $the_content);
    $the_content = str_replace('%%item_user%%', $item_user, $the_content);
    $the_content = str_replace('%%item_cost%%', $item_cost, $the_content);
    $the_content = str_replace('%%item_cat%%', $item_cat, $the_content);
    $the_content = str_replace('%%item_tags%%', $item_tags, $the_content);
    $the_content = str_replace('%%item_uploaded%%', $item_uploaded, $the_content);
    $the_content = str_replace('%%item_last_update%%', $item_last_update, $the_content);
    $the_content = str_replace('%%item_sales%%', $item_sales, $the_content);
    $the_content = str_replace('%%item_rating%%', $item_rating, $the_content);
    return $the_content;
}

function replaceContentType6Shortcodes($total, $counter, $the_content, $item, $envato_username, $marketplace, $just_title, $content, $id, $item_media, $item_img, $item_video, $item_thumb, $item_url, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    $the_content = str_replace('%%total_item_count%%', $total, $the_content);
    $the_content = str_replace('%%current_counter%%', $counter, $the_content);
    $the_content = str_replace('%%see_more_button%%', midas_getSeeMoreButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%buy_now_button%%', midas_getBuyNowButton($item, $envato_username), $the_content);
    $the_content = str_replace('%%live_preview_button%%', midas_getLiveLink($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%generate_item_intro%%', midas_getIntro($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_preview%%', midas_getItemPrev($marketplace, $item, $envato_username), $the_content);
    $the_content = str_replace('%%item_title%%', $just_title, $the_content);
    $the_content = str_replace('%%item_description%%', $content, $the_content);
    $the_content = str_replace('%%item_id%%', $id, $the_content);
    $the_content = str_replace('%%item_media%%', $item_media, $the_content);
    $the_content = str_replace('%%item_img%%', $item_img, $the_content);
    $the_content = str_replace('%%item_video%%', $item_video, $the_content);
    $the_content = str_replace('%%item_thumb%%', $item_thumb, $the_content);
    $the_content = str_replace('%%item_url%%', $item_url, $the_content);
    $the_content = str_replace('%%item_user%%', $item_user, $the_content);
    $the_content = str_replace('%%item_cost%%', $item_cost, $the_content);
    $the_content = str_replace('%%item_cat%%', $item_cat, $the_content);
    $the_content = str_replace('%%item_tags%%', $item_tags, $the_content);
    $the_content = str_replace('%%item_uploaded%%', $item_uploaded, $the_content);
    $the_content = str_replace('%%item_last_update%%', $item_last_update, $the_content);
    $the_content = str_replace('%%item_sales%%', $item_sales, $the_content);
    $the_content = str_replace('%%item_rating%%', $item_rating, $the_content);
    return $the_content;
}

function replaceTitleShortcodes($the_title, $just_title, $content, $id, $item_user, $item_cost, $item_cat, $item_tags, $item_uploaded, $item_last_update, $item_sales, $item_rating)
{
    $the_title = str_replace('%%item_title%%', $just_title, $the_title);
    $the_title = str_replace('%%item_description%%', $content, $the_title);
    $the_title = str_replace('%%item_id%%', $id, $the_title);
    $the_title = str_replace('%%item_user%%', $item_user, $the_title);
    $the_title = str_replace('%%item_cost%%', $item_cost, $the_title);
    $the_title = str_replace('%%item_cat%%', $item_cat, $the_title);
    $the_title = str_replace('%%item_tags%%', $item_tags, $the_title);
    $the_title = str_replace('%%item_uploaded%%', $item_uploaded, $the_title);
    $the_title = str_replace('%%item_last_update%%', $item_last_update, $the_title);
    $the_title = str_replace('%%item_sales%%', $item_sales, $the_title);
    $the_title = str_replace('%%item_rating%%', $item_rating, $the_title);
    return $the_title;
}

function midas_generate_featured_image($image_url, $post_id)
{
    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($image_url);
    $filename   = basename($image_url);
    if (wp_mkdir_p($upload_dir['path'] . '/' . $post_id))
        $file = $upload_dir['path'] . '/' . $post_id . '/' . $filename;
    else
        $file = $upload_dir['basedir'] . '/' . $post_id . '/' . $filename;
    file_put_contents($file, $image_data);
    $wp_filetype = wp_check_filetype($filename, null);
    $attachment  = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id   = wp_insert_attachment($attachment, $file, $post_id);
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata($attach_id, $file);
    $res1        = wp_update_attachment_metadata($attach_id, $attach_data);
    $res2        = set_post_thumbnail($post_id, $attach_id);
}

function midas_hour_diff($date1, $date2)
{
    $date1 = new DateTime($date1);
    $date2 = new DateTime($date2);
    
    $number1 = (int) $date1->format('U');
    $number2 = (int) $date2->format('U');
    return ($number1 - $number2) / 60 / 60;
}

function midas_add_hour($date, $hour)
{
    $date1 = new DateTime($date);
    $date1->modify("$hour hours");
    foreach ($date1 as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return $date;
}

function midas_get_date_now($param = 'now')
{
    $date = new DateTime($param);
    foreach ($date as $key => $value) {
        if ($key == 'date') {
            return $value;
        }
    }
    return '';
}

function midas_create_terms($taxonomy, $parent, $terms_str)
{
    $terms          = explode('/', $terms_str);
    $categories     = array();
    $parent_term_id = $parent;
    foreach ($terms as $term) {
        $res = term_exists($term, $taxonomy);
        if ($res != NULL && $res != 0 && count($res) > 0 && isset($res['term_id'])) {
            $parent_term_id = $res['term_id'];
            $categories[]   = $parent_term_id;
        } else {
            $new_term = wp_insert_term($term, $taxonomy, array(
                'parent' => $parent_term_id
            ));
            if ($new_term != NULL && $new_term != 0 && count($new_term) > 0 && isset($new_term['term_id'])) {
                $parent_term_id = $new_term['term_id'];
                $categories[]   = $parent_term_id;
            }
        }
    }
    
    return $categories;
}

function midas_getExcerpt($marketplace, $json)
{
    $preview = '';
    if ((substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') && isset($json['preview_type']) && isset($json['preview_url'])) {
        $preview = '[audio ' . $json['preview_url'] . ']';
    }
    //todo video preview for videohive?
    //todo buy button and all kind of things shortcode in content text!
    else if (isset($json['live_preview_url'])) {
        $preview = '<img src="' . $json['live_preview_url'] . '" />';
    }
    
    return $preview;
}
function midas_getItemPrev($marketplace, $json, $ref_user)
{
    $preview = '';
    if ((substr($marketplace, 0, 23) == 'https://audiojungle.net' || $marketplace == 'audiojungle') && isset($json['preview_type']) && isset($json['preview_url'])) {
        $preview = '[audio ' . $json['preview_url'] . ']';
    } else if (isset($json['live_preview_url'])) {
        $preview = '<img src="' . $json['live_preview_url'] . '" />';
    }
    return $preview;
}

function midas_getSeeMoreButton($json, $ref_user)
{
    $link = '';
    if (isset($json['url'])) {
        $link = '<a href="' . $json['url'] . '?ref=' . $ref_user . '" class="button purchase" target="_blank">See More on Envato</a>';
    }
    return $link;
}

function midas_getBuyNowButton($json, $ref_user)
{
    $link = '';
    if (isset($json['url'])) {
        $link = '<a href="' . $json['url'] . '?license=regular&open_purchase_for_item_id=' . $json['id'] . '&purchasable=source&ref=' . $ref_user . '" class="button purchase" target="_blank">Buy Now</a>';
    }
    return $link;
}

function midas_getLiveLink($marketplace, $json, $ref_user)
{
    //todo better these
    $live_link = '';
    if (substr($marketplace, 0, 21) == 'https://videohive.net' || $marketplace == 'videohive') {
        $live_link = '<a href="' . $json['live_preview_video_url'] . '" rel="prettyPhoto" class="button" target="_blank">Video Preview</a>';
    }
    if (substr($marketplace, 0, 23) == 'https://themeforest.net' || $marketplace == 'themeforest') {
        $lurl      = $json['url'];
        $larray    = explode('/', $lurl);
        $lelm      = $larray[count($larray) - 1];
        $lurl      = str_replace($lelm, 'full_screen_preview/' . $lelm . '?ref=' . $ref_user, $lurl);
        $live_link = '<a href="' . $lurl . '" class="button" target="_blank">Live Preview</a>';
    }
    return $live_link;
}

function midas_getIntro($marketplace, $json, $ref_user)
{
    $preview   = midas_getItemPrev($marketplace, $json, $ref_user);
    $link      = midas_getBuyNowButton($json, $ref_user);
    $live_link = midas_getLiveLink($marketplace, $json, $ref_user);
    $preview   = '<div>' . $preview . '<div >' . $live_link . '&nbsp;' . $link . '</div></div><br/>';
    
    return $preview;
}

register_activation_hook(__FILE__, 'midas_activation_callback');
function midas_activation_callback()
{
    if (!get_option('midas_Main_Settings')) {
        $midas_Main_Settings = array(
            'midas_enabled' => 'on',
            'submit_status' => 'publish',
            'default_category' => '',
            'default_type' => 'post',
            'default_tags' => '',
            'user_name' => '',
            'auto_categories' => '',
            'auto_tags' => '',
            'auto_image' => '',
            'enable_comments' => '',
            'post_user_name' => '',
            'links_add_ref' => '',
            'links_hide' => '',
            'apiKey' => '',
            'post_title' => '%%item_title%%',
            'post_content' => '%%item_preview%% %%item_description%%',
            'post_title_user' => '%%item_title%%',
            'post_content_user' => '%%item_preview%% %%item_description%%',
            'post_title_popular' => '%%item_title%%',
            'post_content_popular' => '%%item_preview%% %%item_description%%',
            'post_title_random' => '%%item_title%%',
            'post_content_random' => '%%item_preview%% %%item_description%%',
            'post_title_featured' => '%%item_title%%',
            'post_content_featured' => '%%item_preview%% %%item_description%%',
            'post_title_manual' => '%%item_title%%',
            'post_content_manual' => '%%item_preview%% %%item_description%%',
            'enable_metabox' => '',
            'submit_status_user' => '',
            'default_category_user' => '',
            'default_type_user' => '',
            'default_tags_user' => '',
            'auto_categories_user' => '',
            'auto_tags_user' => '',
            'auto_image_user' => '',
            'enable_comments_user' => '',
            'post_user_name_user' => '',
            'submit_status_popular' => '',
            'default_category_popular' => '',
            'default_type_popular' => '',
            'default_tags_popular' => '',
            'auto_categories_popular' => '',
            'auto_tags_popular' => '',
            'auto_image_popular' => '',
            'enable_comments_popular' => '',
            'post_user_name_popular' => '',
            'submit_status_random' => '',
            'default_category_random' => '',
            'default_type_random' => '',
            'default_tags_random' => '',
            'auto_categories_random' => '',
            'auto_tags_random' => '',
            'auto_image_random' => '',
            'enable_comments_random' => '',
            'post_user_name_random' => '',
            'submit_status_featured' => '',
            'default_category_featured' => '',
            'default_type_featured' => '',
            'default_tags_featured' => '',
            'auto_categories_featured' => '',
            'auto_tags_featured' => '',
            'auto_image_featured' => '',
            'enable_comments_featured' => '',
            'post_user_name_featured' => '',
            'submit_status_manual' => '',
            'default_category_manual' => '',
            'default_type_manual' => '',
            'default_tags_manual' => '',
            'auto_categories_manual' => '',
            'auto_tags_manual' => '',
            'auto_image_manual' => '',
            'enable_comments_manual' => '',
            'post_user_name_manual' => '',
            'submit_status_grouped' => '',
            'default_category_grouped' => '',
            'default_type_grouped' => '',
            'default_tags_grouped' => '',
            'auto_categories_grouped' => '',
            'auto_tags_grouped' => '',
            'auto_image_grouped' => '',
            'enable_comments_grouped' => '',
            'post_user_name_grouped' => ''
        );
        add_option('midas_Main_Settings', $midas_Main_Settings);
    }
}


register_activation_hook(__FILE__, 'midas_check_version');
function midas_check_version()
{
    global $wp_version;
    if (!current_user_can('activate_plugins')) {
        echo '<p>' . sprintf(__('You are not allowed to activate plugins!', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    $php_version_required = '5.0';
    $wp_version_required  = '2.7';
    
    if (version_compare(PHP_VERSION, $php_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a PHP version greater than %1$s. Please update your PHP version before you activate it.', 'oe-sb'), $php_version_required) . '</p>';
        die;
    }
    
    if (version_compare($wp_version, $wp_version_required, '<')) {
        deactivate_plugins(basename(__FILE__));
        echo '<p>' . sprintf(__('This plugin can not be activated because it requires a WordPress version greater than %1$s. Please go to Dashboard &#9656; Updates to get the latest version of WordPress .', 'oe-sb'), $wp_version_required) . '</p>';
        die;
    }
}

add_action('admin_init', 'midas_register_mysettings');
function midas_register_mysettings()
{
    register_setting('midas_option_group', 'midas_Main_Settings');
}

function midas_get_plugin_url()
{
    return plugins_url('', __FILE__);
}

function midas_get_file_url($url)
{
    return midas_get_plugin_url() . '/' . $url;
}

add_action('admin_enqueue_scripts', 'midas_admin_load_files');
function midas_admin_load_files()
{
    wp_register_style('midas-browser-style', plugins_url('styles/midas-browser.css', __FILE__), false, '1.0.0');
    wp_enqueue_style('midas-browser-style');
    wp_enqueue_script('jquery');
    wp_enqueue_script('midas-angular', plugins_url('res/angular.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('midas-angular-sanitize', plugins_url('res/angular-sanitize.js', __FILE__), array(), '1.0.0', true);
    wp_enqueue_script('midas-settings-app', plugins_url('res/midas-angular.js', __FILE__), array(), '1.0.0', true);
}

require(dirname(__FILE__) . "/res/midas-main.php");
require(dirname(__FILE__) . "/res/midas-newest-post-rules.php");
require(dirname(__FILE__) . "/res/midas-newest-user.php");
require(dirname(__FILE__) . "/res/midas-popular-items.php");
require(dirname(__FILE__) . "/res/midas-random-items.php");
require(dirname(__FILE__) . "/res/midas-featured-items.php");
require(dirname(__FILE__) . "/res/midas-manual-items.php");
require(dirname(__FILE__) . "/res/midas-group-items.php");
?>