<?php
function midas_admin_settings()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('midas_option_group');
    do_settings_sections('midas_option_group');
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled'])) {
        $midas_enabled = $midas_Main_Settings['midas_enabled'];
    } else {
        $midas_enabled = '';
    }
    if (isset($midas_Main_Settings['submit_status'])) {
        $submit_status = $midas_Main_Settings['submit_status'];
    } else {
        $submit_status = '';
    }
    if (isset($midas_Main_Settings['default_category'])) {
        $default_category = $midas_Main_Settings['default_category'];
    } else {
        $default_category = '';
    }
    if (isset($midas_Main_Settings['default_type'])) {
        $default_type = $midas_Main_Settings['default_type'];
    } else {
        $default_type = '';
    }
    if (isset($midas_Main_Settings['default_tags'])) {
        $default_tags = $midas_Main_Settings['default_tags'];
    } else {
        $default_tags = '';
    }
    if (isset($midas_Main_Settings['user_name'])) {
        $user_name = $midas_Main_Settings['user_name'];
    } else {
        $user_name = '';
    }
    if (isset($midas_Main_Settings['auto_tags'])) {
        $auto_tags = $midas_Main_Settings['auto_tags'];
    } else {
        $auto_tags = '';
    }
    if (isset($midas_Main_Settings['auto_categories'])) {
        $auto_categories = $midas_Main_Settings['auto_categories'];
    } else {
        $auto_categories = '';
    }
    if (isset($midas_Main_Settings['auto_image'])) {
        $auto_image = $midas_Main_Settings['auto_image'];
    } else {
        $auto_image = '';
    }
    if (isset($midas_Main_Settings['enable_comments'])) {
        $enable_comments = $midas_Main_Settings['enable_comments'];
    } else {
        $enable_comments = '';
    }
    if (isset($midas_Main_Settings['auto_generate_comments'])) {
        $auto_generate_comments = $midas_Main_Settings['auto_generate_comments'];
    } else {
        $auto_generate_comments = '';
    }
    if (isset($midas_Main_Settings['auto_generate_comments_user'])) {
        $auto_generate_comments_user = $midas_Main_Settings['auto_generate_comments_user'];
    } else {
        $auto_generate_comments_user = '';
    }
    if (isset($midas_Main_Settings['auto_generate_comments_featured'])) {
        $auto_generate_comments_featured = $midas_Main_Settings['auto_generate_comments_featured'];
    } else {
        $auto_generate_comments_featured = '';
    }
    if (isset($midas_Main_Settings['auto_generate_comments_popular'])) {
        $auto_generate_comments_popular = $midas_Main_Settings['auto_generate_comments_popular'];
    } else {
        $auto_generate_comments_popular = '';
    }
    if (isset($midas_Main_Settings['auto_generate_comments_random'])) {
        $auto_generate_comments_random = $midas_Main_Settings['auto_generate_comments_random'];
    } else {
        $auto_generate_comments_random = '';
    }
    if (isset($midas_Main_Settings['auto_generate_comments_manual'])) {
        $auto_generate_comments_manual = $midas_Main_Settings['auto_generate_comments_manual'];
    } else {
        $auto_generate_comments_manual = '';
    }
    if (isset($midas_Main_Settings['post_user_name'])) {
        $post_user_name = $midas_Main_Settings['post_user_name'];
    } else {
        $post_user_name = '';
    }
    if (isset($midas_Main_Settings['links_add_ref'])) {
        $links_add_ref = $midas_Main_Settings['links_add_ref'];
    } else {
        $links_add_ref = '';
    }
    if (isset($midas_Main_Settings['links_hide'])) {
        $links_hide = $midas_Main_Settings['links_hide'];
    } else {
        $links_hide = '';
    }
    if (isset($midas_Main_Settings['apiKey'])) {
        $apiKey = $midas_Main_Settings['apiKey'];
    } else {
        $apiKey = '';
    }
    if (isset($midas_Main_Settings['post_title'])) {
        $post_title = $midas_Main_Settings['post_title'];
    } else {
        $post_title = '';
    }
    if (isset($midas_Main_Settings['post_content'])) {
        $post_content = $midas_Main_Settings['post_content'];
    } else {
        $post_content = '';
    }
    if (isset($midas_Main_Settings['post_title_user'])) {
        $post_title_user = $midas_Main_Settings['post_title_user'];
    } else {
        $post_title_user = '';
    }
    if (isset($midas_Main_Settings['post_content_user'])) {
        $post_content_user = $midas_Main_Settings['post_content_user'];
    } else {
        $post_content_user = '';
    }
    if (isset($midas_Main_Settings['post_title_popular'])) {
        $post_title_popular = $midas_Main_Settings['post_title_popular'];
    } else {
        $post_title_popular = '';
    }
    if (isset($midas_Main_Settings['post_content_popular'])) {
        $post_content_popular = $midas_Main_Settings['post_content_popular'];
    } else {
        $post_content_popular = '';
    }
    if (isset($midas_Main_Settings['post_title_random'])) {
        $post_title_random = $midas_Main_Settings['post_title_random'];
    } else {
        $post_title_random = '';
    }
    if (isset($midas_Main_Settings['post_content_random'])) {
        $post_content_random = $midas_Main_Settings['post_content_random'];
    } else {
        $post_content_random = '';
    }
    if (isset($midas_Main_Settings['post_title_featured'])) {
        $post_title_featured = $midas_Main_Settings['post_title_featured'];
    } else {
        $post_title_featured = '';
    }
    if (isset($midas_Main_Settings['post_content_featured'])) {
        $post_content_featured = $midas_Main_Settings['post_content_featured'];
    } else {
        $post_content_featured = '';
    }
    if (isset($midas_Main_Settings['post_title_manual'])) {
        $post_title_manual = $midas_Main_Settings['post_title_manual'];
    } else {
        $post_title_manual = '';
    }
    if (isset($midas_Main_Settings['post_content_manual'])) {
        $post_content_manual = $midas_Main_Settings['post_content_manual'];
    } else {
        $post_content_manual = '';
    }
    if (isset($midas_Main_Settings['enable_metabox'])) {
        $enable_metabox = $midas_Main_Settings['enable_metabox'];
    } else {
        $enable_metabox = '';
    }
    if (isset($midas_Main_Settings['submit_status_user'])) {
        $submit_status_user = $midas_Main_Settings['submit_status_user'];
    } else {
        $submit_status_user = '';
    }
    if (isset($midas_Main_Settings['default_category_user'])) {
        $default_category_user = $midas_Main_Settings['default_category_user'];
    } else {
        $default_category_user = '';
    }
    if (isset($midas_Main_Settings['default_type_user'])) {
        $default_type_user = $midas_Main_Settings['default_type_user'];
    } else {
        $default_type_user = '';
    }
    if (isset($midas_Main_Settings['default_tags_user'])) {
        $default_tags_user = $midas_Main_Settings['default_tags_user'];
    } else {
        $default_tags_user = '';
    }
    if (isset($midas_Main_Settings['auto_categories_user'])) {
        $auto_categories_user = $midas_Main_Settings['auto_categories_user'];
    } else {
        $auto_categories_user = '';
    }
    if (isset($midas_Main_Settings['auto_tags_user'])) {
        $auto_tags_user = $midas_Main_Settings['auto_tags_user'];
    } else {
        $auto_tags_user = '';
    }
    if (isset($midas_Main_Settings['auto_image_user'])) {
        $auto_image_user = $midas_Main_Settings['auto_image_user'];
    } else {
        $auto_image_user = '';
    }
    if (isset($midas_Main_Settings['enable_comments_user'])) {
        $enable_comments_user = $midas_Main_Settings['enable_comments_user'];
    } else {
        $enable_comments_user = '';
    }
    if (isset($midas_Main_Settings['post_user_name_user'])) {
        $post_user_name_user = $midas_Main_Settings['post_user_name_user'];
    } else {
        $post_user_name_user = '';
    }
    if (isset($midas_Main_Settings['submit_status_popular'])) {
        $submit_status_popular = $midas_Main_Settings['submit_status_popular'];
    } else {
        $submit_status_popular = '';
    }
    if (isset($midas_Main_Settings['default_category_popular'])) {
        $default_category_popular = $midas_Main_Settings['default_category_popular'];
    } else {
        $default_category_popular = '';
    }
    if (isset($midas_Main_Settings['default_type_popular'])) {
        $default_type_popular = $midas_Main_Settings['default_type_popular'];
    } else {
        $default_type_popular = '';
    }
    if (isset($midas_Main_Settings['default_tags_popular'])) {
        $default_tags_popular = $midas_Main_Settings['default_tags_popular'];
    } else {
        $default_tags_popular = '';
    }
    if (isset($midas_Main_Settings['auto_categories_popular'])) {
        $auto_categories_popular = $midas_Main_Settings['auto_categories_popular'];
    } else {
        $auto_categories_popular = '';
    }
    if (isset($midas_Main_Settings['auto_tags_popular'])) {
        $auto_tags_popular = $midas_Main_Settings['auto_tags_popular'];
    } else {
        $auto_tags_popular = '';
    }
    if (isset($midas_Main_Settings['auto_image_popular'])) {
        $auto_image_popular = $midas_Main_Settings['auto_image_popular'];
    } else {
        $auto_image_popular = '';
    }
    if (isset($midas_Main_Settings['enable_comments_popular'])) {
        $enable_comments_popular = $midas_Main_Settings['enable_comments_popular'];
    } else {
        $enable_comments_popular = '';
    }
    if (isset($midas_Main_Settings['post_user_name_popular'])) {
        $post_user_name_popular = $midas_Main_Settings['post_user_name_popular'];
    } else {
        $post_user_name_popular = '';
    }
    if (isset($midas_Main_Settings['submit_status_random'])) {
        $submit_status_random = $midas_Main_Settings['submit_status_random'];
    } else {
        $submit_status_random = '';
    }
    if (isset($midas_Main_Settings['default_category_random'])) {
        $default_category_random = $midas_Main_Settings['default_category_random'];
    } else {
        $default_category_random = '';
    }
    if (isset($midas_Main_Settings['default_type_random'])) {
        $default_type_random = $midas_Main_Settings['default_type_random'];
    } else {
        $default_type_random = '';
    }
    if (isset($midas_Main_Settings['default_tags_random'])) {
        $default_tags_random = $midas_Main_Settings['default_tags_random'];
    } else {
        $default_tags_random = '';
    }
    if (isset($midas_Main_Settings['auto_categories_random'])) {
        $auto_categories_random = $midas_Main_Settings['auto_categories_random'];
    } else {
        $auto_categories_random = '';
    }
    if (isset($midas_Main_Settings['auto_tags_random'])) {
        $auto_tags_random = $midas_Main_Settings['auto_tags_random'];
    } else {
        $auto_tags_random = '';
    }
    if (isset($midas_Main_Settings['auto_image_random'])) {
        $auto_image_random = $midas_Main_Settings['auto_image_random'];
    } else {
        $auto_image_random = '';
    }
    if (isset($midas_Main_Settings['enable_comments_random'])) {
        $enable_comments_random = $midas_Main_Settings['enable_comments_random'];
    } else {
        $enable_comments_random = '';
    }
    if (isset($midas_Main_Settings['post_user_name_random'])) {
        $post_user_name_random = $midas_Main_Settings['post_user_name_random'];
    } else {
        $post_user_name_random = '';
    }
    if (isset($midas_Main_Settings['submit_status_featured'])) {
        $submit_status_featured = $midas_Main_Settings['submit_status_featured'];
    } else {
        $submit_status_featured = '';
    }
    if (isset($midas_Main_Settings['default_category_featured'])) {
        $default_category_featured = $midas_Main_Settings['default_category_featured'];
    } else {
        $default_category_featured = '';
    }
    if (isset($midas_Main_Settings['default_type_featured'])) {
        $default_type_featured = $midas_Main_Settings['default_type_featured'];
    } else {
        $default_type_featured = '';
    }
    if (isset($midas_Main_Settings['default_tags_featured'])) {
        $default_tags_featured = $midas_Main_Settings['default_tags_featured'];
    } else {
        $default_tags_featured = '';
    }
    if (isset($midas_Main_Settings['auto_categories_featured'])) {
        $auto_categories_featured = $midas_Main_Settings['auto_categories_featured'];
    } else {
        $auto_categories_featured = '';
    }
    if (isset($midas_Main_Settings['auto_tags_featured'])) {
        $auto_tags_featured = $midas_Main_Settings['auto_tags_featured'];
    } else {
        $auto_tags_featured = '';
    }
    if (isset($midas_Main_Settings['auto_image_featured'])) {
        $auto_image_featured = $midas_Main_Settings['auto_image_featured'];
    } else {
        $auto_image_featured = '';
    }
    if (isset($midas_Main_Settings['enable_comments_featured'])) {
        $enable_comments_featured = $midas_Main_Settings['enable_comments_featured'];
    } else {
        $enable_comments_featured = '';
    }
    if (isset($midas_Main_Settings['post_user_name_featured'])) {
        $post_user_name_featured = $midas_Main_Settings['post_user_name_featured'];
    } else {
        $post_user_name_featured = '';
    }
    if (isset($midas_Main_Settings['submit_status_manual'])) {
        $submit_status_manual = $midas_Main_Settings['submit_status_manual'];
    } else {
        $submit_status_manual = '';
    }
    if (isset($midas_Main_Settings['default_category_manual'])) {
        $default_category_manual = $midas_Main_Settings['default_category_manual'];
    } else {
        $default_category_manual = '';
    }
    if (isset($midas_Main_Settings['default_type_manual'])) {
        $default_type_manual = $midas_Main_Settings['default_type_manual'];
    } else {
        $default_type_manual = '';
    }
    if (isset($midas_Main_Settings['default_tags_manual'])) {
        $default_tags_manual = $midas_Main_Settings['default_tags_manual'];
    } else {
        $default_tags_manual = '';
    }
    if (isset($midas_Main_Settings['auto_categories_manual'])) {
        $auto_categories_manual = $midas_Main_Settings['auto_categories_manual'];
    } else {
        $auto_categories_manual = '';
    }
    if (isset($midas_Main_Settings['auto_tags_manual'])) {
        $auto_tags_manual = $midas_Main_Settings['auto_tags_manual'];
    } else {
        $auto_tags_manual = '';
    }
    if (isset($midas_Main_Settings['auto_image_manual'])) {
        $auto_image_manual = $midas_Main_Settings['auto_image_manual'];
    } else {
        $auto_image_manual = '';
    }
    if (isset($midas_Main_Settings['enable_comments_manual'])) {
        $enable_comments_manual = $midas_Main_Settings['enable_comments_manual'];
    } else {
        $enable_comments_manual = '';
    }
    if (isset($midas_Main_Settings['post_user_name_manual'])) {
        $post_user_name_manual = $midas_Main_Settings['post_user_name_manual'];
    } else {
        $post_user_name_manual = '';
    }
    if (isset($midas_Main_Settings['submit_status_grouped'])) {
        $submit_status_grouped = $midas_Main_Settings['submit_status_grouped'];
    } else {
        $submit_status_grouped = '';
    }
    if (isset($midas_Main_Settings['default_category_grouped'])) {
        $default_category_grouped = $midas_Main_Settings['default_category_grouped'];
    } else {
        $default_category_grouped = '';
    }
    if (isset($midas_Main_Settings['default_type_grouped'])) {
        $default_type_grouped = $midas_Main_Settings['default_type_grouped'];
    } else {
        $default_type_grouped = '';
    }
    if (isset($midas_Main_Settings['default_tags_grouped'])) {
        $default_tags_grouped = $midas_Main_Settings['default_tags_grouped'];
    } else {
        $default_tags_grouped = '';
    }
    if (isset($midas_Main_Settings['auto_categories_grouped'])) {
        $auto_categories_grouped = $midas_Main_Settings['auto_categories_grouped'];
    } else {
        $auto_categories_grouped = '';
    }
    if (isset($midas_Main_Settings['auto_tags_grouped'])) {
        $auto_tags_grouped = $midas_Main_Settings['auto_tags_grouped'];
    } else {
        $auto_tags_grouped = '';
    }
    if (isset($midas_Main_Settings['auto_image_grouped'])) {
        $auto_image_grouped = $midas_Main_Settings['auto_image_grouped'];
    } else {
        $auto_image_grouped = '';
    }
    if (isset($midas_Main_Settings['enable_comments_grouped'])) {
        $enable_comments_grouped = $midas_Main_Settings['enable_comments_grouped'];
    } else {
        $enable_comments_grouped = '';
    }
    if (isset($midas_Main_Settings['post_user_name_grouped'])) {
        $post_user_name_grouped = $midas_Main_Settings['post_user_name_grouped'];
    } else {
        $post_user_name_grouped = '';
    }
    if (isset($midas_Main_Settings['variable_list'])) {
        $variable_list = $midas_Main_Settings['variable_list'];
    } else {
        $variable_list = '';
    }
    if (isset($midas_Main_Settings['sentence_list'])) {
        $sentence_list = $midas_Main_Settings['sentence_list'];
    } else {
        $sentence_list = '';
    }
    if (isset($midas_Main_Settings['sentence_list2'])) {
        $sentence_list2 = $midas_Main_Settings['sentence_list2'];
    } else {
        $sentence_list2 = '';
    }
    if (isset($midas_Main_Settings['enable_logging'])) {
        $enable_logging = $midas_Main_Settings['enable_logging'];
    } else {
        $enable_logging = '';
    }
    if (isset($midas_Main_Settings['auto_clear_logs'])) {
        $auto_clear_logs = $midas_Main_Settings['auto_clear_logs'];
    } else {
        $auto_clear_logs = '';
    }
    if (isset($midas_Main_Settings['enable_detailed_logging'])) {
        $enable_detailed_logging = $midas_Main_Settings['enable_detailed_logging'];
    } else {
        $enable_detailed_logging = '';
    }
    if (isset($midas_Main_Settings['auto_update_posts'])) {
        $auto_update_posts = $midas_Main_Settings['auto_update_posts'];
    } else {
        $auto_update_posts = '';
    }
    if (isset($midas_Main_Settings['featured_image_default'])) {
        $featured_image_default = $midas_Main_Settings['featured_image_default'];
    } else {
        $featured_image_default = '';
    }
    if (isset($midas_Main_Settings['featured_image_user'])) {
        $featured_image_user = $midas_Main_Settings['featured_image_user'];
    } else {
        $featured_image_user = '';
    }
    if (isset($midas_Main_Settings['featured_image_featured'])) {
        $featured_image_featured = $midas_Main_Settings['featured_image_featured'];
    } else {
        $featured_image_featured = '';
    }
    if (isset($midas_Main_Settings['featured_image_popular'])) {
        $featured_image_popular = $midas_Main_Settings['featured_image_popular'];
    } else {
        $featured_image_popular = '';
    }
    if (isset($midas_Main_Settings['featured_image_random'])) {
        $featured_image_random = $midas_Main_Settings['featured_image_random'];
    } else {
        $featured_image_random = '';
    }
    if (isset($midas_Main_Settings['featured_image_manual'])) {
        $featured_image_manual = $midas_Main_Settings['featured_image_manual'];
    } else {
        $featured_image_manual = '';
    }
    if (isset($midas_Main_Settings['featured_image_grouped'])) {
        $featured_image_grouped = $midas_Main_Settings['featured_image_grouped'];
    } else {
        $featured_image_grouped = '';
    }
    if (isset($midas_Main_Settings['rule_timeout'])) {
        $rule_timeout = $midas_Main_Settings['rule_timeout'];
    } else {
        $rule_timeout = '';
    }
?>
<script>
                var midas_admin_json = {
                    default_category: '<?php
    echo $default_category;
?>',
                    default_type: '<?php
    echo $default_type;
?>',
                    auto_generate_comments: '<?php
    echo $auto_generate_comments;
?>',
                    auto_generate_comments_user: '<?php
    echo $auto_generate_comments_user;
?>',
                    auto_generate_comments_featured: '<?php
    echo $auto_generate_comments_featured;
?>',
                    auto_generate_comments_popular: '<?php
    echo $auto_generate_comments_popular;
?>',
                    auto_generate_comments_random: '<?php
    echo $auto_generate_comments_random;
?>',
                    auto_generate_comments_manual: '<?php
    echo $auto_generate_comments_manual;
?>',
                    default_category_user: '<?php
    echo $default_category_user;
?>',
                    default_type_user: '<?php
    echo $default_type_user;
?>',
                    auto_categories_user: '<?php
    echo $auto_categories_user;
?>',
                    default_category_popular: '<?php
    echo $default_category_popular;
?>',
                    default_type_popular: '<?php
    echo $default_type_popular;
?>',
                    default_category_random: '<?php
    echo $default_category_random;
?>',
                    default_type_random: '<?php
    echo $default_type_random;
?>',
                    default_category_featured: '<?php
    echo $default_category_featured;
?>',
                    default_type_featured: '<?php
    echo $default_type_featured;
?>',
                    default_category_manual: '<?php
    echo $default_category_manual;
?>',
                    default_type_manual: '<?php
    echo $default_type_manual;
?>',
                    default_category_grouped: '<?php
    echo $default_category_grouped;
?>',
                    default_type_grouped: '<?php
    echo $default_type_grouped;
?>'
}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('#links_hide').is(":checked"))
        {            
            jQuery(".hideGoo").show();
        }
        else
        {
            jQuery(".hideGoo").hide();
        } 
        if(jQuery('#enable_logging').is(":checked"))
        {            
            jQuery(".hideLog").show();
        }
        else
        {
            jQuery(".hideLog").hide();
        }
        if(jQuery('#enable_comments').is(":checked"))
        {            
            jQuery(".hideComm").show();
        }
        else
        {
            jQuery(".hideComm").hide();
        }
        if(jQuery('#enable_comments_user').is(":checked"))
        {            
            jQuery(".hideCommUser").show();
        }
        else
        {
            jQuery(".hideCommUser").hide();
        }
        if(jQuery('#enable_comments_featured').is(":checked"))
        {            
            jQuery(".hideCommFeatured").show();
        }
        else
        {
            jQuery(".hideCommFeatured").hide();
        }
        if(jQuery('#enable_comments_popular').is(":checked"))
        {            
            jQuery(".hideCommPopular").show();
        }
        else
        {
            jQuery(".hideCommPopular").hide();
        }
        if(jQuery('#enable_comments_random').is(":checked"))
        {            
            jQuery(".hideCommRandom").show();
        }
        else
        {
            jQuery(".hideCommRandom").hide();
        }
        if(jQuery('#enable_comments_manual').is(":checked"))
        {            
            jQuery(".hideCommManual").show();
        }
        else
        {
            jQuery(".hideCommManual").hide();
        }
    }
    window.onload = mainChanged;
    var unsaved = false;
    jQuery(document).ready(function () {
        jQuery(":input").change(function(){
            unsaved = true;
        });
        function unloadPage(){ 
            if(unsaved){
                return "You have unsaved changes on this page. Do you want to leave this page and discard your changes or stay on this page?";
            }
        }
        window.onbeforeunload = unloadPage;
    });
</script>
<script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('.midas_image_button').click(function(){
				tb_show('',"media-upload.php?type=image&TB_iframe=true");
			});
			
		});
	</script>
<?php if( isset($_GET['settings-updated']) ) 
{ 
?>
<div id=”message” class=”updated”>
<p style="border-bottom: 6px solid green;background-color: lightgrey;color:green;"><strong>&nbsp;Settings saved.</strong></p>
</div>
<?php 
}
?>
<div ng-app="midsettingsApp" ng-controller="midsettingsController" ng-cloak ng-init="initialized()">
<div class="midas_class">
<table>
    <tr>
    <td>
        <h1><span class="gs-sub-heading"><b>Midas Affiliate Money Generator Plugin Main Switch:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Midas Money Generator Envato Affiliate Plugin. This acts like a main switch.";
?>
                        </div>
                    </div></h1>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="midas_enabled" name="midas_Main_Settings[midas_enabled]" onChange="mainChanged()" <?php
    if ($midas_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="midas_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <table><tr><td>
                    <h3>General Plugin Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the Envato username which will be added to the referral links. Don't have an account? <a href='https://account.envato.com/sign_up' target='_blank'>Sing up!</a>";
?>
                        </div>
                    </div>
                    <b>Envato Referral User Name:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[user_name]" value="<?php echo $user_name;?>" placeholder="Please insert your Envato user name" style="border:6px inset #F7cccE;">
                        
        </div>
        </td></tr><tr><td>
        <hr/></td><td><hr/>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to automatically add referral user name to all envato links in your post contents - this will also replace other referral user names with your own.";
?>
                        </div>
                    </div>
                    <b>Automatically Add Referral to All Links:</b>
                    
                    </td><td>
                    <select id="links_add_ref" name="midas_Main_Settings[links_add_ref]" >
                                  <option value="none"<?php
    if ($links_add_ref == "none") {
        echo " selected";
    }
?>>Disable</option>
                                  <option value="posts"<?php
    if ($links_add_ref == "posts") {
        echo " selected";
    }
?>>Posts</option>
                                  <option value="meta"<?php
    if ($links_add_ref == "meta") {
        echo " selected";
    }
?>>Meta</option>
                                  <option value="all"<?php
    if ($links_add_ref == "all") {
        echo " selected";
    }
?>>All Content</option>
                    </select>    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to show an extended information metabox under every plugin generated post.";
?>
                        </div>
                    </div>
                    <b>Show Extended Item Information Metabox in Post:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_metabox" name="midas_Main_Settings[enable_metabox]"<?php
    if ($enable_metabox == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to cloak URLs with goo.gl link shortener. To lean more about this, please visit <a href='https://developers.google.com/url-shortener/v1/getting_started' target='_blank'>this link</a>.";
?>
                        </div>
                    </div>
                    <b>Hide Referral URLs Using goo.gl:</b>
                    
                    </td><td>
                    <input type="checkbox" id="links_hide" name="midas_Main_Settings[links_hide]" onclick="mainChanged()"<?php
    if ($links_hide == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr><tr><td>
        <div class="hideGoo">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert your goo.gl api key. To lean more about this, please visit <a href='https://developers.google.com/url-shortener/v1/getting_started' target='_blank'>this link</a>.";
?>
                        </div>
                    </div>
                    <b>Goo.gl API key:</b>
                    </div>
                    </td><td>
                    <div class="hideGoo">
                    <input type="text" name="midas_Main_Settings[apiKey]" value="<?php echo $apiKey;?>" placeholder="Please insert your Goo.gl API key">
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable logging for rules?";
?>
                        </div>
                    </div>
                    <b>Enable Logging for Rules:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_logging" name="midas_Main_Settings[enable_logging]" onclick="mainChanged()"<?php
    if ($enable_logging == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideLog">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable detailed logging for rules? Note that this will dramatically increase the size of the log this plugin generates.";
?>
                        </div>
                    </div>
                    <b>Enable Detailed Logging for Rules:</b>
                    </div>
                    </td><td>
                    <div class="hideLog">
                    <input type="checkbox" id="enable_detailed_logging" name="midas_Main_Settings[enable_detailed_logging]"<?php
    if ($enable_detailed_logging == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideLog">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to automatically clear logs after a period of time.";
?>
                        </div>
                    </div>
                    <b>Automatically Clear Logs After:</b>
                    </div>
                    </td><td>
                    <div class="hideLog">
                    <select id="auto_clear_logs" name="midas_Main_Settings[auto_clear_logs]" >
                                  <option value="No"<?php
    if ($auto_clear_logs == "No") {
        echo " selected";
    }
?>>Disabled</option>
                                  <option value="monthly"<?php
    if ($auto_clear_logs == "monthly") {
        echo " selected";
    }
?>>Once a month</option>
                                  <option value="weekly"<?php
    if ($auto_clear_logs == "weekly") {
        echo " selected";
    }
?>>Once a week</option>
                                  <option value="daily"<?php
    if ($auto_clear_logs == "daily") {
        echo " selected";
    }
?>>Once a day</option>
                                  <option value="twicedaily"<?php
    if ($auto_clear_logs == "twicedaily") {
        echo " selected";
    }
?>>Twice a day</option>
                                  <option value="hourly"<?php
    if ($auto_clear_logs == "hourly") {
        echo " selected";
    }
?>>Once an hour</option>
                    </select>    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable automatical updating for generated posts (in case the item developer issues an update)?";
?>
                        </div>
                    </div>
                    <b>Enable Generated Posts Automatical Updating:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="auto_update_posts" name="midas_Main_Settings[auto_update_posts]" >
                                  <option value="No"<?php
    if ($auto_update_posts == "No") {
        echo " selected";
    }
?>>Disabled</option>
                                  <option value="monthly"<?php
    if ($auto_update_posts == "monthly") {
        echo " selected";
    }
?>>Once a month</option>
                                  <option value="weekly"<?php
    if ($auto_update_posts == "weekly") {
        echo " selected";
    }
?>>Once a week</option>
                                  <option value="daily"<?php
    if ($auto_update_posts == "daily") {
        echo " selected";
    }
?>>Once a day</option>
                                  <option value="twicedaily"<?php
    if ($auto_update_posts == "twicedaily") {
        echo " selected";
    }
?>>Twice a day</option>
                                  <option value="hourly"<?php
    if ($auto_update_posts == "hourly") {
        echo " selected";
    }
?>>Once an hour</option>
                    </select>    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the timeout (in seconds) for every rule running. I recommend that you leave this field at it's default value (3600).";
?>
                        </div>
                    </div>
                    <b>Timeout for Rule Running (seconds):</b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" id="rule_timeout" step="1" min="0" name="midas_Main_Settings[rule_timeout]" value="<?php echo $rule_timeout;?>"/>
        </div>
        <br/>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
                        <h3><a name="newest" href="admin.php?page=midas_newest_post_rules">Newest Market Items Rules Settings:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name" name="midas_Main_Settings[post_user_name]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status" name="midas_Main_Settings[submit_status]" >
                                  <option value="pending"<?php
    if ($submit_status == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category" name="midas_Main_Settings[default_category]" ng-model="settings.default_category">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories" name="midas_Main_Settings[auto_categories]"<?php
    if ($auto_categories == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags" name="midas_Main_Settings[auto_tags]"<?php
    if ($auto_tags == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags]" value="<?php echo $default_tags;?>" placeholder="Please insert your additional post tags here" >
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type" name="midas_Main_Settings[default_type]" ng-model="settings.default_type">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image" name="midas_Main_Settings[auto_image]"<?php
    if ($auto_image == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideImage">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert a link to a valid image that will be set for the featured image for the posts that do not have a valid image attached or if you disabled automatical featured image generation. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Default Featured Image if No Image Available for Item:</b>
                    </div>
                    </td><td>
                    <div class="hideImage">
                    <input style="width:345px;" type="url" validator="url" name="midas_Main_Settings[featured_image_default]" placeholder="Please insert the link to a valid image" value="<?php echo $featured_image_default;?>"/>
                    <input class="midas_image_button" type="button" value="Choose image"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments" name="midas_Main_Settings[enable_comments]" onclick="mainChanged()"<?php
    if ($enable_comments == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideComm">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically generate post comments from item's comments feed?";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Imported Comments:</b>
                    </div>
                    </td><td>
                    <div class="hideComm">
                    <select id="auto_generate_comments" name="midas_Main_Settings[auto_generate_comments]" ng-model="settings.auto_generate_comments">
                    <option value="0">Do Not Import Comments</option>
<?php
    for( $i = 1; $i<=50; $i++ ) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
?>                           
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for newest market items. You can use the following shortcodes: %%random_sentence%%, %%random_sentence2%%, %%item_title%%, %%item_description%%, %%item_description_plain_text%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title]" value="<?php echo $post_title;?>"  placeholder="Please insert your desired post title. Example: %%item_title%%">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for newest market items. You can use the following shortcodes: %%random_sentence%%, %%random_sentence2%%, %%see_more_button%%, %%buy_now_button%%, %%video_preview%%, %%video_preview_button%%, %%item_screenshots_button%%, %%item_rotating_preview_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%generate_item_thumbnail%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_description_plain_text%%, %%item_id%%, %%item_media_url%%, %%item_img_url%%, %%item_video_url%%, %%item_thumb_url%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content]" placeholder="Please insert your desired post content. Example:%%item_preview%% %%item_description%%"><?php echo $post_content;?></textarea>
                        
        </div>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
        <h3><a name="user" href="admin.php?page=midas_newest_user">Newest User Items Rules Settings:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_user" name="midas_Main_Settings[post_user_name_user]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_user == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_user" name="midas_Main_Settings[submit_status_user]" >
                                  <option value="pending"<?php
    if ($submit_status_user == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_user == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_user == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_user == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_user == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_user" name="midas_Main_Settings[default_category_user]" ng-model="settings.default_category_user">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_user" name="midas_Main_Settings[auto_categories_user]"<?php
    if ($auto_categories_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_user" name="midas_Main_Settings[auto_tags_user]"<?php
    if ($auto_tags_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_user]" value="<?php echo $default_tags_user;?>" placeholder="Please insert your additional post tags here">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_user" name="midas_Main_Settings[default_type_user]" ng-model="settings.default_type_user">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_user" name="midas_Main_Settings[auto_image_user]"<?php
    if ($auto_image_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideImageUser">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert a link to a valid image that will be set for the featured image for the posts that do not have a valid image attached or if you disabled automatical featured image generation. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Default Featured Image if No Image Available for Item:</b>
                    </div>
                    </td><td>
                    <div class="hideImageUser">
                    <input style="width:345px;" type="url" validator="url" name="midas_Main_Settings[featured_image_user]" placeholder="Please insert the link to a valid image" value="<?php echo $featured_image_user;?>"/>
                    <input class="midas_image_button" type="button" value="Choose image"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_user" name="midas_Main_Settings[enable_comments_user]" onclick="mainChanged()"<?php
    if ($enable_comments_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideCommUser">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically generate post comments from item's comments feed?";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Imported Comments:</b>
                    </div>
                    </td><td>
                    <div class="hideCommUser">
                    <select id="auto_generate_comments_user" name="midas_Main_Settings[auto_generate_comments_user]" ng-model="settings.auto_generate_comments_user">
                    <option value="0">Do Not Import Comments</option>
<?php
    for( $i = 1; $i<=50; $i++ ) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
?>                           
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for user rules. You can use the following shortcodes:  %%random_sentence%%, %%random_sentence2%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_user]" value="<?php echo $post_title_user;?>" placeholder="Please insert your desired post title. Example: %%item_title%%">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for user rules. You can use the following shortcodes: %%random_sentence%%, %%random_sentence2%%, %%see_more_button%%, %%buy_now_button%%, %%video_preview%%, %%video_preview_button%%, %%item_screenshots_button%%, %%item_rotating_preview_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%generate_item_thumbnail%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_description_plain_text%%, %%item_id%%, %%item_media_url%%, %%item_img_url%%, %%item_video_url%%, %%item_thumb_url%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_user]" placeholder="Please insert your desired post content. Example:%%item_preview%% %%item_description%%"><?php echo $post_content_user;?></textarea>
                        
        </div>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
        <h3><a name="popular" href="admin.php?page=midas_popular_items">Popular Market Items Rules Settings:</a></h3>
                </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_popular" name="midas_Main_Settings[post_user_name_popular]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_popular == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_popular" name="midas_Main_Settings[submit_status_popular]" >
                                  <option value="pending"<?php
    if ($submit_status_popular == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_popular == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_popular == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_popular == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_popular == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_popular" name="midas_Main_Settings[default_category_popular]" ng-model="settings.default_category_popular">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_popular" name="midas_Main_Settings[auto_categories_popular]"<?php
    if ($auto_categories_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_popular" name="midas_Main_Settings[auto_tags_popular]"<?php
    if ($auto_tags_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_popular]" value="<?php echo $default_tags_popular;?>" placeholder="Please insert your additional post tags here">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_popular" name="midas_Main_Settings[default_type_popular]" ng-model="settings.default_type_popular">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_popular" name="midas_Main_Settings[auto_image_popular]"<?php
    if ($auto_image_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideImagePopular">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert a link to a valid image that will be set for the featured image for the posts that do not have a valid image attached or if you disabled automatical featured image generation. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Default Featured Image if No Image Available for Item:</b>
                    </div>
                    </td><td>
                    <div class="hideImagePopular">
                    <input style="width:345px;" type="url" validator="url" name="midas_Main_Settings[featured_image_popular]" placeholder="Please insert the link to a valid image" value="<?php echo $featured_image_popular;?>"/>
                    <input class="midas_image_button" type="button" value="Choose image"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_popular" name="midas_Main_Settings[enable_comments_popular]" onclick="mainChanged()"<?php
    if ($enable_comments_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideCommPopular">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically generate post comments from item's comments feed?";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Imported Comments:</b>
                    </div>
                    </td><td>
                    <div class="hideCommPopular">
                    <select id="auto_generate_comments_popular" name="midas_Main_Settings[auto_generate_comments_popular]" ng-model="settings.auto_generate_comments_popular">
                    <option value="0">Do Not Import Comments</option>
<?php
    for( $i = 1; $i<=50; $i++ ) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
?>                           
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for popular item rules. You can use the following shortcodes:  %%random_sentence%%, %%random_sentence2%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_popular]" value="<?php echo $post_title_popular;?>" placeholder="Please insert your desired post title. Example: %%item_title%%">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for popular item rules. You can use the following shortcodes: %%random_sentence%%, %%random_sentence2%%, %%see_more_button%%, %%buy_now_button%%, %%video_preview%%, %%video_preview_button%%, %%item_screenshots_button%%, %%item_rotating_preview_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%generate_item_thumbnail%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_description_plain_text%%, %%item_id%%, %%item_media_url%%, %%item_img_url%%, %%item_video_url%%, %%item_thumb_url%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_popular]" placeholder="Please insert your desired post content. Example:%%item_preview%% %%item_description%%"><?php echo $post_content_popular;?></textarea>
                        
        </div>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
        <h3><a name="random" href="admin.php?page=midas_random_items">Random Market Items Rules Settings:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_random" name="midas_Main_Settings[post_user_name_random]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_random == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_random" name="midas_Main_Settings[submit_status_random]" >
                                  <option value="pending"<?php
    if ($submit_status_random == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_random == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_random == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_random == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_random == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_random" name="midas_Main_Settings[default_category_random]" ng-model="settings.default_category_random">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_random" name="midas_Main_Settings[auto_categories_random]"<?php
    if ($auto_categories_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_random" name="midas_Main_Settings[auto_tags_random]"<?php
    if ($auto_tags_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_random]" value="<?php echo $default_tags_random;?>" placeholder="Please insert your additional post tags here">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_random" name="midas_Main_Settings[default_type_random]" ng-model="settings.default_type_random">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_random" name="midas_Main_Settings[auto_image_random]"<?php
    if ($auto_image_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideImageRandom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert a link to a valid image that will be set for the featured image for the posts that do not have a valid image attached or if you disabled automatical featured image generation. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Default Featured Image if No Image Available for Item:</b>
                    </div>
                    </td><td>
                    <div class="hideImageRandom">
                    <input style="width:345px;" type="url" validator="url" name="midas_Main_Settings[featured_image_random]" placeholder="Please insert the link to a valid image" value="<?php echo $featured_image_random;?>"/>
                    <input class="midas_image_button" type="button" value="Choose image"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_random" name="midas_Main_Settings[enable_comments_random]" onclick="mainChanged()"<?php
    if ($enable_comments_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideCommRandom">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically generate post comments from item's comments feed?";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Imported Comments:</b>
                    </div>
                    </td><td>
                    <div class="hideCommRandom">
                    <select id="auto_generate_comments_random" name="midas_Main_Settings[auto_generate_comments_random]" ng-model="settings.auto_generate_comments_random">
                    <option value="0">Do Not Import Comments</option>
<?php
    for( $i = 1; $i<=50; $i++ ) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
?>                           
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for random item rules. You can use the following shortcodes:  %%random_sentence%%, %%random_sentence2%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_random]" value="<?php echo $post_title_random;?>"  placeholder="Please insert your desired post title. Example: %%item_title%%">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for random item rules. You can use the following shortcodes: %%random_sentence%%, %%random_sentence2%%, %%see_more_button%%, %%buy_now_button%%, %%video_preview%%, %%video_preview_button%%, %%item_screenshots_button%%, %%item_rotating_preview_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%generate_item_thumbnail%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_description_plain_text%%, %%item_id%%, %%item_media_url%%, %%item_img_url%%, %%item_video_url%%, %%item_thumb_url%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_random]" placeholder="Please insert your desired post content. Example:%%item_preview%% %%item_description%%"><?php echo $post_content_random;?></textarea>
                        
        </div>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
        <h3><a name="featured" href="admin.php?page=midas_featured_items">Featured Market Items Rules Settings:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_featured" name="midas_Main_Settings[post_user_name_featured]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_featured == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_featured" name="midas_Main_Settings[submit_status_featured]" >
                                  <option value="pending"<?php
    if ($submit_status_featured == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_featured == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_featured == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_featured == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_featured == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_featured" name="midas_Main_Settings[default_category_featured]" ng-model="settings.default_category_featured">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_featured" name="midas_Main_Settings[auto_categories_featured]"<?php
    if ($auto_categories_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_featured" name="midas_Main_Settings[auto_tags_featured]"<?php
    if ($auto_tags_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_featured]" value="<?php echo $default_tags_featured;?>" placeholder="Please insert your additional post tags here">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_featured" name="midas_Main_Settings[default_type_featured]" ng-model="settings.default_type_featured">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_featured" name="midas_Main_Settings[auto_image_featured]"<?php
    if ($auto_image_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideImageFeatured">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert a link to a valid image that will be set for the featured image for the posts that do not have a valid image attached or if you disabled automatical featured image generation. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Default Featured Image if No Image Available for Item:</b>
                    </div>
                    </td><td>
                    <div class="hideImageFeatured">
                    <input style="width:345px;" type="url" validator="url" name="midas_Main_Settings[featured_image_featured]" placeholder="Please insert the link to a valid image" value="<?php echo $featured_image_featured;?>"/>
                    <input class="midas_image_button" type="button" value="Choose image"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_featured" name="midas_Main_Settings[enable_comments_featured]" onclick="mainChanged()"<?php
    if ($enable_comments_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideCommFeatured">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically generate post comments from item's comments feed?";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Imported Comments:</b>
                    </div>
                    </td><td>
                    <div class="hideCommFeatured">
                    <select id="auto_generate_comments_featured" name="midas_Main_Settings[auto_generate_comments_featured]" ng-model="settings.auto_generate_comments_featured">
                    <option value="0">Do Not Import Comments</option>
<?php
    for( $i = 1; $i<=50; $i++ ) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
?>                           
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for featured item rules. You can use the following shortcodes:  %%random_sentence%%, %%random_sentence2%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_featured]" value="<?php echo $post_title_featured;?>" placeholder="Please insert your desired post title. Example: %%item_title%%">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for featured item rules. You can use the following shortcodes: %%random_sentence%%, %%random_sentence2%%, %%see_more_button%%, %%buy_now_button%%, %%video_preview%%, %%video_preview_button%%, %%item_screenshots_button%%, %%item_rotating_preview_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%generate_item_thumbnail%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_description_plain_text%%, %%item_id%%, %%item_media_url%%, %%item_img_url%%, %%item_video_url%%, %%item_thumb_url%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_featured]" placeholder="Please insert your desired post content. Example:%%item_preview%% %%item_description%%"><?php echo $post_content_featured;?></textarea>
                        
        </div>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
        <h3><a name="manual" href="admin.php?page=midas_manual_items">Manual Items by ID Rules Settings:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_manual" name="midas_Main_Settings[post_user_name_manual]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_manual == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_manual" name="midas_Main_Settings[submit_status_manual]" >
                                  <option value="pending"<?php
    if ($submit_status_manual == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_manual == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_manual == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_manual == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_manual == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_manual" name="midas_Main_Settings[default_category_manual]" ng-model="settings.default_category_manual">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_manual" name="midas_Main_Settings[auto_categories_manual]"<?php
    if ($auto_categories_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_manual" name="midas_Main_Settings[auto_tags_manual]"<?php
    if ($auto_tags_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_manual]" value="<?php echo $default_tags_manual;?>" placeholder="Please insert your additional post tags here">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_manual" name="midas_Main_Settings[default_type_manual]" ng-model="settings.default_type_manual">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_manual" name="midas_Main_Settings[auto_image_manual]"<?php
    if ($auto_image_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideImageManual">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert a link to a valid image that will be set for the featured image for the posts that do not have a valid image attached or if you disabled automatical featured image generation. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Default Featured Image if No Image Available for Item:</b>
                    </div>
                    </td><td>
                    <div class="hideImageManual">
                    <input style="width:345px;" type="url" validator="url" name="midas_Main_Settings[featured_image_manual]" placeholder="Please insert the link to a valid image" value="<?php echo $featured_image_manual;?>"/>
                    <input class="midas_image_button" type="button" value="Choose image"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_manual" name="midas_Main_Settings[enable_comments_manual]" onclick="mainChanged()"<?php
    if ($enable_comments_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideCommManual">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically generate post comments from item's comments feed?";
?>
                        </div>
                    </div>
                    <b>Maximum Number of Imported Comments:</b>
                    </div>
                    </td><td>
                    <div class="hideCommManual">
                    <select id="auto_generate_comments_manual" name="midas_Main_Settings[auto_generate_comments_manual]" ng-model="settings.auto_generate_comments_manual">
                    <option value="0">Do Not Import Comments</option>
<?php
    for( $i = 1; $i<=50; $i++ ) {
        echo '<option value="' . $i . '">' . $i . '</option>';
    }
?>                           
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for manual item rules. You can use the following shortcodes:  %%random_sentence%%, %%random_sentence2%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_manual]" value="<?php echo $post_title_manual;?>"  placeholder="Please insert your desired post title. Example: %%item_title%%">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for manual item rules. You can use the following shortcodes: %%random_sentence%%, %%random_sentence2%%, %%see_more_button%%, %%buy_now_button%%, %%video_preview%%, %%video_preview_button%%, %%item_screenshots_button%%, %%item_rotating_preview_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%generate_item_thumbnail%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_description_plain_text%%, %%item_id%%, %%item_media_url%%, %%item_img_url%%, %%item_video_url%%, %%item_thumb_url%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_manual]" placeholder="Please insert your desired post content. Example:%%item_preview%% %%item_description%%"><?php echo $post_content_manual;?></textarea>
                        
        </div>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
                    </td></tr><tr><td>
        <h3><a name="grouped" href="admin.php?page=midas_group_items">Grouped Item Posts Rules Settings:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_grouped" name="midas_Main_Settings[post_user_name_grouped]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_grouped == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_grouped" name="midas_Main_Settings[submit_status_grouped]" >
                                  <option value="pending"<?php
    if ($submit_status_grouped == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_grouped == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_grouped == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_grouped == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_grouped == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_grouped" name="midas_Main_Settings[default_category_grouped]" ng-model="settings.default_category_grouped">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div style="display:none;">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    </div>
                    </td><td>
                    <div style="display:none;">
                    <input type="checkbox" id="auto_categories_grouped" title="This feature is not supported by this rule type" name="midas_Main_Settings[auto_categories_grouped]"<?php
    if ($auto_categories_grouped == 'on')
        echo ' checked ';
?> disabled>
                        
        </div>
        </td></tr><tr><td>
        <div style="display:none;">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    </div>
                    </td><td>
                    <div style="display:none;">
                    <input type="checkbox" id="auto_tags_grouped" title="This feature is not supported by this rule type" name="midas_Main_Settings[auto_tags_grouped]"<?php
    if ($auto_tags_grouped == 'on')
        echo ' checked ';
?> disabled>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_grouped]" value="<?php echo $default_tags_grouped;?>" placeholder="Please insert your additional post tags here">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_grouped" name="midas_Main_Settings[default_type_grouped]" ng-model="settings.default_type_grouped">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div style="display:none;">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    </div>
                    </td><td>
                    <div style="display:none;">
                    <input type="checkbox" id="auto_image_grouped" title="This feature is not supported by this rule type" name="midas_Main_Settings[auto_image_grouped]"<?php
    if ($auto_image_grouped == 'on')
        echo ' checked ';
?> disabled>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideImageGrouped">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert a link to a valid image that will be set for the featured image for posts. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Featured Image for Posts:</b>
                    </div>
                    </td><td>
                    <div class="hideImageGrouped">
                    <input style="width:345px;" type="url" validator="url" name="midas_Main_Settings[featured_image_grouped]" placeholder="Please insert the link to a valid image" value="<?php echo $featured_image_grouped;?>"/>
                    <input class="midas_image_button" type="button" value="Choose image"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_grouped" name="midas_Main_Settings[enable_comments_grouped]"<?php
    if ($enable_comments_grouped == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr>
        <tr><td>
        <hr/></td><td><hr/></td></tr><tr><td>
        <h3>Random Sentence Generator Settings:</h3>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be sepparated by a new line.";
?>
                        </div>
                    </div>
                    <b>First List of Possible Sentences (%%random_sentence%%):</b>
                    
                    </td><td>
                    <textarea rows="8" cols="70" name="midas_Main_Settings[sentence_list]" placeholder="Please insert the first list of sentences"><?php echo $sentence_list;?></textarea>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be sepparated by a new line.";
?>
                        </div>
                    </div>
                    <b>Second List of Possible Sentences (%%random_sentence2%%):</b>
                    
                    </td><td>
                    <textarea rows="8" cols="70" name="midas_Main_Settings[sentence_list2]" placeholder="Please insert the second list of sentences"><?php echo $sentence_list2;?></textarea>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert some variables you wish to be exchanged for different instances of one sentence. Please format this list as follows:<br/>
Variablename => Variables (seperated by semicolon)<br/>Example:<br/>adjective => clever;interesting;smart;huge;astonishing;unbelievable;nice;adorable;beautiful;elegant;fancy;glamorous;magnificent;helpful;awesome<br/>";
?>
                        </div>
                    </div>
                    <b>List of Possible Variables:</b>
                    
                    </td><td>
                    <textarea rows="8" cols="70" name="midas_Main_Settings[variable_list]" placeholder="Please insert the list of variables"><?php echo $variable_list;?></textarea>
                        
        </div>
        </td></tr></table>
        <hr/>
        <h3>Affiliate Keyword Replacer Settings:</h3>
        <div class="table-responsive">
                    <table class="responsive table" style="overflow-x:auto;width:100%">
				<thead>
					<tr>
                    <th>ID<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This is the ID of the rule.";
?>
                        </div>
                    </div></th>
                    <th>Keyword<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This keyword will be replaced with a link you define.";
?>
                        </div>
                    </div></th>
                    <th>Affiliate Link<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Define the link you want to appear the defined keyword.";
?>
                        </div>
                    </div></th>
					</tr>
                    <tr><td><hr/></td><td><hr/></td><td><hr/></td></tr>
				</thead>
				<tbody>
					<?php echo midas_expand_keyword_rules(); ?>
                    <tr><td><hr/></td><td><hr/></td><td><hr/></td></tr>
					<tr>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;">-</td>
                        <td style="width:45%;text-align:center;vertical-align: middle;"><input type="text" name="midas_keyword_list[keyword][]"  placeholder="Please insert the keyword to be replaced" value="" style="width:100%;" /></td>
						<td style="width:45%;text-align:center;vertical-align: middle;"><input type="url" validator="url" name="midas_keyword_list[link][]" placeholder="Please insert the link to be added to the keyword" value="" style="width:100%;" />
					</tr>
				</tbody>
			</table>
            </div>
        </div>
        </div>
         <hr/>
         <a href="http://market.envato.com/" target="_blank">Sign in into your Envato Account to view your earnings!</a><br/><br/>
         <div>You can also use the following shortcodes in your content: <b>[midas_author]</b>, <b>[midas_item]</b>, <b>[midas_item_card] and <b>[midas_item_thumbnail]</b></b>. <br/>Use the [midas_author] shortcode to display relevant information about an author you enter.<br/>Use the [midas_item] shortcode to display relevant information about an item you enter. <br/>Use the [midas_item_thumbnail] shortcode to display the entered item's thumbnail with an Envato style popup on mouse over with the item's relevant information. <br/>Use the [midas_item_card] shortcode to display a card with information about the item which ID you entered. <br/> Example of shortcode usage: <b>[midas_author user=coderevolution followers=on image=on thumbnail=on country=on location=on sales=on], [midas_item_thumbnail item="19200046"], [midas_item_card item="19200046"] or [midas_item item="19200046" image=on thumbnail=on sales=on author=on  rating=on cost=on tags=on category=on uploaded_on=on last_update=on]</b>. For details about the shortcodes, please see the plugin help file.</div>
<div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
if (isset($_POST['midas_keyword_list'])) {
	add_action('admin_init', 'midas_save_keyword_rules');
}
function midas_save_keyword_rules($data2) {
            $data2 = $_POST['midas_keyword_list'];
			$rules = array();
            if(isset($data2['keyword'][0]))
            {
                for($i = 0; $i < sizeof($data2['keyword']); ++$i) {
                    if(isset($data2['keyword'][$i]) && $data2['keyword'][$i] != '')
                    {
                        $index = trim( sanitize_text_field($data2['keyword'][$i]));
                        $rules[$index] = trim( sanitize_text_field( $data2['link'][$i] ) );
                    }
                }
            }
            update_option('midas_keyword_list', $rules);
		}
function midas_expand_keyword_rules() {
			$rules = get_option('midas_keyword_list');
			$output = '';
            $cont = 0;
			if (!empty($rules)) {
				foreach ($rules as $request => $value) {  
					$output .= '<tr>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;">' . $cont . '</td>
                        <td style="width:45%;text-align:center;vertical-align: middle;"><input type="text" name="midas_keyword_list[keyword][]" value="'.$request.'" required  style="width:100%;"></td>
                        <td style="width:45%;text-align:center;vertical-align: middle;"><input type="url" validator="url" name="midas_keyword_list[link][]" value="'.$value.'" required  style="width:100%;"></td>
					</tr>';
                    $cont++;
				}
			}
			return $output;
		}
?>