<?php
function midas_admin_settings()
{
    $language_names=array("Disabled (English)","Afrikaans","Albanian","Arabic","Armenian","Belarusian","Bulgarian","Catalan","Chinese","Croatian","Czech","Danish","Dutch","English","Estonian","Filipino","Finnish","French","Galician","German","Greek","Hebrew","Hindi","Hungarian","Icelandic","Indonesian","Irish","Italian","Japanese","Korean","Latvian","Lithuanian","Norwegian","Macedonian","Malay","Maltese","Persian","Polish","Portuguese","Romanian","Russian","Serbian","Slovak","Slovenian","Spanish","Swahili","Swedish","Thai","Turkish","Ukrainian","Vietnamese","Welsh","Yiddish");
	$language_codes=array("disabled","af","sq","ar","hy","be","bg","ca","zh-CN","hr","cs","da","nl","en","et","tl","fi","fr","gl","de","el","iw","hi","hu","is","id","ga","it","ja","ko","lv","lt","no","mk","ms","mt","fa","pl","pt","ro","ru","sr","sk","sl","es","sw","sv","th","tr","uk","vi","cy","yi");
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('midas_option_group');
    do_settings_sections('midas_option_group');
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled'])) {
        $midas_enabled = $midas_Main_Settings['midas_enabled'];
    } else {
        $midas_enabled = '';
    }
    if (isset($midas_Main_Settings['user_name'])) {
        $user_name = $midas_Main_Settings['user_name'];
    } else {
        $user_name = '';
    }
    if (isset($midas_Main_Settings['links_add_ref'])) {
        $links_add_ref = $midas_Main_Settings['links_add_ref'];
    } else {
        $links_add_ref = '';
    }
    if (isset($midas_Main_Settings['links_hide'])) {
        $links_hide = $midas_Main_Settings['links_hide'];
    } else {
        $links_hide = '';
    }
    if (isset($midas_Main_Settings['apiKey'])) {
        $apiKey = $midas_Main_Settings['apiKey'];
    } else {
        $apiKey = '';
    }
    if (isset($midas_Main_Settings['enable_metabox'])) {
        $enable_metabox = $midas_Main_Settings['enable_metabox'];
    } else {
        $enable_metabox = '';
    }
    if (isset($midas_Main_Settings['variable_list'])) {
        $variable_list = $midas_Main_Settings['variable_list'];
    } else {
        $variable_list = '';
    }
    if (isset($midas_Main_Settings['sentence_list'])) {
        $sentence_list = $midas_Main_Settings['sentence_list'];
    } else {
        $sentence_list = '';
    }
    if (isset($midas_Main_Settings['sentence_list2'])) {
        $sentence_list2 = $midas_Main_Settings['sentence_list2'];
    } else {
        $sentence_list2 = '';
    }
    if (isset($midas_Main_Settings['enable_logging'])) {
        $enable_logging = $midas_Main_Settings['enable_logging'];
    } else {
        $enable_logging = '';
    }
    if (isset($midas_Main_Settings['auto_clear_logs'])) {
        $auto_clear_logs = $midas_Main_Settings['auto_clear_logs'];
    } else {
        $auto_clear_logs = '';
    }
    if (isset($midas_Main_Settings['enable_detailed_logging'])) {
        $enable_detailed_logging = $midas_Main_Settings['enable_detailed_logging'];
    } else {
        $enable_detailed_logging = '';
    }
    if (isset($midas_Main_Settings['auto_update_posts'])) {
        $auto_update_posts = $midas_Main_Settings['auto_update_posts'];
    } else {
        $auto_update_posts = '';
    }
    if (isset($midas_Main_Settings['rule_timeout'])) {
        $rule_timeout = $midas_Main_Settings['rule_timeout'];
    } else {
        $rule_timeout = '';
    }
    if (isset($midas_Main_Settings['email_address'])) {
        $email_address = $midas_Main_Settings['email_address'];
    } else {
        $email_address = '';
    }
    if (isset($midas_Main_Settings['send_email'])) {
        $send_email = $midas_Main_Settings['send_email'];
    } else {
        $send_email = '';
    }
    if (isset($midas_Main_Settings['envato_token'])) {
        $envato_token = $midas_Main_Settings['envato_token'];
    } else {
        $envato_token = '';
    }
    if (isset($midas_Main_Settings['translate'])) {
        $translate = $midas_Main_Settings['translate'];
    } else {
        $translate = '';
    }
    if (isset($midas_Main_Settings['spin_text'])) {
        $spin_text = $midas_Main_Settings['spin_text'];
    } else {
        $spin_text = '';
    }
    if (isset($midas_Main_Settings['best_user'])) {
        $best_user = $midas_Main_Settings['best_user'];
    } else {
        $best_user = '';
    }
    if (isset($midas_Main_Settings['best_password'])) {
        $best_password = $midas_Main_Settings['best_password'];
    } else {
        $best_password = '';
    }
    if (isset($midas_Main_Settings['max_word_content'])) {
        $max_word_content = $midas_Main_Settings['max_word_content'];
    } else {
        $max_word_content = '';
    }
    if (isset($midas_Main_Settings['min_word_content'])) {
        $min_word_content = $midas_Main_Settings['min_word_content'];
    } else {
        $min_word_content = '';
    }
    if (isset($midas_Main_Settings['max_word_title'])) {
        $max_word_title = $midas_Main_Settings['max_word_title'];
    } else {
        $max_word_title = '';
    }
    if (isset($midas_Main_Settings['min_word_title'])) {
        $min_word_title = $midas_Main_Settings['min_word_title'];
    } else {
        $min_word_title = '';
    }
    if (isset($midas_Main_Settings['required_words'])) {
        $required_words = $midas_Main_Settings['required_words'];
    } else {
        $required_words = '';
    }
    if (isset($midas_Main_Settings['banned_words'])) {
        $banned_words = $midas_Main_Settings['banned_words'];
    } else {
        $banned_words = '';
    }
?>
<script>
                var midas_admin_json = {
}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        }
        if(jQuery('#links_hide').is(":checked"))
        {            
            jQuery(".hideGoo").show();
        }
        else
        {
            jQuery(".hideGoo").hide();
        } 
        if(jQuery('#enable_logging').is(":checked"))
        {            
            jQuery(".hideLog").show();
        }
        else
        {
            jQuery(".hideLog").hide();
        }
        if(jQuery('#send_email').is(":checked"))
        {            
            jQuery(".hideMail").show();
        }
        else
        {
            jQuery(".hideMail").hide();
        }
        if(jQuery("#spin_text option:selected").val() === 'best') 
        {      
            jQuery(".hideBest").show();
        }
        else
        {
            jQuery(".hideBest").hide();
        }
    }
    jQuery(document).ready(function(){
					jQuery('span.wpmidas-delete').html('X').css({'color':'red','cursor':'pointer'}).click(function(){
						var confirm_delete = confirm('Delete This Rule?');
						if (confirm_delete) {
							jQuery(this).parent().parent().remove();
							jQuery('#myForm').submit();						
						}
					});
				});
    window.onload = mainChanged;
    var unsaved = false;
    jQuery(document).ready(function () {
        jQuery(":input").change(function(){
            unsaved = true;
        });
        function unloadPage(){ 
            if(unsaved){
                return "You have unsaved changes on this page. Do you want to leave this page and discard your changes or stay on this page?";
            }
        }
        window.onbeforeunload = unloadPage;
        
    });
</script>
<script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('.midas_image_button').click(function(){
				tb_show('',"media-upload.php?type=image&TB_iframe=true");
			});
		});
	</script>
<?php if( isset($_GET['settings-updated']) ) 
{ 
?>
<div id=”message” class=”updated”>
<p style="border-bottom: 6px solid green;background-color: lightgrey;color:green;"><strong>&nbsp;Settings saved.</strong></p>
</div>
<?php 
}
?>
<div ng-app="midsettingsApp" ng-controller="midsettingsController" ng-cloak ng-init="initialized()">
<div class="midas_class">
    <div class="table-responsive">
<table class="responsive table" style="width:100%;white-space:normal;">
    <tr>
    <td>
        <h1><span class="gs-sub-heading"><b>'Hand of Midas' Affiliate Money Generator Plugin Main Switch:</b>&nbsp;</span>
        <span style="font-size:0.7em;">v1.7&nbsp;</span><div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Midas Money Generator Envato Affiliate Plugin. This acts like a main switch.";
?>
                        </div>
                    </div></h1>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="midas_enabled" name="midas_Main_Settings[midas_enabled]" onChange="mainChanged()" <?php
    if ($midas_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="midas_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    </div>
                    <div class="hideMain">
                    <hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
                        <div class="table-responsive">
                    <table class="responsive table" style="width:100%;white-space:normal;"><tr><td>
                    <h3>General Plugin Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the Envato username which will be added to the referral links. Don't have an account? <a href='https://account.envato.com/sign_up' target='_blank'>Sing up!</a>";
?>
                        </div>
                    </div>
                    <b>Envato Referral User Name:</b>
                    
                    </td><td>
                    <input style="width:63%;max-width:335px;" type="text" name="midas_Main_Settings[user_name]" value="<?php echo $user_name;?>" placeholder="Please insert your Envato user name" style="border:6px inset #F7cccE;">
                    <input style="width:30%;" type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="Save Username"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Get your token <a href='https://build.envato.com/create-token/' target='_blank'>HERE</a>. Just choose the token name, accept the terms and click 'Create Token' (no additional token rights are required). Note that this is required only for the 'Keyword Search Items Rules' creation and running - all other plugin functionality will still work if you leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Envato Authorization Token:</b>
                    
                    </td><td>
                    <input style="width:63%;max-width:335px;" type="text" name="midas_Main_Settings[envato_token]" value="<?php echo $envato_token;?>" placeholder="Please insert your Envato Token here" style="border:6px inset #F7cccE;">
                    <input style="width:30%;" type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="Save Token"/>
        </div>
        </td></tr><tr><td>
        <hr/></td><td><hr/>
        </td></tr><tr><td>
        <h3>After you saved your username, you can start creating rules:</h3></td></tr><tr><td><a name="newest" href="admin.php?page=midas_newest_post_rules">Newest Market Item Rules</a></td><td>(from newest items on Envato Marketplaces)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Items will be generated from the 'Newest Items' feeds from the Envato Marketplaces. Example source from CodeCanyon: <a href='https://codecanyon.net/category/all' target='_blank'>https://codecanyon.net/category/all</a>.";
?>
                        </div>
                    </div></td></tr><tr><td><a name="user" href="admin.php?page=midas_newest_user">Newest User Item Rules</a></td><td>(from newest items from specified users)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Items will be generated from the 'Newest Items' feeds from a specific user. Example source from CodeRevolution: <a href='https://codecanyon.net/user/coderevolution/portfoli' target='_blank'>https://codecanyon.net/user/coderevolution/portfolio</a>";
?>
                        </div>
                    </div></td></tr><tr><td><a name="popular" href="admin.php?page=midas_popular_items">Popular Item Rules</a></td><td>(from popular items on Envato Marketplaces)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Items will be generated from the 'Popular Items' feeds from the Envato Marketplaces. Example source from CodeCanyon: <a href='https://codecanyon.net/page/top_sellers' target='_blank'>https://codecanyon.net/page/top_sellers</a>";
?>
                        </div>
                    </div></td></tr><tr><td><a name="random" href="admin.php?page=midas_random_items">Random Item Rules</a></td><td>(from random items on Envato Marketplaces)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Items will be generated from the 'Random Items' feeds from the Envato Marketplaces. Example source from CodeCanyon: <a href='https://marketplace.envato.com/api/v3/random-new-files:codecanyon.json' target='_blank'>https://marketplace.envato.com/api/v3/random-new-files:codecanyon.json</a>";
?>
                        </div>
                    </div></td></tr><tr><td><a name="featured" href="admin.php?page=midas_featured_items">Featured Item Rules</a></td><td>(from featured items on Envato Marketplaces)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Items will be generated from the 'Featured Items' feeds from the Envato Marketplaces. Example source from CodeCanyon: <a href='https://codecanyon.net/feature' target='_blank'>https://codecanyon.net/feature</a>";
?>
                        </div>
                    </div></td></tr><tr><td><a name="manual" href="admin.php?page=midas_manual_items">Manual Item Rules</a></td><td>(from an item ID you introduce)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "How to get an item's ID? The item's ID is the number placed at the end of the item's marketplace URL. ex: <a href='https://codecanyon.net/item/hand-of-midas-envato-affiliate-money-generator-plugin/19384306' target='_blank'>https://codecanyon.net/item/hand-of-midas-envato-affiliate-money-generator-plugin/<span style='color:red'>19384306</span></a>. In this case, the item's ID is <span style='color:red'>19384306</span>.";
?>
                        </div>
                    </div></td></tr><tr><td><a name="grouped" href="admin.php?page=midas_group_items">Grouped Item Rules</a></td><td>(generated one post including more items - based on item ID)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "How to get an item's ID? The item's ID is the number placed at the end of the item's marketplace URL. ex: <a href='https://codecanyon.net/item/hand-of-midas-envato-affiliate-money-generator-plugin/19384306' target='_blank'>https://codecanyon.net/item/hand-of-midas-envato-affiliate-money-generator-plugin/<span style='color:red'>19384306</span></a>. In this case, the item's ID is <span style='color:red'>19384306</span>.";
?>
                        </div>
                    </div></td></tr><tr><td><a name="grouped" href="admin.php?page=midas_keyword_search">Keyword Search Items Rules</a></td><td>(generates posts based on search keyword queries)<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This feature requires you to input an Envato Authorization Token. After that, you can input search terms and select a marketplace. Posts will be generated based on the search results on that marketplace.";
?>
                        </div>
                    </div></td></tr><tr><td>
        <hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/></td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
        <h3>General Plugin Features Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to automatically add referral user name to all envato links in your post contents - this will also replace other referral user names with your own.";
?>
                        </div>
                    </div>
                    <b>Automatically Add Referral to All Links:</b>
                    
                    </td><td>
                    <select id="links_add_ref" name="midas_Main_Settings[links_add_ref]" >
                                  <option value="none"<?php
    if ($links_add_ref == "none") {
        echo " selected";
    }
?>>Disable</option>
                                  <option value="posts"<?php
    if ($links_add_ref == "posts") {
        echo " selected";
    }
?>>Posts</option>
                                  <option value="meta"<?php
    if ($links_add_ref == "meta") {
        echo " selected";
    }
?>>Meta</option>
                                  <option value="all"<?php
    if ($links_add_ref == "all") {
        echo " selected";
    }
?>>All Content</option>
                    </select>    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to show an extended information metabox under every plugin generated post.";
?>
                        </div>
                    </div>
                    <b>Show Extended Item Information Metabox in Post:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_metabox" name="midas_Main_Settings[enable_metabox]"<?php
    if ($enable_metabox == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to cloak URLs with goo.gl link shortener. To lean more about this, please visit <a href='https://developers.google.com/url-shortener/v1/getting_started' target='_blank'>this link</a>.";
?>
                        </div>
                    </div>
                    <b>Hide Referral URLs Using goo.gl:</b>
                    
                    </td><td>
                    <input type="checkbox" id="links_hide" name="midas_Main_Settings[links_hide]" onclick="mainChanged()"<?php
    if ($links_hide == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr><tr><td>
        <div class="hideGoo">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert your goo.gl api key. To lean more about this, please visit <a href='https://developers.google.com/url-shortener/v1/getting_started' target='_blank'>this link</a>.";
?>
                        </div>
                    </div>
                    <b>Goo.gl API key:</b>
                    </div>
                    </td><td>
                    <div class="hideGoo">
                    <input type="text" name="midas_Main_Settings[apiKey]" value="<?php echo $apiKey;?>" placeholder="Please insert your Goo.gl API key">
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable logging for rules?";
?>
                        </div>
                    </div>
                    <b>Enable Logging for Rules:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_logging" name="midas_Main_Settings[enable_logging]" onclick="mainChanged()"<?php
    if ($enable_logging == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideLog">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable detailed logging for rules? Note that this will dramatically increase the size of the log this plugin generates.";
?>
                        </div>
                    </div>
                    <b>Enable Detailed Logging for Rules:</b>
                    </div>
                    </td><td>
                    <div class="hideLog">
                    <input type="checkbox" id="enable_detailed_logging" name="midas_Main_Settings[enable_detailed_logging]"<?php
    if ($enable_detailed_logging == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div class="hideLog">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to automatically clear logs after a period of time.";
?>
                        </div>
                    </div>
                    <b>Automatically Clear Logs After:</b>
                    </div>
                    </td><td>
                    <div class="hideLog">
                    <select id="auto_clear_logs" name="midas_Main_Settings[auto_clear_logs]" >
                                  <option value="No"<?php
    if ($auto_clear_logs == "No") {
        echo " selected";
    }
?>>Disabled</option>
                                  <option value="monthly"<?php
    if ($auto_clear_logs == "monthly") {
        echo " selected";
    }
?>>Once a month</option>
                                  <option value="weekly"<?php
    if ($auto_clear_logs == "weekly") {
        echo " selected";
    }
?>>Once a week</option>
                                  <option value="daily"<?php
    if ($auto_clear_logs == "daily") {
        echo " selected";
    }
?>>Once a day</option>
                                  <option value="twicedaily"<?php
    if ($auto_clear_logs == "twicedaily") {
        echo " selected";
    }
?>>Twice a day</option>
                                  <option value="hourly"<?php
    if ($auto_clear_logs == "hourly") {
        echo " selected";
    }
?>>Once an hour</option>
                    </select>    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable automatical updating for generated posts (in case the item developer issues an update)?";
?>
                        </div>
                    </div>
                    <b>Enable Generated Posts Automatical Updating:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="auto_update_posts" name="midas_Main_Settings[auto_update_posts]" >
                                  <option value="No"<?php
    if ($auto_update_posts == "No") {
        echo " selected";
    }
?>>Disabled</option>
                                  <option value="monthly"<?php
    if ($auto_update_posts == "monthly") {
        echo " selected";
    }
?>>Once a month</option>
                                  <option value="weekly"<?php
    if ($auto_update_posts == "weekly") {
        echo " selected";
    }
?>>Once a week</option>
                                  <option value="daily"<?php
    if ($auto_update_posts == "daily") {
        echo " selected";
    }
?>>Once a day</option>
                                  <option value="twicedaily"<?php
    if ($auto_update_posts == "twicedaily") {
        echo " selected";
    }
?>>Twice a day</option>
                                  <option value="hourly"<?php
    if ($auto_update_posts == "hourly") {
        echo " selected";
    }
?>>Once an hour</option>
                    </select>    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the timeout (in seconds) for every rule running. I recommend that you leave this field at it's default value (3600), unless you use all of this plugin's functionality at once. If you leave this field blank, default value will apply.";
?>
                        </div>
                    </div>
                    <b>Timeout for Rule Running (seconds):</b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" id="rule_timeout" step="1" min="0" placeholder="Insert rule timeout in seconds" name="midas_Main_Settings[rule_timeout]" value="<?php echo $rule_timeout;?>"/>
        </div>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to receive a summary of the rule running in an email.";
?>
                        </div>
                    </div>
                    <b>Send Rule Running Summary in Email:</b>
                    
                    </td><td>
                    <input type="checkbox" id="send_email" name="midas_Main_Settings[send_email]" onclick="mainChanged()"<?php
    if ($send_email == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr><tr><td>
                    <div class="hideMail">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Input the email adress where you want to send the report. You can input more email addresses, separated by commas.";
?>
                        </div>
                    </div>
                    <b>Email Address:</b>
<?php
    $mailResult = false;
    $mailResult = wp_mail('you@example.com', 'How are you', 'Hurray');
    echo $mailResult ? '<div class="tooltip">Mail sending OK!
  <span class="tooltiptext">Automatic test e-mail was sent! Mail sending is working!</span>
</div>' : '<div class="tooltip">Issue detected!
  <span class="tooltiptext">Automatic test email cannot be sent! Please verify your WordPress e-mailing feature configuration!</span>
</div>';
?>
                    </div>
                    </td><td>
                    <div class="hideMail">
                    <input type="email" id="email_address" name="midas_Main_Settings[email_address]" placeholder="Input an email adress" value="<?php echo $email_address;?>">
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the minimum word count for post titles. Items that have less than this count will not be published. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Minimum Title Word Count:</b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" id="min_word_title" step="1" min="0" placeholder="Input the minimum word count in the title" name="midas_Main_Settings[min_word_title]" value="<?php echo $min_word_title;?>"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the maximum word count for post titles. Items that have more than this count will not be published. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Maximum Title Word Count:</b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" id="max_word_title" step="1" min="0" placeholder="Input the maximum word count in the title" name="midas_Main_Settings[max_word_title]" value="<?php echo $max_word_title;?>"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the minimum word count for post content. Items that have less than this count will not be published. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Minimum Content Word Count:</b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" id="min_word_content" step="1" min="0" placeholder="Input the minimum word count in the content" = name="midas_Main_Settings[min_word_content]" value="<?php echo $min_word_content;?>"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the maximum word count for post content. Items that have more than this count will not be published. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Maximum Content Word Count:</b>
                    </div>
                    </td><td>
                    <div>
                    <input type="number" id="max_word_content" step="1" min="0" placeholder="Input the maximum word count in the content" name="midas_Main_Settings[max_word_content]" value="<?php echo $max_word_content;?>"/>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do not include posts that's title or content contains at least one of these words. Separate words by comma. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Banned Words List:</b>
                    
                    </td><td>
                    <textarea rows="1" name="midas_Main_Settings[banned_words]" placeholder="Do not generate posts that contain at least one of these words"><?php echo $banned_words;?></textarea>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do not include posts that's title or content does not contain at least one of these words. Separate words by comma. To disable this feature, leave this field blank.";
?>
                        </div>
                    </div>
                    <b>Required Words List:</b>
                    
                    </td><td>
                    <textarea rows="1" name="midas_Main_Settings[required_words]" placeholder="Do not generate posts unless they contain all of these words"><?php echo $required_words;?></textarea>
                        
        </div>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically translate generated content using Google Translate?";
?>
                        </div>
                    </div>
                    <b>Automatically Translate Content To:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="translate" name="midas_Main_Settings[translate]" >
<?php
    $i=0;
	foreach($language_names as $lang){
        echo '<option value="' . $language_codes[$i] . '"'; 
        if($translate == $language_codes[$i])
        {
            echo ' selected';
        }
        echo '>' . $language_names[$i] . '</option>';
        $i++;
    }
?>
            </select>
        </div>
        </td></tr><tr><td>
                    <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to randomize text by changing words of a text with synonyms using one of the listed methods? Note that this is an experimental feature and can in some instances drastically increase the rule running time!";
?>
                        </div>
                    </div>
                    <b>Spin Text Using Word Synonyms:</b>
                    
                    </td><td>
                    <select id="spin_text" name="midas_Main_Settings[spin_text]" onchange="mainChanged()">
                    <option value="disabled"
<?php
if($spin_text == 'disabled')
        {
            echo ' selected';
        }
?>
>Disabled</option>
                    <option value="best"
<?php
if($spin_text == 'best')
        {
            echo ' selected';
        }
?>
>The Best Spinner - High Quality - Paid</option>
                    <option value="wikisynonyms"
<?php
if($spin_text == 'wikisynonyms')
        {
            echo ' selected';
        }
?>
>WikiSynonyms - Medium Quality - Free</option>
                    <option value="freethesaurus"
<?php
if($spin_text == 'freethesaurus')
        {
            echo ' selected';
        }
?>
>FreeThesaurus - Low Quality - Free</option>
                    </select>
        </div>
        </td></tr><tr><td>
        <div class="hideBest">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert your user name on 'The Best Spinner'. You can get one <a href='http://www.thebestspinner.com/' target='_alt'>here</a> (premium/paid service).";
?>
                        </div>
                    </div>
                    <b>'The Best Spinner' User Name:</b>
                    </div>
                    </td><td>
                    <div class="hideBest">
                    <input type="text" name="midas_Main_Settings[best_user]" value="<?php echo $best_user;?>" placeholder="Please insert your 'The Best Spinner' user name">
        </div>
        </td></tr><tr><td>
        <div class="hideBest">
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert your password on 'The Best Spinner'. You can get one <a href='http://www.thebestspinner.com/' target='_alt'>here</a> (premium/paid service).";
?>
                        </div>
                    </div>
                    <b>'The Best Spinner' Password:</b>
                    </div>
                    </td><td>
                    <div class="hideBest">
                    <input type="text" name="midas_Main_Settings[best_password]" value="<?php echo $best_password;?>" placeholder="Please insert your 'The Best Spinner' password">
        </div>
        </td></tr>
        </td></tr><tr><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/> </td><td><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        </td></tr><tr><td>
        <h3>Random Sentence Generator Settings:</h3>
        </td></tr>
        <tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be sepparated by a new line.";
?>
                        </div>
                    </div>
                    <b>First List of Possible Sentences (%%random_sentence%%):</b>
                    
                    </td><td>
                    <textarea rows="8" cols="70" name="midas_Main_Settings[sentence_list]" placeholder="Please insert the first list of sentences"><?php echo $sentence_list;?></textarea>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert some sentences from which you want to get one at random. You can also use variables defined below. %something ==> is a variable. Each sentence must be sepparated by a new line.";
?>
                        </div>
                    </div>
                    <b>Second List of Possible Sentences (%%random_sentence2%%):</b>
                    
                    </td><td>
                    <textarea rows="8" cols="70" name="midas_Main_Settings[sentence_list2]" placeholder="Please insert the second list of sentences"><?php echo $sentence_list2;?></textarea>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert some variables you wish to be exchanged for different instances of one sentence. Please format this list as follows:<br/>
Variablename => Variables (seperated by semicolon)<br/>Example:<br/>adjective => clever;interesting;smart;huge;astonishing;unbelievable;nice;adorable;beautiful;elegant;fancy;glamorous;magnificent;helpful;awesome<br/>";
?>
                        </div>
                    </div>
                    <b>List of Possible Variables:</b>
                    
                    </td><td>
                    <textarea rows="8" cols="70" name="midas_Main_Settings[variable_list]" placeholder="Please insert the list of variables"><?php echo $variable_list;?></textarea>
                        
        </div>
        </td></tr></table></div>
        <hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
        <h3>Affiliate Keyword Replacer Tool Settings:</h3>
        <div class="table-responsive">
                    <table class="responsive table" style="overflow-x:auto;width:100%">
				<thead>
					<tr>
                    <th>ID<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This is the ID of the rule.";
?>
                        </div>
                    </div></th>
                    <th style="max-width:40px;">Del<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to delete this rule?";
?>
                        </div>
                    </div></th>
                    <th>Search Keyword<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This keyword will be replaced with a link you define.";
?>
                        </div>
                    </div></th>
                    <th>Replacement Keyword<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This keyword will replace the search keyword you define. Leave this field blank if you only want to add an URL to the specified keyword.";
?>
                        </div>
                    </div></th>
                    <th>Link to Add<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Define the link you want to appear the defined keyword. Leave this field blank if you only want to replace the specified keyword without linking from it.";
?>
                        </div>
                    </div></th>
					</tr>
                    <tr><td><hr/></td><td><hr/></td><td><hr/></td><td><hr/></td><td><hr/></td></tr>
				</thead>
				<tbody>
					<?php echo midas_expand_keyword_rules(); ?>
                    <tr><td><hr/></td><td><hr/></td><td><hr/></td><td><hr/></td><td><hr/></td></tr>
					<tr>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;">-</td>
                        <td style="max-width:20px;text-align: center;" ><span style="max-width:20px;color:gray;" >X</span></td>
                        <td style="width:30%;text-align:center;vertical-align: middle;"><input type="text" name="midas_keyword_list[keyword][]"  placeholder="Please insert the keyword to be replaced" value="" style="width:100%;" /></td>
                        <td style="width:30%;text-align:center;vertical-align: middle;"><input type="text" name="midas_keyword_list[replace][]"  placeholder="Please insert the keyword to replace the search keyword" value="" style="width:100%;" /></td>
						<td style="width:30%;text-align:center;vertical-align: middle;"><input type="url" validator="url" name="midas_keyword_list[link][]" placeholder="Please insert the link to be added to the keyword" value="" style="width:100%;" />
					</tr>
				</tbody>
			</table>
            </div>
        </div>
        </div>
         <hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>
         <a href="http://market.envato.com/" target="_blank">Sign in into your Envato Account to view your earnings!</a><br/><br/>
         <div>You can also use the following shortcodes in your content: <b>[midas_author]</b>, <b>[midas_item]</b>, <b>[midas_item_card] and <b>[midas_item_thumbnail]</b></b>. <br/>Use the [midas_author] shortcode to display relevant information about an author you enter.<br/>Use the [midas_item] shortcode to display relevant information about an item you enter. <br/>Use the [midas_item_thumbnail] shortcode to display the entered item's thumbnail with an Envato style popup on mouse over with the item's relevant information. <br/>Use the [midas_item_card] shortcode to display a card with information about the item which ID you entered. <br/> Example of shortcode usage: <b>[midas_author user=coderevolution followers=on image=on thumbnail=on country=on location=on sales=on], [midas_item_thumbnail item="19200046"], [midas_item_card item="19200046"] or [midas_item item="19200046" image=on thumbnail=on sales=on author=on  rating=on cost=on tags=on category=on uploaded_on=on last_update=on]</b>. For details about the shortcodes, please see the plugin help file.</div>
         <div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" onclick="unsaved = false;" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
if (isset($_POST['midas_keyword_list'])) {
	add_action('admin_init', 'midas_save_keyword_rules');
}
function midas_save_keyword_rules($data2) {
            $data2 = $_POST['midas_keyword_list'];
			$rules = array();
            if(isset($data2['keyword'][0]))
            {
                for($i = 0; $i < sizeof($data2['keyword']); ++$i) {
                    if(isset($data2['keyword'][$i]) && $data2['keyword'][$i] != '')
                    {
                        $index = trim( sanitize_text_field($data2['keyword'][$i]));
                        $rules[$index] = array(trim( sanitize_text_field( $data2['link'][$i] ) ), trim( sanitize_text_field( $data2['replace'][$i] ) ));
                    }
                }
            }
            update_option('midas_keyword_list', $rules);
		}
function midas_expand_keyword_rules() {
			$rules = get_option('midas_keyword_list');
			$output = '';
            $cont = 0;
			if (!empty($rules)) {
				foreach ($rules as $request => $value) {  
					$output .= '<tr>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;">' . $cont . '</td>
                        <td style="max-width:20px;text-align: center;"><span class="wpmidas-delete"></span></td>
                        <td style="width:30%;text-align:center;vertical-align: middle;"><input type="text" placeholder="Please insert the keyword to be replaced" name="midas_keyword_list[keyword][]" value="'.$request.'" required style="width:100%;"></td>
                        <td style="width:30%;text-align:center;vertical-align: middle;"><input type="text" placeholder="Please insert the keyword to replace the search keyword" name="midas_keyword_list[replace][]" value="'.$value[1].'" style="width:100%;"></td>
                        <td style="width:30%;text-align:center;vertical-align: middle;"><input type="url" validator="url" placeholder="Please insert the link to be added to the keyword" name="midas_keyword_list[link][]" value="'.$value[0].'" style="width:100%;"></td>
					</tr>';
                    $cont++;
				}
			}
			return $output;
		}
?>