<?php
function midas_admin_settings()
{
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
        <form id="myForm" method="post" action="options.php">
<?php
    settings_fields('midas_option_group');
    do_settings_sections('midas_option_group');
    $midas_Main_Settings = get_option('midas_Main_Settings', false);
    if (isset($midas_Main_Settings['midas_enabled'])) {
        $midas_enabled = $midas_Main_Settings['midas_enabled'];
    } else {
        $midas_enabled = '';
    }
    if (isset($midas_Main_Settings['submit_status'])) {
        $submit_status = $midas_Main_Settings['submit_status'];
    } else {
        $submit_status = '';
    }
    if (isset($midas_Main_Settings['default_category'])) {
        $default_category = $midas_Main_Settings['default_category'];
    } else {
        $default_category = '';
    }
    if (isset($midas_Main_Settings['default_type'])) {
        $default_type = $midas_Main_Settings['default_type'];
    } else {
        $default_type = '';
    }
    if (isset($midas_Main_Settings['default_tags'])) {
        $default_tags = $midas_Main_Settings['default_tags'];
    } else {
        $default_tags = '';
    }
    if (isset($midas_Main_Settings['user_name'])) {
        $user_name = $midas_Main_Settings['user_name'];
    } else {
        $user_name = '';
    }
    if (isset($midas_Main_Settings['auto_tags'])) {
        $auto_tags = $midas_Main_Settings['auto_tags'];
    } else {
        $auto_tags = '';
    }
    if (isset($midas_Main_Settings['auto_categories'])) {
        $auto_categories = $midas_Main_Settings['auto_categories'];
    } else {
        $auto_categories = '';
    }
    if (isset($midas_Main_Settings['auto_image'])) {
        $auto_image = $midas_Main_Settings['auto_image'];
    } else {
        $auto_image = '';
    }
    if (isset($midas_Main_Settings['enable_comments'])) {
        $enable_comments = $midas_Main_Settings['enable_comments'];
    } else {
        $enable_comments = '';
    }
    if (isset($midas_Main_Settings['post_user_name'])) {
        $post_user_name = $midas_Main_Settings['post_user_name'];
    } else {
        $post_user_name = '';
    }
    if (isset($midas_Main_Settings['links_add_ref'])) {
        $links_add_ref = $midas_Main_Settings['links_add_ref'];
    } else {
        $links_add_ref = '';
    }
    if (isset($midas_Main_Settings['links_hide'])) {
        $links_hide = $midas_Main_Settings['links_hide'];
    } else {
        $links_hide = '';
    }
    if (isset($midas_Main_Settings['apiKey'])) {
        $apiKey = $midas_Main_Settings['apiKey'];
    } else {
        $apiKey = '';
    }
    if (isset($midas_Main_Settings['post_title'])) {
        $post_title = $midas_Main_Settings['post_title'];
    } else {
        $post_title = '';
    }
    if (isset($midas_Main_Settings['post_content'])) {
        $post_content = $midas_Main_Settings['post_content'];
    } else {
        $post_content = '';
    }
    if (isset($midas_Main_Settings['post_title_user'])) {
        $post_title_user = $midas_Main_Settings['post_title_user'];
    } else {
        $post_title_user = '';
    }
    if (isset($midas_Main_Settings['post_content_user'])) {
        $post_content_user = $midas_Main_Settings['post_content_user'];
    } else {
        $post_content_user = '';
    }
    if (isset($midas_Main_Settings['post_title_popular'])) {
        $post_title_popular = $midas_Main_Settings['post_title_popular'];
    } else {
        $post_title_popular = '';
    }
    if (isset($midas_Main_Settings['post_content_popular'])) {
        $post_content_popular = $midas_Main_Settings['post_content_popular'];
    } else {
        $post_content_popular = '';
    }
    if (isset($midas_Main_Settings['post_title_random'])) {
        $post_title_random = $midas_Main_Settings['post_title_random'];
    } else {
        $post_title_random = '';
    }
    if (isset($midas_Main_Settings['post_content_random'])) {
        $post_content_random = $midas_Main_Settings['post_content_random'];
    } else {
        $post_content_random = '';
    }
    if (isset($midas_Main_Settings['post_title_featured'])) {
        $post_title_featured = $midas_Main_Settings['post_title_featured'];
    } else {
        $post_title_featured = '';
    }
    if (isset($midas_Main_Settings['post_content_featured'])) {
        $post_content_featured = $midas_Main_Settings['post_content_featured'];
    } else {
        $post_content_featured = '';
    }
    if (isset($midas_Main_Settings['post_title_manual'])) {
        $post_title_manual = $midas_Main_Settings['post_title_manual'];
    } else {
        $post_title_manual = '';
    }
    if (isset($midas_Main_Settings['post_content_manual'])) {
        $post_content_manual = $midas_Main_Settings['post_content_manual'];
    } else {
        $post_content_manual = '';
    }
    if (isset($midas_Main_Settings['enable_metabox'])) {
        $enable_metabox = $midas_Main_Settings['enable_metabox'];
    } else {
        $enable_metabox = '';
    }
    if (isset($midas_Main_Settings['submit_status_user'])) {
        $submit_status_user = $midas_Main_Settings['submit_status_user'];
    } else {
        $submit_status_user = '';
    }
    if (isset($midas_Main_Settings['default_category_user'])) {
        $default_category_user = $midas_Main_Settings['default_category_user'];
    } else {
        $default_category_user = '';
    }
    if (isset($midas_Main_Settings['default_type_user'])) {
        $default_type_user = $midas_Main_Settings['default_type_user'];
    } else {
        $default_type_user = '';
    }
    if (isset($midas_Main_Settings['default_tags_user'])) {
        $default_tags_user = $midas_Main_Settings['default_tags_user'];
    } else {
        $default_tags_user = '';
    }
    if (isset($midas_Main_Settings['auto_categories_user'])) {
        $auto_categories_user = $midas_Main_Settings['auto_categories_user'];
    } else {
        $auto_categories_user = '';
    }
    if (isset($midas_Main_Settings['auto_tags_user'])) {
        $auto_tags_user = $midas_Main_Settings['auto_tags_user'];
    } else {
        $auto_tags_user = '';
    }
    if (isset($midas_Main_Settings['auto_image_user'])) {
        $auto_image_user = $midas_Main_Settings['auto_image_user'];
    } else {
        $auto_image_user = '';
    }
    if (isset($midas_Main_Settings['enable_comments_user'])) {
        $enable_comments_user = $midas_Main_Settings['enable_comments_user'];
    } else {
        $enable_comments_user = '';
    }
    if (isset($midas_Main_Settings['post_user_name_user'])) {
        $post_user_name_user = $midas_Main_Settings['post_user_name_user'];
    } else {
        $post_user_name_user = '';
    }
    if (isset($midas_Main_Settings['submit_status_popular'])) {
        $submit_status_popular = $midas_Main_Settings['submit_status_popular'];
    } else {
        $submit_status_popular = '';
    }
    if (isset($midas_Main_Settings['default_category_popular'])) {
        $default_category_popular = $midas_Main_Settings['default_category_popular'];
    } else {
        $default_category_popular = '';
    }
    if (isset($midas_Main_Settings['default_type_popular'])) {
        $default_type_popular = $midas_Main_Settings['default_type_popular'];
    } else {
        $default_type_popular = '';
    }
    if (isset($midas_Main_Settings['default_tags_popular'])) {
        $default_tags_popular = $midas_Main_Settings['default_tags_popular'];
    } else {
        $default_tags_popular = '';
    }
    if (isset($midas_Main_Settings['auto_categories_popular'])) {
        $auto_categories_popular = $midas_Main_Settings['auto_categories_popular'];
    } else {
        $auto_categories_popular = '';
    }
    if (isset($midas_Main_Settings['auto_tags_popular'])) {
        $auto_tags_popular = $midas_Main_Settings['auto_tags_popular'];
    } else {
        $auto_tags_popular = '';
    }
    if (isset($midas_Main_Settings['auto_image_popular'])) {
        $auto_image_popular = $midas_Main_Settings['auto_image_popular'];
    } else {
        $auto_image_popular = '';
    }
    if (isset($midas_Main_Settings['enable_comments_popular'])) {
        $enable_comments_popular = $midas_Main_Settings['enable_comments_popular'];
    } else {
        $enable_comments_popular = '';
    }
    if (isset($midas_Main_Settings['post_user_name_popular'])) {
        $post_user_name_popular = $midas_Main_Settings['post_user_name_popular'];
    } else {
        $post_user_name_popular = '';
    }
    if (isset($midas_Main_Settings['submit_status_random'])) {
        $submit_status_random = $midas_Main_Settings['submit_status_random'];
    } else {
        $submit_status_random = '';
    }
    if (isset($midas_Main_Settings['default_category_random'])) {
        $default_category_random = $midas_Main_Settings['default_category_random'];
    } else {
        $default_category_random = '';
    }
    if (isset($midas_Main_Settings['default_type_random'])) {
        $default_type_random = $midas_Main_Settings['default_type_random'];
    } else {
        $default_type_random = '';
    }
    if (isset($midas_Main_Settings['default_tags_random'])) {
        $default_tags_random = $midas_Main_Settings['default_tags_random'];
    } else {
        $default_tags_random = '';
    }
    if (isset($midas_Main_Settings['auto_categories_random'])) {
        $auto_categories_random = $midas_Main_Settings['auto_categories_random'];
    } else {
        $auto_categories_random = '';
    }
    if (isset($midas_Main_Settings['auto_tags_random'])) {
        $auto_tags_random = $midas_Main_Settings['auto_tags_random'];
    } else {
        $auto_tags_random = '';
    }
    if (isset($midas_Main_Settings['auto_image_random'])) {
        $auto_image_random = $midas_Main_Settings['auto_image_random'];
    } else {
        $auto_image_random = '';
    }
    if (isset($midas_Main_Settings['enable_comments_random'])) {
        $enable_comments_random = $midas_Main_Settings['enable_comments_random'];
    } else {
        $enable_comments_random = '';
    }
    if (isset($midas_Main_Settings['post_user_name_random'])) {
        $post_user_name_random = $midas_Main_Settings['post_user_name_random'];
    } else {
        $post_user_name_random = '';
    }
    if (isset($midas_Main_Settings['submit_status_featured'])) {
        $submit_status_featured = $midas_Main_Settings['submit_status_featured'];
    } else {
        $submit_status_featured = '';
    }
    if (isset($midas_Main_Settings['default_category_featured'])) {
        $default_category_featured = $midas_Main_Settings['default_category_featured'];
    } else {
        $default_category_featured = '';
    }
    if (isset($midas_Main_Settings['default_type_featured'])) {
        $default_type_featured = $midas_Main_Settings['default_type_featured'];
    } else {
        $default_type_featured = '';
    }
    if (isset($midas_Main_Settings['default_tags_featured'])) {
        $default_tags_featured = $midas_Main_Settings['default_tags_featured'];
    } else {
        $default_tags_featured = '';
    }
    if (isset($midas_Main_Settings['auto_categories_featured'])) {
        $auto_categories_featured = $midas_Main_Settings['auto_categories_featured'];
    } else {
        $auto_categories_featured = '';
    }
    if (isset($midas_Main_Settings['auto_tags_featured'])) {
        $auto_tags_featured = $midas_Main_Settings['auto_tags_featured'];
    } else {
        $auto_tags_featured = '';
    }
    if (isset($midas_Main_Settings['auto_image_featured'])) {
        $auto_image_featured = $midas_Main_Settings['auto_image_featured'];
    } else {
        $auto_image_featured = '';
    }
    if (isset($midas_Main_Settings['enable_comments_featured'])) {
        $enable_comments_featured = $midas_Main_Settings['enable_comments_featured'];
    } else {
        $enable_comments_featured = '';
    }
    if (isset($midas_Main_Settings['post_user_name_featured'])) {
        $post_user_name_featured = $midas_Main_Settings['post_user_name_featured'];
    } else {
        $post_user_name_featured = '';
    }
    if (isset($midas_Main_Settings['submit_status_manual'])) {
        $submit_status_manual = $midas_Main_Settings['submit_status_manual'];
    } else {
        $submit_status_manual = '';
    }
    if (isset($midas_Main_Settings['default_category_manual'])) {
        $default_category_manual = $midas_Main_Settings['default_category_manual'];
    } else {
        $default_category_manual = '';
    }
    if (isset($midas_Main_Settings['default_type_manual'])) {
        $default_type_manual = $midas_Main_Settings['default_type_manual'];
    } else {
        $default_type_manual = '';
    }
    if (isset($midas_Main_Settings['default_tags_manual'])) {
        $default_tags_manual = $midas_Main_Settings['default_tags_manual'];
    } else {
        $default_tags_manual = '';
    }
    if (isset($midas_Main_Settings['auto_categories_manual'])) {
        $auto_categories_manual = $midas_Main_Settings['auto_categories_manual'];
    } else {
        $auto_categories_manual = '';
    }
    if (isset($midas_Main_Settings['auto_tags_manual'])) {
        $auto_tags_manual = $midas_Main_Settings['auto_tags_manual'];
    } else {
        $auto_tags_manual = '';
    }
    if (isset($midas_Main_Settings['auto_image_manual'])) {
        $auto_image_manual = $midas_Main_Settings['auto_image_manual'];
    } else {
        $auto_image_manual = '';
    }
    if (isset($midas_Main_Settings['enable_comments_manual'])) {
        $enable_comments_manual = $midas_Main_Settings['enable_comments_manual'];
    } else {
        $enable_comments_manual = '';
    }
    if (isset($midas_Main_Settings['post_user_name_manual'])) {
        $post_user_name_manual = $midas_Main_Settings['post_user_name_manual'];
    } else {
        $post_user_name_manual = '';
    }
    if (isset($midas_Main_Settings['submit_status_grouped'])) {
        $submit_status_grouped = $midas_Main_Settings['submit_status_grouped'];
    } else {
        $submit_status_grouped = '';
    }
    if (isset($midas_Main_Settings['default_category_grouped'])) {
        $default_category_grouped = $midas_Main_Settings['default_category_grouped'];
    } else {
        $default_category_grouped = '';
    }
    if (isset($midas_Main_Settings['default_type_grouped'])) {
        $default_type_grouped = $midas_Main_Settings['default_type_grouped'];
    } else {
        $default_type_grouped = '';
    }
    if (isset($midas_Main_Settings['default_tags_grouped'])) {
        $default_tags_grouped = $midas_Main_Settings['default_tags_grouped'];
    } else {
        $default_tags_grouped = '';
    }
    if (isset($midas_Main_Settings['auto_categories_grouped'])) {
        $auto_categories_grouped = $midas_Main_Settings['auto_categories_grouped'];
    } else {
        $auto_categories_grouped = '';
    }
    if (isset($midas_Main_Settings['auto_tags_grouped'])) {
        $auto_tags_grouped = $midas_Main_Settings['auto_tags_grouped'];
    } else {
        $auto_tags_grouped = '';
    }
    if (isset($midas_Main_Settings['auto_image_grouped'])) {
        $auto_image_grouped = $midas_Main_Settings['auto_image_grouped'];
    } else {
        $auto_image_grouped = '';
    }
    if (isset($midas_Main_Settings['enable_comments_grouped'])) {
        $enable_comments_grouped = $midas_Main_Settings['enable_comments_grouped'];
    } else {
        $enable_comments_grouped = '';
    }
    if (isset($midas_Main_Settings['post_user_name_grouped'])) {
        $post_user_name_grouped = $midas_Main_Settings['post_user_name_grouped'];
    } else {
        $post_user_name_grouped = '';
    }
?>
<script>
                var midas_admin_json = {
                    midas_enabled: '<?php
    echo $midas_enabled;
?>',
                    submit_status: '<?php
    echo $submit_status;
?>',
                    default_category: '<?php
    echo $default_category;
?>',
                    default_type: '<?php
    echo $default_type;
?>',
                    default_tags: '<?php
    echo $default_tags;
?>',
                    user_name: '<?php
    echo $user_name;
?>',
                    auto_tags: '<?php
    echo $auto_tags;
?>',
                    auto_categories: '<?php
    echo $auto_categories;
?>',
                    auto_image: '<?php
    echo $auto_image;
?>',
                    enable_comments: '<?php
    echo $enable_comments;
?>',
                    post_user_name: '<?php
    echo $post_user_name;
?>',
                    links_add_ref: '<?php
    echo $links_add_ref;
?>',
                    links_hide: '<?php
    echo $links_hide;
?>',
                    apiKey: '<?php
    echo $apiKey;
?>',
                    post_title: '<?php
    echo $post_title;
?>',
                    post_content: '<?php
    echo $post_content;
?>',
                    post_title_user: '<?php
    echo $post_title_user;
?>',
                    post_content_user: '<?php
    echo $post_content_user;
?>',
                    post_title_popular: '<?php
    echo $post_title_popular;
?>',
                    post_content_popular: '<?php
    echo $post_content_popular;
?>',
                    post_title_random: '<?php
    echo $post_title_random;
?>',
                    post_content_random: '<?php
    echo $post_content_random;
?>',
                    post_title_featured: '<?php
    echo $post_title_featured;
?>',
                    post_content_featured: '<?php
    echo $post_content_featured;
?>',
                    post_title_manual: '<?php
    echo $post_title_manual;
?>',
                    post_content_manual: '<?php
    echo $post_content_manual;
?>',
                    enable_metabox: '<?php
    echo $enable_metabox;
?>',
                    submit_status_user: '<?php
    echo $submit_status_user;
?>',
                    default_category_user: '<?php
    echo $default_category_user;
?>',
                    default_type_user: '<?php
    echo $default_type_user;
?>',
                    default_tags_user: '<?php
    echo $default_tags_user;
?>',
                    auto_categories_user: '<?php
    echo $auto_categories_user;
?>',
                    auto_tags_user: '<?php
    echo $auto_tags_user;
?>',
                    auto_image_user: '<?php
    echo $auto_image_user;
?>',
                    enable_comments_user: '<?php
    echo $enable_comments_user;
?>',
                    post_user_name_user: '<?php
    echo $post_user_name_user;
?>',
                    submit_status_popular: '<?php
    echo $submit_status_popular;
?>',
                    default_category_popular: '<?php
    echo $default_category_popular;
?>',
                    default_type_popular: '<?php
    echo $default_type_popular;
?>',
                    default_tags_popular: '<?php
    echo $default_tags_popular;
?>',
                    auto_categories_popular: '<?php
    echo $auto_categories_popular;
?>',
                    auto_tags_popular: '<?php
    echo $auto_tags_popular;
?>',
                    auto_image_popular: '<?php
    echo $auto_image_popular;
?>',
                    enable_comments_popular: '<?php
    echo $enable_comments_popular;
?>',
                    post_user_name_popular: '<?php
    echo $post_user_name_popular;
?>',
                    submit_status_random: '<?php
    echo $submit_status_random;
?>',
                    default_category_random: '<?php
    echo $default_category_random;
?>',
                    default_type_random: '<?php
    echo $default_type_random;
?>',
                    default_tags_random: '<?php
    echo $default_tags_random;
?>',
                    auto_categories_random: '<?php
    echo $auto_categories_random;
?>',
                    auto_tags_random: '<?php
    echo $auto_tags_random;
?>',
                    auto_image_random: '<?php
    echo $auto_image_random;
?>',
                    enable_comments_random: '<?php
    echo $enable_comments_random;
?>',
                    post_user_name_random: '<?php
    echo $post_user_name_random;
?>',
                    submit_status_featured: '<?php
    echo $submit_status_featured;
?>',
                    default_category_featured: '<?php
    echo $default_category_featured;
?>',
                    default_type_featured: '<?php
    echo $default_type_featured;
?>',
                    default_tags_featured: '<?php
    echo $default_tags_featured;
?>',
                    auto_categories_featured: '<?php
    echo $auto_categories_featured;
?>',
                    auto_tags_featured: '<?php
    echo $auto_tags_featured;
?>',
                    auto_image_featured: '<?php
    echo $auto_image_featured;
?>',
                    enable_comments_featured: '<?php
    echo $enable_comments_featured;
?>',
                    post_user_name_featured: '<?php
    echo $post_user_name_featured;
?>',
                    submit_status_manual: '<?php
    echo $submit_status_manual;
?>',
                    default_category_manual: '<?php
    echo $default_category_manual;
?>',
                    default_type_manual: '<?php
    echo $default_type_manual;
?>',
                    default_tags_manual: '<?php
    echo $default_tags_manual;
?>',
                    auto_categories_manual: '<?php
    echo $auto_categories_manual;
?>',
                    auto_tags_manual: '<?php
    echo $auto_tags_manual;
?>',
                    auto_image_manual: '<?php
    echo $auto_image_manual;
?>',
                    enable_comments_manual: '<?php
    echo $enable_comments_manual;
?>',
                    post_user_name_manual: '<?php
    echo $post_user_name_manual;
?>',
                    submit_status_grouped: '<?php
    echo $submit_status_grouped;
?>',
                    default_category_grouped: '<?php
    echo $default_category_grouped;
?>',
                    default_type_grouped: '<?php
    echo $default_type_grouped;
?>',
                    default_tags_grouped: '<?php
    echo $default_tags_grouped;
?>',
                    auto_categories_grouped: '<?php
    echo $auto_categories_grouped;
?>',
                    auto_tags_grouped: '<?php
    echo $auto_tags_grouped;
?>',
                    auto_image_grouped: '<?php
    echo $auto_image_grouped;
?>',
                    enable_comments_grouped: '<?php
    echo $enable_comments_grouped;
?>',
                    post_user_name_grouped: '<?php
    echo $post_user_name_grouped;
?>'
}
</script>
<script type="text/javascript">
    function mainChanged()
    {
        if(jQuery('.input-checkbox').is(":checked"))
        {            
            jQuery(".hideMain").show();
        }
        else
        {
            jQuery(".hideMain").hide();
        } 
    }
    window.onload = mainChanged;
</script>
<div ng-app="midsettingsApp" ng-controller="midsettingsController" ng-cloak ng-init="initialized()">
<div class="midas_class">
<table>
    <tr>
    <td>
        <span class="gs-sub-heading"><b>Midas Affiliate Money Generator Plugin Main Switch:</b>&nbsp;</span>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                            <?php
    echo "Enable or disable the Midas Money Generator Envato Affiliate Plugin. This acts like a main switch.";
?>
                        </div>
                    </div>
                    </td>
                    <td>
        <div class="slideThree">	
                            <input class="input-checkbox" type="checkbox" id="midas_enabled" name="midas_Main_Settings[midas_enabled]" onChange="mainChanged()" <?php
    if ($midas_enabled == 'on')
        echo ' checked ';
?>>
                            <label for="midas_enabled"></label>
                    </div>
                    </td>
                    </tr>
                    </table>
                    </div>
                    <div class="hideMain">
                    <hr/>
                    <table><tr><td>
                    <h3>General Plugin Settings:</h3>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the Envato username which will be added to the referral links.";
?>
                        </div>
                    </div>
                    <b>Envato Referral User Name:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[user_name]" ng-model="settings.user_name">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to automatically add referral user name to all envato links in your post contents - this will also replace other referral user names with your own.";
?>
                        </div>
                    </div>
                    <b>Automatically Add Referral to All Links:</b>
                    
                    </td><td>
                    <select id="links_add_ref" name="midas_Main_Settings[links_add_ref]" >
                                  <option value="none"<?php
    if ($links_add_ref == "none") {
        echo " selected";
    }
?>>Disable</option>
                                  <option value="posts"<?php
    if ($links_add_ref == "posts") {
        echo " selected";
    }
?>>Posts</option>
                                  <option value="meta"<?php
    if ($links_add_ref == "meta") {
        echo " selected";
    }
?>>Meta</option>
                                  <option value="all"<?php
    if ($links_add_ref == "all") {
        echo " selected";
    }
?>>All Content</option>
                    </select>    
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to show an extended information metabox under every plugin generated post.";
?>
                        </div>
                    </div>
                    <b>Show Extended Item Information Metabox in Post:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_metabox" name="midas_Main_Settings[enable_metabox]"<?php
    if ($enable_metabox == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Choose if you want to cloak URLs with goo.gl link shortener.";
?>
                        </div>
                    </div>
                    <b>Hide Referral URLs using goo.gl:</b>
                    
                    </td><td>
                    <input type="checkbox" id="links_hide" name="midas_Main_Settings[links_hide]"<?php
    if ($links_hide == 'on')
        echo ' checked ';
?>>
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Insert your goo.gl api key.";
?>
                        </div>
                    </div>
                    <b>Goo.gl API key:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[apiKey]" ng-model="settings.apiKey">
        </div>
        </td></tr><tr><td>
                        <h3><a name="newest" href="admin.php?page=midas_newest_post_rules">Newest Market Item Post Rules Settings:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name" name="midas_Main_Settings[post_user_name]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status" name="midas_Main_Settings[submit_status]" >
                                  <option value="pending"<?php
    if ($submit_status == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category" name="midas_Main_Settings[default_category]" ng-model="settings.default_category">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories" name="midas_Main_Settings[auto_categories]"<?php
    if ($auto_categories == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags" name="midas_Main_Settings[auto_tags]"<?php
    if ($auto_tags == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags]" ng-model="settings.default_tags">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type" name="midas_Main_Settings[default_type]" ng-model="settings.default_type">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image" name="midas_Main_Settings[auto_image]"<?php
    if ($auto_image == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments" name="midas_Main_Settings[enable_comments]"<?php
    if ($enable_comments == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for newest market items. You can use the following shortcodes: %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title]" ng-model="settings.post_title">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for newest market items. You can use the following shortcodes: %%see_more_button%%, %%buy_now_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_media%%, %%item_img%%, %%item_video%%, %%item_thumb%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content]" ng-model="settings.post_content"></textarea>
                        
        </div>
        </td></tr><tr><td>
        <h3><a name="user" href="admin.php?page=midas_newest_user">User Rules:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_user" name="midas_Main_Settings[post_user_name_user]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_user == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_user" name="midas_Main_Settings[submit_status_user]" >
                                  <option value="pending"<?php
    if ($submit_status_user == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_user == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_user == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_user == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_user == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_user" name="midas_Main_Settings[default_category_user]" ng-model="settings.default_category_user">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_user" name="midas_Main_Settings[auto_categories_user]"<?php
    if ($auto_categories_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_user" name="midas_Main_Settings[auto_tags_user]"<?php
    if ($auto_tags_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_user]" ng-model="settings.default_tags_user">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_user" name="midas_Main_Settings[default_type_user]" ng-model="settings.default_type_user">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_user" name="midas_Main_Settings[auto_image_user]"<?php
    if ($auto_image_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_user" name="midas_Main_Settings[enable_comments_user]"<?php
    if ($enable_comments_user == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for user rules. You can use the following shortcodes:  %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_user]" ng-model="settings.post_title_user">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for user rules. You can use the following shortcodes: %%see_more_button%%, %%buy_now_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_media%%, %%item_img%%, %%item_video%%, %%item_thumb%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_user]" ng-model="settings.post_content_user"></textarea>
                        
        </div>
        </td></tr><tr><td>
        <h3><a name="popular" href="admin.php?page=midas_popular_items">Popular Rules:</a></h3>
                </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_popular" name="midas_Main_Settings[post_user_name_popular]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_popular == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_popular" name="midas_Main_Settings[submit_status_popular]" >
                                  <option value="pending"<?php
    if ($submit_status_popular == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_popular == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_popular == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_popular == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_popular == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_popular" name="midas_Main_Settings[default_category_popular]" ng-model="settings.default_category_popular">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_popular" name="midas_Main_Settings[auto_categories_popular]"<?php
    if ($auto_categories_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_popular" name="midas_Main_Settings[auto_tags_popular]"<?php
    if ($auto_tags_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_popular]" ng-model="settings.default_tags_popular">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_popular" name="midas_Main_Settings[default_type_popular]" ng-model="settings.default_type_popular">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_popular" name="midas_Main_Settings[auto_image_popular]"<?php
    if ($auto_image_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_popular" name="midas_Main_Settings[enable_comments_popular]"<?php
    if ($enable_comments_popular == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for popular item rules. You can use the following shortcodes:  %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_popular]" ng-model="settings.post_title_popular">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for popular item rules. You can use the following shortcodes: %%see_more_button%%, %%buy_now_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_media%%, %%item_img%%, %%item_video%%, %%item_thumb%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_popular]" ng-model="settings.post_content_popular"></textarea>
                        
        </div>
        </td></tr><tr><td>
        <h3><a name="random" href="admin.php?page=midas_random_items">Random Rules:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_random" name="midas_Main_Settings[post_user_name_random]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_random == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_random" name="midas_Main_Settings[submit_status_random]" >
                                  <option value="pending"<?php
    if ($submit_status_random == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_random == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_random == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_random == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_random == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_random" name="midas_Main_Settings[default_category_random]" ng-model="settings.default_category_random">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_random" name="midas_Main_Settings[auto_categories_random]"<?php
    if ($auto_categories_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_random" name="midas_Main_Settings[auto_tags_random]"<?php
    if ($auto_tags_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_random]" ng-model="settings.default_tags_random">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_random" name="midas_Main_Settings[default_type_random]" ng-model="settings.default_type_random">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_random" name="midas_Main_Settings[auto_image_random]"<?php
    if ($auto_image_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_random" name="midas_Main_Settings[enable_comments_random]"<?php
    if ($enable_comments_random == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for random item rules. You can use the following shortcodes:  %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_random]" ng-model="settings.post_title_random">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for random item rules. You can use the following shortcodes: %%see_more_button%%, %%buy_now_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_media%%, %%item_img%%, %%item_video%%, %%item_thumb%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_random]" ng-model="settings.post_content_random"></textarea>
                        
        </div>
        </td></tr><tr><td>
        <h3><a name="featured" href="admin.php?page=midas_featured_items">Featured Rules:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_featured" name="midas_Main_Settings[post_user_name_featured]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_featured == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_featured" name="midas_Main_Settings[submit_status_featured]" >
                                  <option value="pending"<?php
    if ($submit_status_featured == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_featured == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_featured == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_featured == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_featured == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_featured" name="midas_Main_Settings[default_category_featured]" ng-model="settings.default_category_featured">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_featured" name="midas_Main_Settings[auto_categories_featured]"<?php
    if ($auto_categories_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_featured" name="midas_Main_Settings[auto_tags_featured]"<?php
    if ($auto_tags_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_featured]" ng-model="settings.default_tags_featured">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_featured" name="midas_Main_Settings[default_type_featured]" ng-model="settings.default_type_featured">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_featured" name="midas_Main_Settings[auto_image_featured]"<?php
    if ($auto_image_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_featured" name="midas_Main_Settings[enable_comments_featured]"<?php
    if ($enable_comments_featured == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for featured item rules. You can use the following shortcodes:  %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_featured]" ng-model="settings.post_title_featured">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for featured item rules. You can use the following shortcodes: %%see_more_button%%, %%buy_now_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_media%%, %%item_img%%, %%item_video%%, %%item_thumb%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_featured]" ng-model="settings.post_content_featured"></textarea>
                        
        </div>
        </td></tr><tr><td>
        <h3><a name="manual" href="admin.php?page=midas_manual_items">Manual Rules:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_manual" name="midas_Main_Settings[post_user_name_manual]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_manual == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_manual" name="midas_Main_Settings[submit_status_manual]" >
                                  <option value="pending"<?php
    if ($submit_status_manual == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_manual == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_manual == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_manual == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_manual == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_manual" name="midas_Main_Settings[default_category_manual]" ng-model="settings.default_category_manual">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_manual" name="midas_Main_Settings[auto_categories_manual]"<?php
    if ($auto_categories_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_manual" name="midas_Main_Settings[auto_tags_manual]"<?php
    if ($auto_tags_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_manual]" ng-model="settings.default_tags_manual">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_manual" name="midas_Main_Settings[default_type_manual]" ng-model="settings.default_type_manual">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_manual" name="midas_Main_Settings[auto_image_manual]"<?php
    if ($auto_image_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_manual" name="midas_Main_Settings[enable_comments_manual]"<?php
    if ($enable_comments_manual == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the title of the generated posts for manual item rules. You can use the following shortcodes:  %%item_title%%, %%item_description%%, %%item_id%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Title:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[post_title_manual]" ng-model="settings.post_title_manual">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Set the content of the generated posts for manual item rules. You can use the following shortcodes: %%see_more_button%%, %%buy_now_button%%, %%live_preview_button%%, %%generate_item_intro%%, %%item_preview%%, %%item_title%%, %%item_description%%, %%item_id%%, %%item_media%%, %%item_img%%, %%item_video%%, %%item_thumb%%, %%item_url%%, %%item_user%%, %%item_cost%%, %%item_cat%%, %%item_tags%%, %%item_uploaded%%, %%item_last_update%%, %%item_sales%%, %%item_rating%%";
?>
                        </div>
                    </div>
                    <b>Generated Post Content:</b>
                    
                    </td><td>
                    <textarea rows="3" cols="70" name="midas_Main_Settings[post_content_manual]" ng-model="settings.post_content_manual"></textarea>
                        
        </div>
                    </td></tr><tr><td>
        <h3><a name="grouped" href="admin.php?page=midas_group_items">Grouped Rules:</a></h3>
        </td></tr><tr><td>
        <div >
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Username of the publisher of the published posts for anonymous user submissions.";
?>
                        </div>
                    </div>
                    <b>Generated Posts Author User Name:</b>
                    </div>
                    </td><td>
                    <div>
                    <select id="post_user_name_grouped" name="midas_Main_Settings[post_user_name_grouped]" >
<?php
    $blogusers = get_users();
    foreach ($blogusers as $user) {
        echo '<option value="' . esc_html($user->ID) . '"';
        if ($post_user_name_grouped == $user->ID) {
            echo " selected";
        }
        echo '>' . $user->display_name . '</option>';
    }
?>                           
                    </select>      
                    </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the status that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Status:</b>                  
                    </td><td>
                    <select id="submit_status_grouped" name="midas_Main_Settings[submit_status_grouped]" >
                                  <option value="pending"<?php
    if ($submit_status_grouped == "pending") {
        echo " selected";
    }
?>>Moderate -> Pending</option>
                                  <option value="draft"<?php
    if ($submit_status_grouped == "draft") {
        echo " selected";
    }
?>>Moderate -> Draft</option>
                                  <option value="publish"<?php
    if ($submit_status_grouped == "publish") {
        echo " selected";
    }
?>>Published</option>
                                  <option value="private"<?php
    if ($submit_status_grouped == "private") {
        echo " selected";
    }
?>>Private</option>
                                  <option value="trash"<?php
    if ($submit_status_grouped == "trash") {
        echo " selected";
    }
?>>Trash</option>
                    </select>                       
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post category that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Category:</b>
                    
                    </td><td>
                    <select id="default_category_grouped" name="midas_Main_Settings[default_category_grouped]" ng-model="settings.default_category_grouped">
                    <option value="midas_no_category_12345678">Do Not Add a Category</option>
<?php
    $cat_args   = array(
        'orderby' => 'name',
        'hide_empty' => 0,
        'order' => 'ASC'
    );
    $categories = get_categories($cat_args);
    foreach ($categories as $category) {
?>
<option value="<?php
        echo $category->term_id;
?>"><?php
        echo sanitize_text_field($category->name);
?></option>
<?php
    }
?>
                </select>     
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post categories from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Categories From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_categories_grouped" name="midas_Main_Settings[auto_categories_grouped]"<?php
    if ($auto_categories_grouped == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post tags from the Envato items?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Tags From Items:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_tags_grouped" name="midas_Main_Settings[auto_tags_grouped]"<?php
    if ($auto_tags_grouped == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post tags that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Additional Post Tags:</b>
                    
                    </td><td>
                    <input type="text" name="midas_Main_Settings[default_tags_grouped]" ng-model="settings.default_tags_grouped">
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Select the post type that you want for the automatically generated posts to have.";
?>
                        </div>
                    </div>
                    <b>Post Type:</b>
                    
                    </td><td>
                    <select id="default_type_grouped" name="midas_Main_Settings[default_type_grouped]" ng-model="settings.default_type_grouped">
                        <option value="post">Post</option>
                        <option value="page">Page</option>
                    </select>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to automatically add post featured image from the Envato item?";
?>
                        </div>
                    </div>
                    <b>Automatically Add Post Featured Image:</b>
                    
                    </td><td>
                    <input type="checkbox" id="auto_image_grouped" name="midas_Main_Settings[auto_image_grouped]"<?php
    if ($auto_image_grouped == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr><tr><td>
        <div>
        <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Do you want to enable comments for the generated posts?";
?>
                        </div>
                    </div>
                    <b>Enable Comments For Generated Posts:</b>
                    
                    </td><td>
                    <input type="checkbox" id="enable_comments_grouped" name="midas_Main_Settings[enable_comments_grouped]"<?php
    if ($enable_comments_grouped == 'on')
        echo ' checked ';
?>>
                        
        </div>
        </td></tr>
        </table>         
        <hr/>
        <h3>Affiliate Keyword Replacer Settings:</h3>
        <div class="table-responsive">
                    <table class="responsive table" style="overflow-x:auto;">
				<thead>
					<tr>
                    <th>ID<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This is the ID of the rule.";
?>
                        </div>
                    </div></th>
                    <th>Keyword<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This keyword will be replaced with a link you define.";
?>
                        </div>
                    </div></th>
                    <th>Affiliate Link<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Define the link you want to appear the defined keyword.";
?>
                        </div>
                    </div></th>
					</tr>
                    <tr><td><hr/></td><td><hr/></td><td><hr/></td></tr>
				</thead>
				<tbody>
					<?php echo midas_expand_keyword_rules(); ?>
                    <tr><td><hr/></td><td><hr/></td><td><hr/></td></tr>
					<tr>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;">-</td>
                        <td style="text-align:center;vertical-align: middle;"><input type="text" name="midas_keyword_list[keyword][]" value="" /></td>
						<td style="text-align:center;vertical-align: middle;"><input type="url" validator="url" name="midas_keyword_list[link][]" value="" />
					</tr>
				</tbody>
			</table>
            </div>
        </div>
        </div>
         <hr/>
<div><p class="submit"><input type="submit" name="btnSubmit" id="btnSubmit" class="button button-primary" value="Save Settings"/></p></div>
    </form>
</div>
</div>
<?php
}
if (isset($_POST['midas_keyword_list'])) {
	add_action('admin_init', 'midas_save_keyword_rules');
}
function midas_save_keyword_rules($data2) {
            $data2 = $_POST['midas_keyword_list'];
			$rules = array();
            if(isset($data2['keyword'][0]))
            {
                for($i = 0; $i < sizeof($data2['keyword']); ++$i) {
                    if(isset($data2['keyword'][$i]) && $data2['keyword'][$i] != '')
                    {
                        $index = trim( sanitize_text_field($data2['keyword'][$i]));
                        $rules[$index] = trim( sanitize_text_field( $data2['link'][$i] ) );
                    }
                }
            }
            update_option('midas_keyword_list', $rules);
		}
function midas_expand_keyword_rules() {
			$rules = get_option('midas_keyword_list');
			$output = '';
            $cont = 0;
			if (!empty($rules)) {
				foreach ($rules as $request => $value) {  
					$output .= '<tr>
                        <td style="max-width:32px;text-align:center;vertical-align: middle;">' . $cont . '</td>
                        <td><input type="text" name="midas_keyword_list[keyword][]" value="'.$request.'" required></td>
                        <td><input type="url" validator="url" name="midas_keyword_list[link][]" value="'.$value.'" required></td>
					</tr>';
                    $cont++;
				}
			}
			return $output;
		}
?>