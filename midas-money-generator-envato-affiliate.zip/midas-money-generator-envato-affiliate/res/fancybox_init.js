jQuery(document).ready(function() {
		jQuery(".fancybox").fancybox();
});