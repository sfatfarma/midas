<?php
function midas_logs()
{
    if(isset($_POST['midas_delete']))
    {
        if(file_exists(WP_CONTENT_DIR . '/midas_info.log'))
        {
            unlink(WP_CONTENT_DIR . '/midas_info.log');
        }
    }
    if(isset($_POST['midas_delete_rules']))
    {
        $running = array();
        update_option('midas_running_list', $running);
    }
    if(isset($_POST['midas_restore_defaults']))
    {
        midas_activation_callback(true);
    }
    if(isset($_POST['midas_delete_all']))
    {
        midas_delete_all_posts();
    }
?>
<div class="wrap gs_popuptype_holder seo_pops">
    <div>
<script>
                var midas_admin_json = {
}
function toggle(target){
        if(jQuery("#"+target).is(":visible"))
        {            
            jQuery("#"+target).hide();
        }
        else
        {
            jQuery("#"+target).show();
        }
    }
</script>
<div>
<h3>Rules Currently Running:<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "These rules are currently running on your server.";
?>
                        </div>
                    </div></h3>
                    <div>
<?php
    if (!get_option('midas_running_list')) {
        $running = array();
    } else {
        $running = get_option('midas_running_list');
    }
    if (!empty($running)) {
        echo '<ul>';
        foreach($running as $key => $thread)
        {
            foreach($thread as $param => $type)
            {
                $ech = '';
                if ($type == '0') {
                    $ech .= 'Newest Market Items Rules';
                } elseif ($type == '1') {
                    $ech .= 'Newest User Items Rules';
                } elseif ($type == '2') {
                    $ech .= 'Popular Market Items Rules';
                } elseif ($type == '3') {
                    $ech .= 'Random Market Items Rules';
                } elseif ($type == '4') {
                    $ech .= 'Featured Market Items Rules';
                } elseif ($type == '5') {
                    $ech .= 'Manual Items by ID Rules';
                } elseif ($type == '6') {
                    $ech .= 'Grouped Items Posts Rules';
                } elseif ($type == 'auto_update') {
                    $ech .= 'Item Auto Updating Process';
                }
                else{
                    $ech .= 'Unknown rule type: ' . $type;
                }
                echo '<li><b>' . $ech . '</b> - ID' . $param . '</li>';
            }
        }
        echo '</ul>';        
    }
    else
    {
        echo 'No rules are running right now<br/>';
    }
    if (!get_option('midas_auto_running_list')) {
        $running = array();
    } else {
        $running = get_option('midas_auto_running_list');
    }
    if (!empty($running)) {
        echo '<ul>';
        foreach($running as $key => $thread)
        {
            foreach($thread as $param => $type)
            {
                $ech = '';
                if ($type == 'auto_update') {
                    $ech .= 'Items auto updating process running';
                }
                else{
                    $ech .= 'Unknown rule type: ' . $type;
                }
                echo '<li><b>' . $ech . '</b></li>';
            }
        }
        echo '</ul>';        
    }
    else
    {
        echo 'Auto update process not running<br/>';
    }
?>
                    </div>
                    <hr/>
    <form method="post" onsubmit="return confirm('Are you sure you want to clear the running list?');">
<input name="midas_delete_rules" type="submit" title="Caution! This is for debugging purpose only!" value="Clear Running Rules List">
    </form>
    </div>
    <div class="hideMain">
    <br/><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>    
        <div><h3>Restore Plugin Default Settings: <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Hit this button and the plugin settings will be restored to their default values. Warning! All settings will be lost!";
?>
                        </div>
                    </div></h3><hr/><form method="post" onsubmit="return confirm('Are you sure you want to restore the default plugin settings?');"><input name="midas_restore_defaults" type="submit" value="Restore Plugin Default Settings"></form></div>
                    <br/><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>    
        <div><h3>Delete All Posts Generated by this Plugin: <div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "Hit this button and all posts generated by this plugin will be deleted!";
?>
                        </div>
                    </div></h3><hr/><form method="post" onsubmit="return confirm('Are you sure you want to delete all generated posts? This ca take a while, please be patient.');"><input name="midas_delete_all" type="submit" value="Delete All Generated Posts"></form></div>
                    <br/><hr style=" height: 12px;border: 0;box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);"/>    
                    <h3>Activity Log:<div class="bws_help_box bws_help_box_right dashicons dashicons-editor-help" style="vertical-align: middle;">
                                        <div class="bws_hidden_help_text" style="min-width: 260px;">
                                            <?php
    echo "This is the main log of your plugin. Here will be listed every single instance of the rules you run or are automatically run by schedule jobs (if you enable logging, in the plugin configuration).";
?>
                        </div>
                    </div></h3>
<div>
<?php
if(file_exists(WP_CONTENT_DIR . '/midas_info.log'))
{
    $log = file_get_contents(WP_CONTENT_DIR . '/midas_info.log');
    echo $log;
}
else
{
    echo "Log empty";
}
?>
</div>
        </div>
        <hr/> 
        <form method="post" onsubmit="return confirm('Are you sure you want to delete all logs?');">
   <input name="midas_delete" type="submit" value="Delete Logs">
        </form>
        <br/><hr/><br/>
<div>
Confused about rule icons? <a style="cursor:pointer" onclick="unsaved = false;toggle('midas_icons');">Show Rule Visual Status Indicators:</a><br/>
<div style="display:none" id="midas_icons">
<table><tr><td><img id="run_img" src="<?php echo plugin_dir_url(dirname(__FILE__));?>images/running.gif" alt="Running" title="status"></td><td>Running</td></tr>
<tr><td><img id="ok_img" src="<?php echo plugin_dir_url(dirname(__FILE__));?>images/ok.gif" alt="OK"  title="status"></td><td>Success</td></tr>
<tr><td><img id="fail_img" src="<?php echo plugin_dir_url(dirname(__FILE__));?>images/failed.gif" alt="Faield" title="status"></td><td>Failed</td></tr>
<tr><td><img id="nochange_img" src="<?php echo plugin_dir_url(dirname(__FILE__));?>images/nochange.gif" alt="NoChange"title="status"></td><td>No Change</td></tr>
</table>
</div>
</div>
</div>
</div>
<?php
}
?>