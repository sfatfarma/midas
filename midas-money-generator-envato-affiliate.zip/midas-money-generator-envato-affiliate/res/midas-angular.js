angular.module('midsettingsApp', ['ngSanitize'])
.controller('midsettingsController', function($scope) {
    $scope.settings = midas_admin_json;
});