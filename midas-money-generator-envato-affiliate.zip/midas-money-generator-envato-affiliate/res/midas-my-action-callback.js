jQuery(document).ready(function($) {
    jQuery('body').on('click', '#submit-my-form', function(e) {
        e.preventDefault();
        var $me = jQuery(this),
            action = 'midas_my_ajax_action';
        var data = jQuery.extend(true, $me.data(), {
            action: action,
            max_comments: jQuery('#max_comments').val(),
            item_id: jQuery('#item_id').val(),
            post_id: jQuery('#post_id').val()
        });
        jQuery.post(ajaxurl, data, function(response) {
            if(response == '-1'){
                alert('Failed to import comments!');
            } else {
                alert('Success! ' + response + ' comments imported!');
            }
        });
    });
});