<?php 

class C5_Market_Affiliate_Admin_Page {
	
	public $page_url = '';
	public $slug = '';
	public $envato = '';
	
	function __construct() {
		$this->constants();
		
		$this->envato = new C5_Envato_API($this->get_saved_options());	
		
		
	}
	
	function hook() {
		
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action('admin_init', array($this, 'save_data'));
	}
	
	
	function constants() {
		$this->slug = 'c5-market-affiliate';
		$this->page_url = admin_url('options-general.php?page='.$this->slug );
		
	}
	
	function admin_menu () {
		add_options_page( 'Market Affiliate','Market Affiliate','manage_options',$this->slug , array( $this, 'settings_page' ) );
	}
	function save_data() {
		
		if (!isset( $_GET['page'] )) {
			return;
		}
		if ($_GET['page'] != $this->slug) {
			return;
		}
		if (isset($_GET['code'])) {
			$data = get_option($this->slug);
			$data['envato_app_code'] = $_GET['code'];
			
			update_option($this->slug, $data);
			
			
			$this->envato->update_args($data);
			$this->envato->get_token_link();
			
			
			return;
		}
		if (!isset($_POST['envato_app_name']) && !isset($_POST['envato_referal_username']) ) {
			return;
		}
		
		$data = get_option($this->slug);
		
		if (isset($_POST['envato_form'])) {
			
			foreach ($this->envato_app_options() as $option) {
				if (isset( $_POST[$option['id']] ) && !$option['strict'] ) {
					$data[$option['id']] = $_POST[$option['id']];
				}else {
					$data[$option['id']] = $option['std'];
				}
			}
		}else {
			
			foreach ($this->plugin_options() as $option) {
				if (isset( $_POST[$option['id']] ) && !$option['strict'] ) {
					$data[$option['id']] = $_POST[$option['id']];
				}else {
					$data[$option['id']] = $option['std'];
				}
			}
		}
		
		
		update_option($this->slug, $data);
		
		if ($data['envato_app_code'] == '') {
			$this->envato->update_args($data);
			$url = $this->envato->get_authorization_link();
			wp_redirect($url);
		}
		
	}
	
	function plugin_options() {
		$options = array(
			array(
				'id'=>'envato_referal_username',
				'type'=>'text',
				'desc' => __('This username will be used for referals across the website.','c5-market-affiliate'),
				'label' => __('Envato Referal Username','c5-market-affiliate'),
				
			),
			array(
				'id'=>'envato_sales_cache',
				'type'=>'text',
				'std' => '3600',
				'desc' => __('This is the cache time in seconds for refreshing the item sales, "Min 60 seconds and Max 604800 seconds".','c5-market-affiliate'),
				'label' => __('Refresh Cache time for sales','c5-market-affiliate'),
			),
			array(
				'id'=>'envato_cache',
				'type'=>'text',
				'std' => '86400',
				'desc' => __('This is the cache time in seconds for refreshing all item info including images, title, price, sales, rating and update date. "Min 3600 seconds and Max 604800 seconds".','c5-market-affiliate'),
				'label' => __('Refresh Cache time for item','c5-market-affiliate'),
			),
			
		
		);
		
		$defaults = array(
			'id'=>'',
			'type'=>'',
			'desc'=>'',
			'label'=>'',
			'disabled'=>false,
			'std'=>'',
			'strict'=>false
		);
		$final_options = array();
		foreach ($options as $option) {
			$final_options[] = shortcode_atts(
					$defaults, $option );
		}
		return $final_options;
	}
	
	function envato_app_options() {
		$options = array(
			array(
				'id'=>'envato_app_name',
				'type'=>'text',
				'label' => __('Envato APP Name ','c5-market-affiliate')
			),
			array(
				'id'=>'envato_app_secret_key',
				'type'=>'text',
				'label' => __('Envato APP Secret Key ','c5-market-affiliate')
			),
			array(
				'id'=>'envato_app_client_id',
				'type'=>'text',
				'label' => __('Envato APP oAuth Client ID ','c5-market-affiliate')
			),
			array(
				'id'=>'envato_app_code',
				'type'=>'hidden',
				'label' => __('Envato APP code ','c5-market-affiliate'),
				'strict'=> true,
			),
			array(
				'id'=>'envato_form',
				'type'=>'hidden',
				'label' => '',
				'strict'=> true,
			),
			array(
				'id'=>'envato_app_redirect_url',
				'type'=>'text',
				'disabled'=> true,
				'desc' => __('Make Sure that your App has this url as a redirect url','c5-market-affiliate'),
				'std'=> $this->page_url,
				'label' => __('Envato APP Redirect URL ','c5-market-affiliate'),
				'strict'=> true,
			),
		
		);
		
		$defaults = array(
			'id'=>'',
			'type'=>'',
			'desc'=>'',
			'label'=>'',
			'disabled'=>false,
			'std'=>'',
			'strict'=>false
		);
		$final_options = array();
		foreach ($options as $option) {
			$final_options[] = shortcode_atts(
					$defaults, $option );
		}
		return $final_options;
	}
	function get_saved_options() {
		$saved_options = get_option($this->slug);
		if (empty($saved_options)) {
			$saved_options = array();
		}
		
		foreach ($this->envato_app_options() as $option) {
			if (!isset($saved_options[ $option['id'] ])) {
				$saved_options[ $option['id'] ] = $option['std'];
			}
		}
		foreach ($this->plugin_options() as $option) {
			if (!isset($saved_options[ $option['id'] ])) {
				$saved_options[ $option['id'] ] = $option['std'];
			}
		}
		
		
		$args = array('envato_refresh_token' , 'envato_token_type' ,'envato_access_token', 'envato_expires_in', 'envato_last_update');
		foreach ($args as $key) {
			if ( !isset($saved_options[$key])) {
				$saved_options[$key] = '';
			}
		}
		
		return $saved_options;
	}
	
	function show_options($options) {
		$saved_options = $this->get_saved_options();
		foreach ( $options as $option) {
			switch ($option['type']) {
				case 'text':
					?>
					<tr>
					<th scope="row"><label for="<?php echo $option['id'] ?>"><?php echo $option['label'] ?></label></th>
					<td>
					<?php 
					$disabled = '';
					if ($option['disabled']) {
						$disabled = ' disabled ';
					}
					
					 ?>
					<input name="<?php echo $option['id'] ?>" type="text" id="<?php echo $option['id'] ?>" value="<?php echo $saved_options[$option['id'] ] ?>" class="regular-text" <?php echo $disabled ?>>
					<?php if ($option['desc']!='') { ?>
						<p class="description" id="<?php echo $option['id'] ?>-description"><?php echo $option['desc']; ?></p>
					<?php }	 ?>
					
					
					</td>
					</tr>
					<?php
					break;
				case 'heading-3':
					?>
					<tr>
					<th scope="row"><h3><?php echo $option['label'] ?></h3></th>
					<td></td>
					</tr>
					<?php
					break;
				case 'hidden':
					?>
					<input name="<?php echo $option['id'] ?>" type="hidden" id="<?php echo $option['id'] ?>" value="<?php echo $saved_options[$option['id'] ] ?>">
					<?php
					break;
			}
		}
	}
	
	function  settings_page () {
		$saved_options = $this->get_saved_options();
		?>
		<div class="wrap">
		<h2><?php _e('Market Affiliate Plugin Settings - [W][P][L][O][C][K][E][R][.][C][O][M]','c5-market-affiliate') ?></h2>
		<?php 
		if ( $saved_options['envato_access_token'] != '') { ?>
			<div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible"> 
			<p><strong><?php _e('App is ready, You can start using the plugin','c5-market-affiliate') ?></strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
		<?php } ?>
		<h3 class="title">Envato App Settings</h3>
		<form method="post" action="<?php echo $this->page_url; ?>" novalidate="novalidate">
		<table class="form-table">
		<tbody>
		<?php
			$this->show_options( $this->envato_app_options() );
		?>
		</tbody></table>
		
		<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e('Authorize','c5-market-affiliate'); ?>"></p></form>
		
		<h3 class="title">Market Affiliate Settings - w:p:l:o:c:k:e:r:.:c:o:m</h3>
		<form method="post" action="<?php echo $this->page_url; ?>" novalidate="novalidate">
		<table class="form-table">
		<tbody>
		<?php
			$this->show_options( $this->plugin_options() );
		?>
		</tbody></table>
		
		<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="<?php _e('Save Changes','c5-market-affiliate'); ?>"></p></form>
		
		</div>
		<?php
	}
	
}
$admin_page =  new C5_Market_Affiliate_Admin_Page();
$admin_page->hook();

?>