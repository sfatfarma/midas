<?php 

class C5_Envato_Shortcode {
	
	public $envato = '';
	
	function __construct() {
		
	}
	function hook() {
		add_shortcode( 'c5ma_envato_item', array($this, 'c5ma_envato_item') );
		add_shortcode( 'c5ma_envato_user', array($this, 'c5ma_envato_user') );
		add_shortcode( 'c5ma_envato_feed', array($this, 'c5ma_envato_feed') );
		
	}
	
	function prepare_object() {
		$args = get_option('c5-market-affiliate');
		$this->envato = new C5_Envato_API($args);
		
		
	}
	
	function get_shape($option) {
		$option = 'tall';
		switch ($option) {
			case 'big':
			
		}
	}
	
	
	function c5ma_envato_feed($atts, $content) {
		$atts = shortcode_atts( array(
		    'shape' => 'big',
		    'method' => 'new',
		    'marketplace' => 'themeforest',
		    'category' => 'wordpress',
		    'count' => '5',
		), $atts );
		
		$atts['count'] = intval($atts['count']);
		if ($atts['count'] <= 0) {
			$atts['count'] = 1;
		}
		if ($atts['count'] > 20) {
			$atts['count'] = 20;
		}
		
		$post_id = '';
		$return = '';
		$obj = new C5_Envato_Affiliate_CPT();
		$items = $obj->get_feed_items($atts['method'],$atts['marketplace'],$atts['category']);
		if (!empty($items)) {
			$item = new C5_Envato_Item();
			$return .= '<div class="c5ma-items-wrap c5ma-items-wrap-'.$atts['shape'].' clearfix">';
			$counter = 1;
			foreach ($items as $post_id) {
				switch ($atts['shape']) {
					case 'big':
						$return .= $item->get_large_post($post_id);
						break;
					case 'banner':
						$return .= $item->get_banner_post($post_id, $content);
						break;
					case 'wide':
						$return .= $item->get_wide_post($post_id);
						break;
					case 'tall':
						$return .= $item->get_tall_post($post_id);
						break;
					case 'thumbnail':
						$return .= $item->get_thumb_post($post_id);
						break;
					case 'sidebar':
						$return .= $item->get_sidebar_post($post_id);
						break;
					default:
						$return .= $item->get_large_post($post_id);
						break;
				}
				if ($counter == $atts['count']) {
					break;
				}
				$counter++;
			}
			$return .= '</div>';
		}
		return $return;
		
	}
	
	function c5ma_envato_user($atts) {
		$atts = shortcode_atts( array(
		    'shape' => 'big',
		    'username' => 'code125',
		    'marketplace' => 'themeforest',
		), $atts );
		
		$post_id = '';
		$return = '';
		$obj = new C5_Envato_Affiliate_CPT();
		$items = $obj->get_user_items($atts['username'],$atts['marketplace']);
		if (!empty($items)) {
			$item = new C5_Envato_Item();
			$return .= '<div class="c5ma-items-wrap c5ma-items-wrap-'.$atts['shape'].' clearfix">';
			foreach ($items as $post_id) {
				switch ($atts['shape']) {
					case 'big':
						$return .= $item->get_large_post($post_id);
						break;
					case 'wide':
						$return .= $item->get_wide_post($post_id);
						break;
					case 'tall':
						$return .= $item->get_tall_post($post_id);
						break;
					case 'thumbnail':
						$return .= $item->get_thumb_post($post_id);
						break;
					case 'sidebar':
						$return .= $item->get_sidebar_post($post_id);
						break;
					default:
						$return .= $item->get_large_post($post_id);
						break;
				}
			}
			$return .= '</div>';
		}
		return $return;
		
	}
	function c5ma_envato_item( $atts , $content) {
	    $atts = shortcode_atts( array(
	        'shape' => 'big',
	        'url' => '',
	    ), $atts );
		$obj = new C5_Envato_Affiliate_CPT();
		
		$post_id = '';
		
		if ($atts['url'] != '') {
			$post_id= $obj->get_item_by_url( $atts['url'] );
			if ($post_id != '') {
				$item = new C5_Envato_Item();
				
				switch ($atts['shape']) {
					case 'big':
						$return = $item->get_large_post($post_id, $content) ;
						break;
					case 'banner':
						$return = $item->get_banner_post($post_id, $content);
						break;
					case 'buttons':
						$return = $item->get_item_buttons($post_id);
						break;
					case 'wide':
						$return = $item->get_wide_post($post_id);
						break;
					case 'tall':
						$return = $item->get_tall_post($post_id);
						break;
					case 'thumbnail':
						$return = $item->get_thumb_post($post_id);
						break;
					case 'sidebar':
						$return = $item->get_sidebar_post($post_id);
						break;
					default:
						$return = $item->get_large_post($post_id);
						break;
				}
				return $return;
			}
		
		}
		
	}
}

$shortcode = new C5_Envato_Shortcode();
$shortcode->hook();
 ?>