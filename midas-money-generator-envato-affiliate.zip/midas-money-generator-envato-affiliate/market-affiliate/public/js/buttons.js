jQuery(document).ready(function($) {

  tinymce.create('tinymce.plugins.C5MA_Market_affiliate', {
        /**
         * Initializes the plugin, this will be executed after the plugin has been created.
         * This call is done before the editor instance has finished it's initialization so use the onInit event
         * of the editor instance to intercept that event.
         *
         * @param {tinymce.Editor} ed Editor instance that the plugin is initialized in.
         * @param {string} url Absolute URL to where the plugin is located.
         */
        init : function(ed, url) {
           ed.addCommand('c5maButton', function() {
                $('.c5ma-shortcode-button-wrap').fadeIn();     
            });
            
            

            ed.addButton('c5maButton', {
                title : 'Add Envato Items',
                cmd : 'c5maButton',
                image : url + '/icon.png'
            });
        },

        /**
         * Creates control instances based in the incomming name. This method is normally not
         * needed since the addButton method of the tinymce.Editor class is a more easy way of adding buttons
         * but you sometimes need to create more complex controls like listboxes, split buttons etc then this
         * method can be used to create those.
         *
         * @param {String} n Name of the control to create.
         * @param {tinymce.ControlManager} cm Control manager to use inorder to create new control.
         * @return {tinymce.ui.Control} New control instance or null if no control was created.
         */
        createControl : function(n, cm) {
            return null;
        },

        /**
         * Returns information about the plugin as a name/value array.
         * The current keys are longname, author, authorurl, infourl and version.
         *
         * @return {Object} Name/value array containing information about the plugin.
         */
        getInfo : function() {
            return {
                    longname : 'C5MA_Market_affiliate Buttons',
                    author : 'Code125',
                    authorurl : 'http://themeforest.net/user/code125/portfolio?ref=code125',
                    infourl : 'http://wiki.moxiecode.com/index.php/TinyMCE:Plugins/example',
                    version : "1.0"
            };
        }
    });

    // Register plugin
    tinymce.PluginManager.add('c5maMarketAffiliate', tinymce.plugins.C5MA_Market_affiliate);

	$('#c5ma-shortcode').on('change', function() {
		var select_value = this.value;
		$('.c5ma-parent').removeClass().addClass('c5ma-parent c5ma-' + select_value);
	});
	$(document).on('click', '.c5ma-close', function (e) {
		$('.c5ma-shortcode-button-wrap').css('display' , 'none');
	
	});
	$(document).on('click', '.c5ma-button-generate', function (e) {
		var current_shortcode = $( "#c5ma-shortcode" ).val();
		
		var response = '';
		
		if (current_shortcode == 'c5ma_envato_item') {
			response = '[c5ma_envato_item url="'+ $('#c5ma-url').val() +'" shape="'+ $('#c5ma-shape').val() +'"]';
			 
		}else if (current_shortcode == 'c5ma_envato_user') {
			response = '[c5ma_envato_user username="'+ $('#c5ma-username').val() +'" shape="'+ $('#c5ma-shape').val() +'" marketplace="'+ $('#c5ma-marketplace').val() +'" ]';
		}else if (current_shortcode == 'c5ma_envato_feed') {
			response = '[c5ma_envato_feed method="'+ $('#c5ma-method').val() +'" shape="'+ $('#c5ma-shape').val() +'" marketplace="'+ $('#c5ma-marketplace').val() +'"  category="'+ $('#c5ma-category').val() +'"  count="'+ $('#c5ma-count').val() +'" ]';
		}
		
		send_to_editor(response);
		$('.c5ma-shortcode-button-wrap').css('display' , 'none');
	
	});
	
	function c5ma_generate_shortcode(parameter) {
		
	}
	
		

});