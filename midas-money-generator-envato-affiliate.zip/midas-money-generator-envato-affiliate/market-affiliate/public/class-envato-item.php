<?php 
class C5_Envato_Item {
	
	function __construct() {
		
	}
	
	function decorate_url($post_id) {
		$url = $this->meta($post_id , 'url');
		$data = get_option('c5-market-affiliate');
		if ($data['envato_referal_username']!='') {
			$url .= '?ref='. $data['envato_referal_username'];
		}
		
		$final_url = $this->get_shorturl($url , $post_id);
		
		return $final_url;
	}
	
	function decorate_preview_url($post_id) {
		$url = $this->meta($post_id , 'url');
		$data = get_option('c5-market-affiliate');
		if ($data['envato_referal_username']!='') {
			$url .= '?ref='. $data['envato_referal_username'];
		}
		
		
		$item_id = $this->meta($post_id , 'item_id');
		
		$url = str_replace($item_id, 'full_screen_preview/' . $item_id, $url );
		$final_url = $this->get_shorturl($url , $post_id);
		
		return $final_url;
	}
	
	
	function get_shorturl($url , $post_id) {
		$request_url = '';
		if (function_exists('qppr_create_quick_redirect')) {
			
			$item_id =  html_entity_decode( get_the_title($post_id) );
			$item_id = preg_replace("/[^a-z0-9\s]/i", "", $item_id); 
			$item_id = str_replace('  ', ' ', $item_id );
			$item_id = str_replace(' ', '-', $item_id );
			
			if (strpos($url, 'full_screen_preview') !== false) {
				$item_id = $item_id . '-preview';
			}
			
			$request_url = home_url('/out/'.$item_id.'/');
//			$request_url = esc_url( $request_url );
			$atts = array( 
				'request_url'		=> $request_url,
				'destination_url'	=> $url,
				'newwindow'			=> 1,
				'nofollow'			=> 0,
			);
			$result = qppr_create_quick_redirect($atts);
			if (!$result) {
				$request_url = '';
			}
		}
		if ($request_url == '') {
			$request_url = $url;
		}
		return $request_url;
		
	}
	
	
	function meta($post_id, $key) {
		return get_post_meta($post_id, $key, true);
	}
	
	function get_author_url($post_id) {
		$url = $this->meta($post_id , 'url');
		$author = $this->meta($post_id, 'user');
		$marketplace = $this->meta($post_id , 'marketplace');
		
		$return = 'http://' . $marketplace . '.net/user/' . $author; 
		$data = get_option('c5-market-affiliate');
		if ($data['envato_referal_username']!='') {
			$return .= '?ref='. $data['envato_referal_username'];
		}
		return $return;
		
	}
	
	function get_item_preview($post_id) {
		$html = get_the_post_thumbnail( $post_id, 'full' );
		if ($html == '') {
			$aws = get_post_meta($post_id , 'live_preview_url_aws' , true);
			if ($aws!='') {
				$html = '<img src="'.$aws.'" class="attachment-full attachment-full c5-resize-image wp-post-image" alt="preview" />';
			}
		}
		return $html;
	}
	function get_item_thumb($post_id) {
		
		$thumbnail = $this->meta($post_id, 'thumbnail');
		$html = wp_get_attachment_image( $thumbnail, 'full' );
		if ($html == '') {
			$aws = get_post_meta($post_id , 'thumbnail_aws' , true);
			if ($aws!='') {
				$html = '<img src="'.$aws.'" class="attachment-full attachment-full c5-resize-image wp-post-image" alt="preview" />';
			}
		}
		return $html;
	}
	
	function get_item_thumbnail($post_id) {
		$html = get_the_post_thumbnail( $post_id, 'full' );
		if ($html == '') {
			$aws = get_post_meta($post_id , 'live_preview_url_aws' , true);
			if ($aws!='') {
				$html = '<img src="'.$aws.'" class="attachment-fullattachment-full c5-resize-image wp-post-image" alt="preview" />';
			}
		}
		return $html;
	}
	
	function get_item_buttons($post_id = '') {
		if ($post_id == '') {
			$post_id = get_the_ID();
		}
		
		$url = $this->decorate_url($post_id);
		
		$return = '';
		
		$return .= '<div class="c5ma-item-buttons clearfix">';
		
				
		
		$return .= '<div class="c5ma-item-purchase clearfix">';
			$url = $this->decorate_url($post_id);
			
			$cost = intval( $this->meta($post_id, 'cost') ) ;
			
			$return .= '<a href="'.$url.'" target="_blank" class="c5ma-btn c5ma-btn-purchase">' .__( 'Purchase' ,'c5-market-affiliate') . ' - '.$cost.' $</a>';
			
			$live_preview_url = $this->decorate_preview_url($post_id );
			$return .= '<a href="'.$live_preview_url.'" target="_blank" class="c5ma-btn c5ma-btn-preview">' .__( 'Preview' ,'c5-market-affiliate') . '</a>';
			
			
		$return .= '</div>';
		
		
		$return .= '</div>';
		
		return $return;
	}
	
	function get_large_post($post_id = '', $content = '') {
		if ($post_id == '') {
			$post_id = get_the_ID();
		}
		
		$url = $this->decorate_url($post_id);
		
		$return = '';
		
		$return .= '<div class="c5ma-post-large clearfix">';
		
		$return .= '<div class="c5ma-wide-image-wrap clearfix"><a href="'.$url.'" target="_blank">' . $this->get_item_preview($post_id) . '</a></div>';
		
		$return .= '<div class="c5ma-item-info clearfix">';
		$return .= '<div class="c5ma-item-info-main">';
			$return .= '<h3 class="c5ma-item-title"><a href="'.$url.'" target="_blank">'.get_the_title($post_id).'</a></h3>';
			
			$author = $this->meta($post_id, 'user');
			$author_url = $this->get_author_url($post_id);
			
			$return .= '<p class="c5ma-meta-info">';
			
			$return .= '<a class="c5ma-author" href="'.$author_url.'" target="_blank">' .__('By:' ,'c5-market-affiliate') . ' '.$author.'</a>';
			
			$created_at = date( get_option('date_format') , strtotime( $this->meta($post_id, 'uploaded_on') )) ;
			
			$return .= ' <span class="c5ma-created">, '.__( 'Created:','c5-market-affiliate').' '.$created_at.'</span>' ;
			if ( $this->meta($post_id, 'last_update') != $this->meta($post_id, 'uploaded_on')) {
				$last_update = human_time_diff(strtotime( $this->meta($post_id, 'last_update') )) ;
				
				$return .= ' <span class="c5ma-last_update">, '.__( 'Latest update:','c5-market-affiliate').' '.$last_update.' ' . __( 'ago' , 'c5-market-affiliate') . '</span>' ;
			}
			
			
			$return .= '</p>';
			
		$return .= '</div>';
		$return .= '<div class="c5ma-item-info-side">';
		
		$cost = intval( $this->meta($post_id, 'cost') ) ;
		
		$return .= '<p class="c5ma-price"><span class="c5ma-currency">$</span><span class="c5ma-cost">'.$cost.'</span></p>';
		
		$sales = intval( $this->meta($post_id, 'sales') ) ;
		$text = __('Sales','c5-market-affiliate');
		if ($sales == 1 || $sales == 0) {
			$text = __('Sale','c5-market-affiliate');
		}
		$return .= '<p class="c5ma-sales"><span class="c5ma-sales-count">'.number_format($sales). '</span> <span class="c5ma-sales-text">'.$text.'</span></p>';
		
		$return .= '</div>';
		
		if ($content!='') {
			$return .= '<div class="c5ma-content">'.$content.'</div>';
		}
		
		
		$return .= '<div class="c5ma-item-purchase clearfix">';
			$url = $this->decorate_url($post_id);
			
			$return .= '<a href="'.$url.'" target="_blank" class="c5ma-btn c5ma-btn-purchase">' .__( 'Purchase' ,'c5-market-affiliate') . '</a>';
			
			$live_preview_url = $this->decorate_preview_url($post_id );
			$return .= '<a href="'.$live_preview_url.'" target="_blank" class="c5ma-btn c5ma-btn-preview">' .__( 'Preview' ,'c5-market-affiliate') . '</a>';
			
			
		$return .= '</div>';
		
		$return .= '</div>';
		
		$return .= '</div>';
		
		return $return;
	}
	
	function get_banner_post($post_id = '' , $content = '') {
		if ($post_id == '') {
			$post_id = get_the_ID();
		}
		
		$url = $this->decorate_url($post_id);
		
		$return = '';
		
		$return .= '<div class="c5ma-post-banner clearfix"><div class="c5ma-row">';
		
		
		$return .= '<div class="c5ma-col-6"><div class="c5ma-item-info clearfix">';
		$return .= '<div class="c5ma-item-info-main">';
			$return .= '<h3 class="c5ma-item-title"><a href="'.$url.'" target="_blank">'.get_the_title($post_id).'</a></h3>';
			
			$author = $this->meta($post_id, 'user');
			$author_url = $this->get_author_url($post_id);
			
			$return .= '<p class="c5ma-meta-info">';
			
			$return .= '<a class="c5ma-author" href="'.$author_url.'" target="_blank">' .__('By:' ,'c5-market-affiliate') . ' '.$author.'</a>';
			
			$created_at = date( get_option('date_format') , strtotime( $this->meta($post_id, 'uploaded_on') )) ;
			
			$return .= ' <span class="c5ma-created">, '.__( 'Created:','c5-market-affiliate').' '.$created_at.'</span>' ;
			if ( $this->meta($post_id, 'last_update') != $this->meta($post_id, 'uploaded_on')) {
				$last_update = human_time_diff(strtotime( $this->meta($post_id, 'last_update') )) ;
				
				$return .= ' <span class="c5ma-last_update">, '.__( 'Latest update:','c5-market-affiliate').' '.$last_update.' ' . __( 'ago' , 'c5-market-affiliate') . '</span>' ;
			}
			
			
			$return .= '</p>';
			
		$return .= '</div>';
		$return .= '<div class="c5ma-item-info-side">';
		
		$cost = intval( $this->meta($post_id, 'cost') ) ;
		
		$return .= '<p class="c5ma-price"><span class="c5ma-currency">$</span><span class="c5ma-cost">'.$cost.'</span></p>';
		
		$sales = intval( $this->meta($post_id, 'sales') ) ;
		$text = __('Sales','c5-market-affiliate');
		if ($sales == 1 || $sales == 0) {
			$text = __('Sale','c5-market-affiliate');
		}
		$return .= '<p class="c5ma-sales"><span class="c5ma-sales-count">'.number_format($sales). '</span> <span class="c5ma-sales-text">'.$text.'</span></p>';
		
		$return .= '</div>';
		
		if ($content!='') {
			$return .= '<div class="c5ma-content">'.$content.'</div>';
		}
		
		$return .= '<div class="c5ma-item-purchase clearfix">';
			$url = $this->decorate_url($post_id);
			
			$return .= '<a href="'.$url.'" target="_blank" class="c5ma-btn c5ma-btn-purchase">' .__( 'Purchase' ,'c5-market-affiliate') . '</a>';
			
			$live_preview_url = $this->decorate_preview_url($post_id );
			$return .= '<a href="'.$live_preview_url.'" target="_blank" class="c5ma-btn c5ma-btn-preview">' .__( 'Preview' ,'c5-market-affiliate') . '</a>';
			
			
		$return .= '</div>';
		$return .= '</div></div>';
		
		$return .= '<div class="c5ma-col-6"><div class="c5ma-wide-image-wrap clearfix"><a href="'.$url.'" target="_blank">' . $this->get_item_preview($post_id) . '</a></div></div>';
		
		
		$return .= '</div>';
		
		$return .= '</div>';
		
		return $return;
	}
	
		
	
	function get_wide_post($post_id = '') {
		if ($post_id == '') {
			$post_id = get_the_ID();
		}
		
		$url = $this->decorate_url($post_id);
		
		$return = '';
		
		$return .= '<div class="c5ma-post-wide clearfix">';
		
		$return .= '<div class="c5ma-image-thumbnail clearfix"><a href="'.$url.'" target="_blank">' . $this->get_item_thumb($post_id) . '</a></div>';
		
		
		$return .= '<div class="c5ma-item-info-main">';
			$return .= '<h3 class="c5ma-item-title"><a href="'.$url.'" target="_blank">'.get_the_title($post_id).'</a></h3>';
			
			$author = $this->meta($post_id, 'user');
			$author_url = $this->get_author_url($post_id);
			
			$return .= '<p class="c5ma-meta-info">';
			
			$return .= '<a class="c5ma-author" href="'.$author_url.'" target="_blank">' .__('By:' ,'c5-market-affiliate') . ' '.$author.'</a>';
			
			$created_at = date( get_option('date_format') , strtotime( $this->meta($post_id, 'uploaded_on') )) ;
			
			$return .= ' <span class="c5ma-created">, '.__( 'Created:','c5-market-affiliate').' '.$created_at.'</span>' ;
			if ( $this->meta($post_id, 'last_update') != $this->meta($post_id, 'uploaded_on')) {
				$last_update = human_time_diff(strtotime( $this->meta($post_id, 'last_update') )) ;
				
				$return .= ' <span class="c5ma-last_update">, '.__( 'Latest update:','c5-market-affiliate').' '.$last_update.' ' . __( 'ago' , 'c5-market-affiliate') . '</span>' ;
			}
			
			
			$return .= '</p>';
			
		$return .= '</div>';
		$return .= '<div class="c5ma-item-info-side">';
		
		$cost = intval( $this->meta($post_id, 'cost') ) ;
		
		$return .= '<p class="c5ma-price"><span class="c5ma-currency">$</span><span class="c5ma-cost">'.$cost.'</span></p>';
		
		$sales = intval( $this->meta($post_id, 'sales') ) ;
		$text = __('Sales','c5-market-affiliate');
		if ($sales == 1 || $sales == 0) {
			$text = __('Sale','c5-market-affiliate');
		}
		$return .= '<p class="c5ma-sales"><span class="c5ma-sales-count">'.number_format($sales). '</span> <span class="c5ma-sales-text">'.$text.'</span></p>';
		
		$return .= '</div>';
		
		
		
		
		
		
		$return .= '</div>';
		
		return $return;
	}
	
	function get_sidebar_post($post_id = '') {
		if ($post_id == '') {
			$post_id = get_the_ID();
		}
		
		$url = $this->decorate_url($post_id);
		
		$return = '';
		
		$return .= '<div class="c5ma-post-sidebar clearfix">';
		
		$return .= '<div class="c5ma-image-thumbnail clearfix"><a href="'.$url.'" target="_blank">' . $this->get_item_thumb($post_id) . '</a></div>';
		
		
		$return .= '<div class="c5ma-item-info-main">';
			$return .= '<h3 class="c5ma-item-title"><a href="'.$url.'" target="_blank">'.get_the_title($post_id).'</a></h3>';
			
			$cost = intval( $this->meta($post_id, 'cost') ) ;
			
			$return .= '<p class="c5ma-price"><span class="c5ma-currency">$</span><span class="c5ma-cost">'.$cost.'</span></p>';
			
			$sales = intval( $this->meta($post_id, 'sales') ) ;
			$text = __('Sales','c5-market-affiliate');
			if ($sales == 1 || $sales == 0) {
				$text = __('Sale','c5-market-affiliate');
			}
			$return .= '<p class="c5ma-sales"><span class="c5ma-sales-count">'.number_format($sales). '</span> <span class="c5ma-sales-text">'.$text.'</span></p>';
		
		$return .= '</div>';
		
		
		
		
		
		
		$return .= '</div>';
		
		return $return;
	}
	
	
	
	function get_tall_post($post_id = '') {
		if ($post_id == '') {
			$post_id = get_the_ID();
		}
		
		$url = $this->decorate_url($post_id);
		
		$return = '';
		
		$return .= '<div class="c5ma-post-tall clearfix">';
		
		$return .= '<div class="c5ma-wide-image-wrap clearfix"><a href="'.$url.'" target="_blank">' . $this->get_item_preview($post_id) . '</a></div>';
		
		$return .= '<div class="c5ma-item-wrap clearfix">';
		
		$return .= '<h3 class="c5ma-item-title"><a href="'.$url.'" target="_blank">'.get_the_title($post_id).'</a></h3> <div class="clearfix"></div>';
		
		$return .= '<div class="c5ma-item-info-main clearfix">';
			
			
			$author = $this->meta($post_id, 'user');
			$author_url = $this->get_author_url($post_id);
			
			$return .= '<p class="c5ma-meta-info">';
			
			$return .= '<a class="c5ma-author" href="'.$author_url.'" target="_blank"> '.$author.'</a></p>';
			
			$return .= '<p class="c5ma-meta-info">';
			
			$created_at = date( get_option('date_format') , strtotime( $this->meta($post_id, 'uploaded_on') )) ;
			
			$return .= ' <span class="c5ma-created">'.__( 'Created:','c5-market-affiliate').' '.$created_at.'</span><br/>' ;
			
			if ( $this->meta($post_id, 'last_update') != $this->meta($post_id, 'uploaded_on')) {
				$last_update = human_time_diff(strtotime( $this->meta($post_id, 'last_update') )) ;
				
				$return .= ' <span class="c5ma-last_update">'.__( 'Latest update:','c5-market-affiliate').' '.$last_update.' ' . __( 'ago' , 'c5-market-affiliate') . '</span>' ;
			}
			
			$return .= '</p>';
			
		$return .= '</div>';
		$return .= '<div class="c5ma-item-info-side">';
		
		$cost = intval( $this->meta($post_id, 'cost') ) ;
		
		$return .= '<p class="c5ma-price"><span class="c5ma-currency">$</span><span class="c5ma-cost">'.$cost.'</span></p>';
		
		$sales = intval( $this->meta($post_id, 'sales') ) ;
		$text = __('Sales','c5-market-affiliate');
		if ($sales == 1 || $sales == 0) {
			$text = __('Sale','c5-market-affiliate');
		}
		$return .= '<p class="c5ma-sales"><span class="c5ma-sales-count">'.number_format($sales). '</span> <span class="c5ma-sales-text">'.$text.'</span></p>';
		
		$return .= '</div>';
		
		
		
		
		$return .= '<div class="clearfix"></div></div>';
		
		$return .= '</div>';
		
		return $return;
	}
	
	function get_thumb_post($post_id = '') {
		if ($post_id == '') {
			$post_id = get_the_ID();
		}
		
		$url = $this->decorate_url($post_id);
		
		$return = '';
		
		$return .= '<div class="c5ma-post-thumb clearfix">';
		
		$return .= '<div class="c5ma-image-thumbnail clearfix"><a href="'.$url.'" target="_blank">' . $this->get_item_thumb($post_id) . '</a></div>';
		
		
		$return .= '<div class="c5ma-item-info-main">';
			$return .= '<h3 class="c5ma-item-title"><a href="'.$url.'" target="_blank">'.get_the_title($post_id).'</a></h3>';
			
			
			
		$return .= '</div>';
		$return .= '<div class="c5ma-item-info-side">';
		
		$cost = intval( $this->meta($post_id, 'cost') ) ;
		
		$return .= '<p class="c5ma-price"><span class="c5ma-currency">$</span><span class="c5ma-cost">'.$cost.'</span></p>';
		
		$sales = intval( $this->meta($post_id, 'sales') ) ;
		$text = __('Sales','c5-market-affiliate');
		if ($sales == 1 || $sales == 0) {
			$text = __('Sale','c5-market-affiliate');
		}
		$return .= '<p class="c5ma-sales"><span class="c5ma-sales-count">'.number_format($sales). '</span> <span class="c5ma-sales-text">'.$text.'</span></p>';
		
		$return .= '</div>';
		
		
		
		
		
		
		$return .= '</div>';
		
		return $return;
	}
}

 ?>