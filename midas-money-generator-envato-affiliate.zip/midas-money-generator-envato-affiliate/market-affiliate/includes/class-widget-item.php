<?php 
// Creating the widget 
class C5MA_item_widget extends WP_Widget {
	
	function __construct() {
		parent::__construct(
		// Base ID of your widget
		'c5ma_item_widget', 
		
		// Widget name will appear in UI
		__('[Market Affiliate] Item', 'c5-market-affiliate'), 
		
		// Widget description
		array( 'description' => __( 'Market Affiliate Item Widget', 'c5-market-affiliate' ), ) 
	);
}

// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
	$title = apply_filters( 'widget_title', $instance['title'] );
	// before and after widget arguments are defined by themes
	echo $args['before_widget'];
	if ( ! empty( $title ) )
	echo $args['before_title'] . $title . $args['after_title'];
	
	if (!isset($instance['content'])) {
		$instance['content'] = '';
	}
	
	// This is where you run the code and display the output
	echo '<div class="clearfix">';
	echo do_shortcode('[c5ma_envato_item url="'.$instance['url'].'" shape="'.$instance['shape'].'"]'.$instance['content'].'[/c5ma_envato_item]');
	echo '</div>';
	
	echo $args['after_widget'];
}

// Widget Backend 
public function form( $instance ) {
	if ( isset( $instance[ 'title' ] ) ) {
		$title = $instance[ 'title' ];
	}else {
		$title = '';
	}
	if ( isset( $instance[ 'url' ] ) ) {
		$url = $instance[ 'url' ];
	}else {
		$url = '';
	}
	if ( isset( $instance[ 'shape' ] ) ) {
		$shape = $instance[ 'shape' ];
	}else {
		$shape = '';
	}
	
	if ( isset( $instance[ 'content' ] ) ) {
		$content = $instance[ 'content' ];
	}else {
		$content = '';
	}
	
	// Widget admin form
	?>
	<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ,'c5-market-affiliate'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'url' ); ?>"><?php _e( 'Item URL:' , 'c5-market-affiliate' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'url' ); ?>" name="<?php echo $this->get_field_name( 'url' ); ?>" type="text" value="<?php echo esc_attr( $url ); ?>" />
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'shape' ); ?>"><?php _e( 'Shape:' , 'c5-market-affiliate' ); ?></label> 
		<select class="widefat" id="<?php echo $this->get_field_id( 'shape' ); ?>" name="<?php echo $this->get_field_name( 'shape' ); ?>">
		<?php 
		$saved_value = $shape;
		$options = array(
			array(
				'label' => 'Big',
				'value' => 'big'
			),
			array(
				'label' => 'Banner',
				'value' => 'banner'
			),
			array(
				'label' => 'Wide',
				'value' => 'wide'
			),
			array(
				'label' => 'Tall',
				'value' => 'tall'
			),
			array(
				'label' => 'Thumbnail',
				'value' => 'thumbnail'
			),
			array(
				'label' => 'Sidebar',
				'value' => 'sidebar'
			),
		);
		foreach ($options as $option) {
			$selected = '';
			if ($option['value'] == $saved_value) {
				$selected = 'selected="selected"';
			}
			echo '<option value="'.$option['value'].'" '.$selected.'>'.$option['label'].'</option>';
		}
		 ?>
		
		</select>
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'content' ); ?>"><?php _e( 'Description:' ,'c5-market-affiliate'); ?></label>
		<span class="description"><?php _e('Only for Banner and Big Style','c5-market-affiliate') ?></span> 
		<textarea class="widefat" id="<?php echo $this->get_field_id( 'content' ); ?>" name="<?php echo $this->get_field_name( 'content' ); ?>" type="text" ><?php echo esc_textarea( $content ); ?></textarea>
	</p>
	<?php 
}

// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
	$instance = array();
	$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
	$instance['url'] = ( ! empty( $new_instance['url'] ) ) ? strip_tags( $new_instance['url'] ) : '';
	$instance['shape'] = ( ! empty( $new_instance['shape'] ) ) ? strip_tags( $new_instance['shape'] ) : '';
	$instance['content'] = ( ! empty( $new_instance['content'] ) ) ? strip_tags( $new_instance['content'] ) : '';
	return $instance;
}
} // Class c5ma_item_widget ends here

// Register and load the widget
function c5ma_item_load_widget() {
	register_widget( 'C5MA_item_widget' );
}
add_action( 'widgets_init', 'c5ma_item_load_widget' );

?>