<?php 
class C5_Market_Affiliate_button {
	function __construct() {
		
	}
	
	function hook() {
		add_action( 'init', array($this, 'buttons'));
		add_action('admin_notices' ,  array($this, 'generator_button') );
	}

	
	
	
	function buttons() {
	    add_filter( "mce_external_plugins", array($this, 'add_buttons')  );
	    add_filter( 'mce_buttons', array($this, 'register_buttons')  );
	}
	function add_buttons( $plugin_array ) {
	    $plugin_array['c5maMarketAffiliate'] = C5MA_URL . '/public/js/buttons.js';
	    return $plugin_array;
	}
	function register_buttons( $buttons ) {
	    $buttons[] = 'c5maButton'; // dropcap', 'recentposts
	    return $buttons;
	}
	
	function generator_button() {
		
		$return = '<div class="c5ma-shortcode-button-wrap clearfix" style="display:none"><div class="c5ma-shortcode-button"><div class="c5ma-parent c5ma-c5ma_envato_item"><p class="c5ma-close">X</p>';
		
		$return .= '<form method="post" action="">';
		
		$return .= '<p>'.__('Choose the Shortcode type and its option will appear below','c5-market-affiliate').'</p>';
		
		$return .= $this->show_options();
		
		$return .= '<p class="c5ma-button c5ma-button-generate">Generate Shortcode</p>';
		
		$return .= '</form>';
		
		$return .= '</div></div></div>';
		
		echo $return;
		
	}
	
	function show_options() {
	
	
		$return = '';
		
		$options = $this->options();
		foreach ($options as $option) {
			$classes = explode(',', $option['parent']);
			$class = '';
			foreach ($classes as $single_class) {
				$class .= 'c5ma-' .$single_class . ' ';
			}
			switch ($option['type']) {
				case 'text':
					
					$return .= '<div class="c5ma-settings c5ma-settings-'.$option['id'].' '.$class.'">';
					$return .= '<label for="c5ma-'.$option['id'].'">'.$option['label'].'</label>';
					
					if ($option['desc'] != '') {
						$return .= '<p class="desc">' . $option['desc'] . '</p>';
					}
					
					$return .= '<input name="c5ma-'. $option['id'] .'" type="text" id="c5ma-'. $option['id'] .'" value="'. $option['std'] .'" class="regular-text" >';
					
					$return .= '</div>';
					break;
				case 'select':
					$return .= '<div class="c5ma-settings c5ma-settings-'.$option['id'].' '.$class.'">';
					$return .= '<label for="c5ma-'.$option['id'].'">'.$option['label'].'</label>';
					
					if ($option['desc'] != '') {
						$return .= '<p class="desc">' . $option['desc'] . '</p>';
					}
					
					$return .= '<select name="c5ma-'. $option['id'] .'" id="c5ma-'. $option['id'] .'"  class="regular-select" >';
					
					foreach ($option['choices'] as $choice) {
						$selected = '';
						if ($choice['value'] == $option['std'] ) {
							$selected = 'selected="selected"';
						}
						$return .= '<option value="'.$choice['value'].'" '.$selected.'>'.$choice['label'].'</option>';
					}
				
					
					$return .= '</select>';
					
					$return .= '</div>';
					break;
			}
		}
		
		return $return;
		
	}
	
	function options() {
		
		$options = array(
			array(
				'id'=>'shortcode',
				'type'=>'select',
				'label' => __('Choose Shortcode','c5-market-affiliate'),
				'std' => 'c5ma_envato_item',
				'choices'=>array(
					array(
						'label' => 'Envato Item',
						'value' => 'c5ma_envato_item'
					),
					array(
						'label' => 'Envato User',
						'value' => 'c5ma_envato_user'
					),
					array(
						'label' => 'Envato Feed',
						'value' => 'c5ma_envato_feed'
					),
				)
			),
			array(
				'id'=>'url',
				'type'=>'text',
				'label' => __('Item Url ','c5-market-affiliate'),
				'parent' => 'c5ma_envato_item',
			),
			array(
				'id'=>'username',
				'type'=>'text',
				'label' => __('Author Username ','c5-market-affiliate'),
				'parent' => 'c5ma_envato_user',
			),
			array(
				'id'=>'shape',
				'type'=>'select',
				'label' => __('Choose Shape','c5-market-affiliate'),
				'std' => 'big',
				'parent' => 'c5ma_envato_item,c5ma_envato_user,c5ma_envato_feed',
				'choices'=>array(
					array(
						'label' => 'Big',
						'value' => 'big'
					),
					array(
						'label' => 'Banner',
						'value' => 'banner'
					),
					array(
						'label' => 'Wide',
						'value' => 'wide'
					),
					array(
						'label' => 'Tall',
						'value' => 'tall'
					),
					array(
						'label' => 'Thumbnail',
						'value' => 'thumbnail'
					),
					array(
						'label' => 'Sidebar',
						'value' => 'sidebar'
					),
					array(
						'label' => 'Buttons',
						'value' => 'buttons'
					),
				)
			),
			array(
				'id'=>'marketplace',
				'type'=>'select',
				'label' => __('Select Marketplace','c5-market-affiliate'),
				'std' => 'themeforest',
				'parent' => 'c5ma_envato_user,c5ma_envato_feed',
				'choices'=>array(
					array(
						'label' => 'ThemeForest',
						'value' => 'themeforest'
					),
					array(
						'label' => 'CodeCanyon',
						'value' => 'codecanyon'
					),
					array(
						'label' => 'VideoHive',
						'value' => 'videohive'
					),
					array(
						'label' => 'AudioJungle',
						'value' => 'audiojungle'
					),
					array(
						'label' => 'GraphicRiver',
						'value' => 'graphicriver'
					),
					array(
						'label' => 'PhotoDune',
						'value' => 'photodune'
					),
					array(
						'label' => '3DOcean',
						'value' => '3docean'
					),
					array(
						'label' => 'ActiveDen',
						'value' => 'activeden'
					),
				)
			),
			array(
				'id'=>'method',
				'type'=>'select',
				'label' => __('Select Feed Type','c5-market-affiliate'),
				'std' => 'new',
				'parent' => 'c5ma_envato_feed',
				'choices'=>array(
					array(
						'label' => 'New items',
						'value' => 'new'
					),
					array(
						'label' => 'Popular',
						'value' => 'popular'
					),
					array(
						'label' => 'Featured',
						'value' => 'featured'
					),
					array(
						'label' => 'Random',
						'value' => 'random'
					)
				)
			),
			array(
				'id'=>'category',
				'type'=>'text',
				'parent' => 'c5ma_envato_feed',
				'label' => __('Category ','c5-market-affiliate'),
			),
			
			array(
				'id'=>'count',
				'type'=>'text',
				'std' => '9',
				'parent' => 'c5ma_envato_feed',
				'label' => __('Count','c5-market-affiliate'),
				
			),
			
		
		);
		
		$defaults = array(
			'id'=>'',
			'type'=>'',
			'desc'=>'',
			'label'=>'',
			'parent'=>'',
			'std'=>'',
			'choices' => array(),
		);
		$final_options = array();
		foreach ($options as $option) {
			$final_options[] = shortcode_atts(
					$defaults, $option );
		}
		return $final_options;
		
		
		
	}
}

$obj = new C5_Market_Affiliate_button();
$obj->hook();

 ?>