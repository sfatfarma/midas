<?php 

class C5_Envato_Affiliate_CPT {
	function __construct() {
		
	}
	function hook() {
		add_action( 'init', array($this , 'register_post_type') );
	}
	
	
	function register_post_type() {
		$labels = array(
			'name'               => __( 'Envato items', 'c5-market-affiliate' ),
			'singular_name'      => __( 'Envato item', 'c5-market-affiliate' ),
			'menu_name'          => __( 'Envato items', 'c5-market-affiliate' ),
			'name_admin_bar'     => __( 'Envato item', 'c5-market-affiliate' ),
			'add_new'            => __( 'Add New', 'c5-market-affiliate' ),
			'add_new_item'       => __( 'Add New Envato item', 'c5-market-affiliate' ),
			'new_item'           => __( 'New Envato item', 'c5-market-affiliate' ),
			'edit_item'          => __( 'Edit Envato item', 'c5-market-affiliate' ),
			'view_item'          => __( 'View Envato item', 'c5-market-affiliate' ),
			'all_items'          => __( 'All Envato items', 'c5-market-affiliate' ),
			'search_items'       => __( 'Search Envato items', 'c5-market-affiliate' ),
			'parent_item_colon'  => __( 'Parent Envato items:', 'c5-market-affiliate' ),
			'not_found'          => __( 'No Envato items found.', 'c5-market-affiliate' ),
			'not_found_in_trash' => __( 'No Envato items found in Trash.', 'c5-market-affiliate' )
		);
	
		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'envato-item' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title', 'editor', 'thumbnail', 'excerpt' )
		);
	
		register_post_type( 'envato-item', $args );
		
		
	}
	
	
	
	function get_user_items($username = 'code125', $marketplace='themeforest') {
		
		
		if ( false === ( $website_ids = get_transient( 'c5ea_user_data_' . $username . '_' . $marketplace ) ) ) {
//		if(true){	
		  $args = get_option('c5-market-affiliate');
		  $envato = new C5_Envato_API($args);
		  
		  
		  $items = $envato->get_user_items($username, $marketplace);
		  $website_ids = array();
		  foreach ($items as $item_data) {
		  	$website_ids[] = $this->check_and_create($item_data);
		  }
		  
		  set_transient( 'c5ea_user_data_' . $username . '_' . $marketplace , $website_ids , 60*60 );
		}
		return $website_ids;
	}
	function get_feed_items($method = 'new', $marketplace='themeforest',$category= 'wordpress') {
		
		$key = 'c5ea_feed_data_' . $method . '_' . $marketplace . '_' .$category;
		
		if ( false === ( $website_ids = get_transient( $key ) ) ) {
//		if(true){	
		  $args = get_option('c5-market-affiliate');
		  $envato = new C5_Envato_API($args);
		  
		  switch ($method) {
		  	case 'new':
		  		$items = $envato->get_new_items($marketplace, $category);
		  		break;
		  	case 'popular':
	  			$items = $envato->get_popular_items($marketplace);
	  			break;
	  		case 'featured':
				$items = $envato->get_featured_items($marketplace);
				break;
			case 'random':
				$items = $envato->get_random_items($marketplace);
				break;
			}
		  
		  $website_ids = array();
		  foreach ($items as $item_data) {
		  	$website_ids[] = $this->get_item_post_id($item_data['id']);
		  }
		  
		  set_transient( $key  , 60*60 );
		}
		return $website_ids;
	}
	
	function get_item_by_url($url) {
		$url_atts = explode('/', $url);
		
		
		if (isset($url_atts[5])) {
			return $this->get_item_post_id( $url_atts[5] );
		}
		return false;
	}
	function get_item_post_id($item_id) {
		$args = array(
			'post_type'=>'envato-item',
			'posts_per_page' => -1,
			'meta_query' => array(
					array(
						'key'     => 'item_id',
						'value'   => $item_id,
					),
				),
		);
		
		// The Query
		$the_query = new WP_Query( $args );
		
		// The Loop
		if ( $the_query->have_posts() ) {
			
			while ( $the_query->have_posts() ) {
				$the_query->the_post();
				$post_id = get_the_ID();
			}
		} else {
			$post_id = $this->add_new_item($item_id);
		}
		
		$data = get_option('c5-market-affiliate');
		
		$c5_envato_sales_updated = get_post_meta($post_id, 'c5_envato_sales_updated', true);
		$cache_time = 60*60;
		if (isset($data['envato_sales_cache'])) {
			$data['envato_sales_cache'] = intval($data['envato_sales_cache']);
			if ($data['envato_sales_cache'] >= 3600 && $data['envato_sales_cache'] <= 604800) {
				$cache_time= $data['envato_sales_cache'] ;
			}
		}
		if ( (time() - $c5_envato_sales_updated ) > $cache_time ) {
		
			$this->update_item_sales($post_id , $item_id);
		}
		
		
		
		$c5_envato_updated = get_post_meta($post_id, 'c5_envato_updated', true);
		
		$cache_time = 60*60*24;
		if (isset($data['envato_cache'])) {
			$data['envato_cache'] = intval($data['envato_cache']);
			if ($data['envato_cache'] >= 3600 && $data['envato_cache'] <= 604800) {
				$cache_time= $data['envato_cache'] ;
			}
		}
		if ( (time() - $c5_envato_updated ) > $cache_time ) {
		
			$attachmentid = get_post_meta($post_id, 'live_preview_url', true);
			wp_delete_attachment( $attachmentid, true );
			
			$attachmentid = get_post_meta($post_id, 'thumbnail', true);
			wp_delete_attachment( $attachmentid, true );
			
			$post_id = $this->update_envato_item($post_id , $item_id);
		}
		
		wp_reset_postdata();
		
		return $post_id;
	}
	
	function update_item_sales($post_id , $item_id) {
		$args = get_option('c5-market-affiliate');
		$envato = new C5_Envato_API($args);
		
		$data = $envato->get_item($item_id );
		$old_sales = get_post_meta($post_id, 'sales', true);
		if ($data['sales'] > $old_sales) {
			update_post_meta($post_id, 'sales', $data['sales']);	
		}
		
		update_post_meta($post_id , 'c5_envato_sales_updated', time() );
	}
	
	function update_envato_item($post_id , $item_id) {
		
		
		
		
		$args = get_option('c5-market-affiliate');
		$envato = new C5_Envato_API($args);
		
		$data = $envato->get_item($item_id );
		
		$envato_item = array(
		  'post_title'    => $data['item'],
		  'ID'           => $post_id,
		);
		unset($data['item']);
		$post_id = wp_update_post( $envato_item );
		
		return $this->update_meta_data($post_id , $item_id , $data);
		
	}
	
	function add_new_item($item_id) {
		
		$args = get_option('c5-market-affiliate');
		$envato = new C5_Envato_API($args);
		
		$data = $envato->get_item($item_id );
		
		return $this->create_item($data);
		
		
	}
	
	function check_and_create($data) {
		$args = array(
			'post_type'=>'envato-item',
			'posts_per_page' => -1,
			'meta_query' => array(
					array(
						'key'     => 'item_id',
						'value'   => $data['id'],
					),
				),
		);
		
		// The Query
		$the_query = new WP_Query( $args );
		
		// The Loop
		if ( $the_query->have_posts() ) {
			
			while ( $the_query->have_posts() ) {
				$the_query->the_post();
				$post_id = get_the_ID();
			}
		} else {
			$post_id = $this->create_item($data);
		}
		return $post_id;
	}
	
	function create_item($data) {
		$envato_item = array(
		  'post_title'    => $data['item'],
		  'post_type'     => 'envato-item',
		  'post_status'    => 'publish'
		);
		unset($data['item']);
		$post_id = wp_insert_post( $envato_item );
		
		return $this->update_meta_data($post_id , $data['id'] , $data);
	}
	
	function update_meta_data($post_id , $item_id , $data) {
		update_post_meta($post_id , 'item_id', $data['id']);
		unset( $data['id'] );
		$attachment_id = $this->upload_image( $data['live_preview_url'] , $post_id );
		$data['live_preview_url_aws'] = $data['live_preview_url'];
		$data['live_preview_url'] = $attachment_id;
		
		$attachment_id = $this->upload_image( $data['thumbnail'] , $post_id );
		$data['thumbnail_aws'] = $data['thumbnail'];
		$data['thumbnail'] = $attachment_id;
		
		update_post_meta($post_id , '_thumbnail_id' , $data['live_preview_url']);
		
		foreach ($data as $key => $value) {
			update_post_meta($post_id , $key, $value);
		}
		
		$websites = array(
			'themeforest',
			'codecanyon',
			'videohive',
			'photodune',
			'audiojungle',
			'3docean',
			'graphicriver',
			'activeden',
		);
		$current_website = 'themeforest';
		foreach ($websites as $website) {
			$pos = strpos($data['url'], $website);
			
			if ($pos !== false) {
			    $current_website = $website;
			}
		}
		update_post_meta($post_id , 'marketplace', $current_website);
		
		update_post_meta($post_id , 'c5_envato_updated', time() );
		
		
		return $post_id;
	}
	
	function upload_image( $photo_name , $postid  ) {
		if( !class_exists( 'WP_Http' ) )
		  include_once( ABSPATH . WPINC. '/class-http.php' );
		
		$photo = new WP_Http();
		$photo = $photo->request( $photo_name );
		if (is_wp_error($photo)) {
//			print_r($photo);
			return false;
		}
		if( $photo['response']['code'] != 200 )
			return false;
	
		$attachment = wp_upload_bits(  basename( $photo_name ) , null, $photo['body'], date("Y-m", strtotime( $photo['headers']['last-modified'] ) ) );
		
		if( !empty( $attachment['error'] ) )
			return false;
	
		$filetype = wp_check_filetype( basename( $attachment['file'] ), null );
	
		$postinfo = array(
			'post_mime_type'	=> $filetype['type'],
			'post_title'		=> preg_replace( '/\.[^.]+$/', '', basename( $photo_name ) ),
			'post_content'		=> '',
			'post_status'		=> 'inherit',
		);
		$filename = $attachment['file'];
		$attach_id = wp_insert_attachment( $postinfo, $filename, $postid );
	
		if( !function_exists( 'wp_generate_attachment_data' ) )
			require_once(ABSPATH . "wp-admin" . '/includes/image.php');
		$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
		wp_update_attachment_metadata( $attach_id,  $attach_data );
		return $attach_id;
	}
	
	
	/*
	function upload_image($filename , $parent_post_id) {
		
		// Check the type of file. We'll use this as the 'post_mime_type'.
		$filetype = wp_check_filetype( basename( $filename ), null );
		
		// Get the path to the upload directory.
		$wp_upload_dir = wp_upload_dir();
		
		// Prepare an array of post data for the attachment.
		$attachment = array(
			'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename ), 
			'post_mime_type' => $filetype['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
			'post_content'   => '',
			'post_status'    => 'publish'
		);
		print_r($attachment);
		
		// Insert the attachment.
		$attach_id = wp_insert_attachment( $attachment, $filename, $parent_post_id );
		
//		 Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
//		require_once( ABSPATH . 'wp-admin/includes/image.php' );
//		
//		 Generate the metadata for the attachment, and update the database record.
//		$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
//		wp_update_attachment_metadata( $attach_id, $attach_data );
	}
	*/
	
}
$C5_Envato_Affiliate_CPT = new C5_Envato_Affiliate_CPT();
$C5_Envato_Affiliate_CPT->hook();

 ?>