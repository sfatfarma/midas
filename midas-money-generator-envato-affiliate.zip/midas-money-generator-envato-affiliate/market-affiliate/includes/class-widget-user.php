<?php 
// Creating the widget 
class C5MA_user_widget extends WP_Widget {
	
	function __construct() {
		parent::__construct(
		// Base ID of your widget
		'c5ma_user_widget', 
		
		// Widget name will appear in UI
		__('[Market Affiliate] User Feed', 'c5-market-affiliate'), 
		
		// Widget description
		array( 'description' => __( 'Market Affiliate User Feed Widget', 'c5-market-affiliate' ), ) 
	);
}

// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
	$title = apply_filters( 'widget_title', $instance['title'] );
	// before and after widget arguments are defined by themes
	echo $args['before_widget'];
	if ( ! empty( $title ) )
	echo $args['before_title'] . $title . $args['after_title'];
	
	// This is where you run the code and display the output
	echo '<div class="clearfix">';
	echo do_shortcode('[c5ma_envato_user username="'.$instance['username'].'" shape="'.$instance['shape'].'" marketplace="'.$instance['marketplace'].'"]');
	echo '</div>';
	
	echo $args['after_widget'];
}

// Widget Backend 
public function form( $instance ) {
	if ( isset( $instance[ 'title' ] ) ) {
		$title = $instance[ 'title' ];
	}else {
		$title = '';
	}
	if ( isset( $instance[ 'username' ] ) ) {
		$username = $instance[ 'username' ];
	}else {
		$username = '';
	}
	if ( isset( $instance[ 'shape' ] ) ) {
		$shape = $instance[ 'shape' ];
	}else {
		$shape = '';
	}
	if ( isset( $instance[ 'marketplace' ] ) ) {
		$marketplace = $instance[ 'marketplace' ];
	}else {
		$marketplace = '';
	}
	
	// Widget admin form
	?>
	<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ,'c5-market-affiliate'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'username' ); ?>"><?php _e( 'Username:' , 'c5-market-affiliate' ); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'username' ); ?>" name="<?php echo $this->get_field_name( 'username' ); ?>" type="text" value="<?php echo esc_attr( $username ); ?>" />
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'shape' ); ?>"><?php _e( 'Shape:' , 'c5-market-affiliate' ); ?></label> 
		<select class="widefat" id="<?php echo $this->get_field_id( 'shape' ); ?>" name="<?php echo $this->get_field_name( 'shape' ); ?>">
		<?php 
		$saved_value = $shape;
		$options = array(
			array(
				'label' => 'Big',
				'value' => 'big'
			),
			array(
				'label' => 'Wide',
				'value' => 'wide'
			),
			array(
				'label' => 'Tall',
				'value' => 'tall'
			),
			array(
				'label' => 'Thumbnail',
				'value' => 'thumbnail'
			),
			array(
				'label' => 'Sidebar',
				'value' => 'sidebar'
			),
		);
		foreach ($options as $option) {
			$selected = '';
			if ($option['value'] == $saved_value) {
				$selected = 'selected="selected"';
			}
			echo '<option value="'.$option['value'].'" '.$selected.'>'.$option['label'].'</option>';
		}
		 ?>
		
		</select>
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'marketplace' ); ?>"><?php _e( 'MarketPlace:' , 'c5-market-affiliate' ); ?></label> 
		<select class="widefat" id="<?php echo $this->get_field_id( 'marketplace' ); ?>" name="<?php echo $this->get_field_name( 'marketplace' ); ?>">
		<?php 
		$saved_value = $marketplace;
		$options = array(
			array(
				'label' => 'ThemeForest',
				'value' => 'themeforest'
			),
			array(
				'label' => 'CodeCanyon',
				'value' => 'codecanyon'
			),
			array(
				'label' => 'VideoHive',
				'value' => 'videohive'
			),
			array(
				'label' => 'AudioJungle',
				'value' => 'audiojungle'
			),
			array(
				'label' => 'GraphicRiver',
				'value' => 'graphicriver'
			),
			array(
				'label' => 'PhotoDune',
				'value' => 'photodune'
			),
			array(
				'label' => '3DOcean',
				'value' => '3docean'
			),
			array(
				'label' => 'ActiveDen',
				'value' => 'activeden'
			),
		);
		foreach ($options as $option) {
			$selected = '';
			if ($option['value'] == $saved_value) {
				$selected = 'selected="selected"';
			}
			echo '<option value="'.$option['value'].'" '.$selected.'>'.$option['label'].'</option>';
		}
		 ?>
		
		</select>
	</p>
	<?php 
}

// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
	$instance = array();
	$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
	$instance['username'] = ( ! empty( $new_instance['username'] ) ) ? strip_tags( $new_instance['username'] ) : '';
	$instance['shape'] = ( ! empty( $new_instance['shape'] ) ) ? strip_tags( $new_instance['shape'] ) : '';
	$instance['marketplace'] = ( ! empty( $new_instance['marketplace'] ) ) ? strip_tags( $new_instance['marketplace'] ) : '';
	return $instance;
}
} // Class c5ma_user_widget ends here

// Register and load the widget
function c5ma_user_load_widget() {
	register_widget( 'C5MA_user_widget' );
}
add_action( 'widgets_init', 'c5ma_user_load_widget' );

?>