<?php 

class C5_Envato_API {
	
	public $app_name = '';
	public $app_secret_key = '';
	public $oAuth_client_ID = '';
	public $redirect_url = '';
	public $code = '';
	
	public $refresh_token = '';
	public $token_type = '';
	public $access_token = '';
	public $expires_in = '';
	public $last_update = '';
	
	
	public $slug = '';
	
	function __construct($args) {
		$this->constants($args);
	}
	
	function constants($args) {
		$this->update_args($args);
		
		
//		$this->app_name = 'Envato Affiliate WP Plugin';
//		$this->app_secret_key = '9FCDYWJWv4a2So7SfXkHMpiJMcwrTROK';
//		$this->oAuth_client_ID = 'envato-affiliate-wp-plugin-8lwf50z7';
//		$this->redirect_url = 'http://envato-affiliate.code125.com/wp-admin/';
	
	}
	
	function update_args($args) {
		$this->app_name = $args['envato_app_name'];
		$this->app_secret_key = $args['envato_app_secret_key'];
		$this->oAuth_client_ID = $args['envato_app_client_id'];
		$this->redirect_url = $args['envato_app_redirect_url'];
		$this->code  = $args['envato_app_code'];
		
		$raw_args = array('refresh_token' , 'token_type' ,'access_token', 'expires_in' , 'last_update');
		foreach ($raw_args as $key) {
			$new_key = 'envato_' . $key;
			if ( !isset($args[$new_key])) {
				$this->$key = '';
			}else {
				$this->$key = $args[$new_key];
			}
		}
	}
	
	
	
	function get_token_link() {
		$url = 'https://api.envato.com/token';
		$args = array(
			'grant_type'=>'authorization_code',
			'code'=> $this->code,
			'client_id'=> $this->oAuth_client_ID,
			'client_secret'=> $this->app_secret_key,
		);
		
		$response = wp_remote_post( $url, array(
			'method' => 'POST',
			'timeout' => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking' => true,
			'headers' => array(),
			'body' => $args,
			'cookies' => array()
		    )
		);
		
		if ( !is_wp_error( $response ) ) {
		   $info = json_decode( $response['body'] ) ;
		   $data = get_option('c5-market-affiliate');
		   foreach ($info as $key => $value) {
		   		
		   		$data['envato_'. $key] = $value;
		   		$this->$key = $value;
		   }
		   $data['envato_last_update'] = time();
		   $this->last_update = time();
		   update_option('c5-market-affiliate', $data);
		}
	}
	
	function get_authorization_link(){
		$url = 'https://api.envato.com/authorization?response_type=code&client_id='.$this->oAuth_client_ID.'&redirect_uri=' . $this->redirect_url;
		return $url;
	}
	
	function get_item_by_url($url) {
		$url_atts = explode('/', $url);
		
		
		if (isset($url_atts[5])) {
			$this->get_item( $url_atts[5] );
		}
	}
	
	function get_user_items($username= 'code125', $marketplace = 'themeforest') {
		
		$url = 'https://api.envato.com/v1/market/new-files-from-user:'.$username.','.$marketplace.'.json';
		$data = $this->execute($url);
		$items = array();
		if (isset($data['new-files-from-user'])) {
			return $data['new-files-from-user'];
		}
		return $items;
	}
	function get_new_items($marketplace= 'themeforest', $category = 'wordpress') {
		
		$url = 'https://api.envato.com/v1/market/new-files:'.$marketplace.','.$category.'.json';
		$data = $this->execute($url);
		$items = array();
		if (isset($data['new-files'])) {
			return $data['new-files'];
		}
		return $items;
		
	}
	function get_popular_items($marketplace= 'themeforest') {
		
		$url = 'https://api.envato.com/v1/market/popular:'.$marketplace.'.json';
		$data = $this->execute($url);
		$items = array();
		if (isset($data['popular'])) {
			return $data['popular']['items_last_week']; 
		}
		return $items;
	}
	function get_featured_items($marketplace= 'themeforest') {
		
		$url = 'https://api.envato.com/v1/market/features:'.$marketplace.'.json';
		$data = $this->execute($url);
		$items = array();
		if (isset($data['features'])) {
			return $data['features']['featured_file'];
		}
		return $items;
	}
	function get_random_items($marketplace= 'themeforest') {
		
		$url = 'https://api.envato.com/v1/market/random-new-files:'.$marketplace.'.json';
		$data = $this->execute($url);
		$items = array();
		if (isset($data['random-new-files'])) {
			return $data['random-new-files'];
		}
		return $items;
	}
	
	
	function get_item($id) {
		$url = 'https://api.envato.com/v1/market/item:'.$id.'.json';
		$data = $this->execute($url);
		
		return $data['item'];
	}
	
	function refresh_token() {
		$url = 'https://api.envato.com/token';
		$args = array(
			'grant_type'=>'refresh_token',
			'refresh_token'=> $this->refresh_token,
			'client_id'=> $this->oAuth_client_ID,
			'client_secret'=> $this->app_secret_key,
		);
		
		$response = wp_remote_post( $url, array(
			'method' => 'POST',
			'timeout' => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking' => true,
			'headers' => array(),
			'body' => $args,
			'cookies' => array()
		    )
		);
		
		if ( !is_wp_error( $response ) ) {
		   $info = json_decode( $response['body'] ) ;
		   $data = get_option('c5-market-affiliate');
		   foreach ($info as $key => $value) {
		   		
		   		$data['envato_'. $key] = $value;
		   		$this->$key = $value;
		   }
		   $data['envato_last_update'] = time();
		   $this->last_update = time();
		   update_option('c5-market-affiliate', $data);
		}
	}
	
	function expiration_check() {
		$expired = $this->last_update + $this->expires_in - 100;
		if (time() > $expired ) {
			$this->refresh_token();
		}
	}
	
	function execute($api_url) {
		
		$this->expiration_check();
		
		$ch = curl_init();
		$headr = array();
		$headr[] = 'Content-length: 0';
		$headr[] = 'Content-type: application/json';
		$headr[] = 'Authorization: Bearer '.$this->access_token; // my token for the api
		
		curl_setopt($ch, CURLOPT_HTTPHEADER,$headr);
		curl_setopt($ch, CURLOPT_URL,$api_url);
		curl_setopt($ch, CURLOPT_USERAGENT,'Mozilla/5.0 (compatible; '.$this->app_name.')'); // my product name
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$ch_data = curl_exec($ch);
		curl_close($ch);
		if(!empty($ch_data)) {
		 $json_data = json_decode($ch_data, true);
		  return $json_data;
		}
	}
	
	function myFunction() {
		
	}
	
	
}


 ?>