<?php 
// Creating the widget 
class C5MA_feed_widget extends WP_Widget {
	
	function __construct() {
		parent::__construct(
		// Base ID of your widget
		'c5ma_feed_widget', 
		
		// Widget name will appear in UI
		__('[Market Affiliate] Market Feed', 'c5-market-affiliate'), 
		
		// Widget description
		array( 'description' => __( 'Market Affiliate Envato Market Feed Widget', 'c5-market-affiliate' ), ) 
	);
}

// Creating widget front-end
// This is where the action happens
public function widget( $args, $instance ) {
	$title = apply_filters( 'widget_title', $instance['title'] );
	// before and after widget arguments are defined by themes
	echo $args['before_widget'];
	if ( ! empty( $title ) )
	echo $args['before_title'] . $title . $args['after_title'];
	
	// This is where you run the code and display the output
	echo '<div class="clearfix">';
	echo do_shortcode('[c5ma_envato_feed method="'.$instance['method'].'" shape="'.$instance['shape'].'" marketplace="'.$instance['marketplace'].'" category="'.$instance['category'].'" count="'.$instance['count'].'" ]');
	echo '</div>';
	
	echo $args['after_widget'];
}

// Widget Backend 
public function form( $instance ) {
	if ( isset( $instance[ 'title' ] ) ) {
		$title = $instance[ 'title' ];
	}else {
		$title = '';
	}
	if ( isset( $instance[ 'method' ] ) ) {
		$method = $instance[ 'method' ];
	}else {
		$method = '';
	}
	if ( isset( $instance[ 'shape' ] ) ) {
		$shape = $instance[ 'shape' ];
	}else {
		$shape = '';
	}
	if ( isset( $instance[ 'marketplace' ] ) ) {
		$marketplace = $instance[ 'marketplace' ];
	}else {
		$marketplace = '';
	}
	if ( isset( $instance[ 'category' ] ) ) {
		$category = $instance[ 'category' ];
	}else {
		$category = '';
	}
	if ( isset( $instance[ 'count' ] ) ) {
		$count = $instance[ 'count' ];
	}else {
		$count = '';
	}
	
	// Widget admin form
	?>
	<p>
		<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ,'c5-market-affiliate'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'method' ); ?>"><?php _e( 'Feed Type:' , 'c5-market-affiliate' ); ?></label> 
		<select class="widefat" id="<?php echo $this->get_field_id( 'method' ); ?>" name="<?php echo $this->get_field_name( 'method' ); ?>">
		<?php 
		$saved_value = $method;
		$options = array(
			array(
				'label' => 'New items',
				'value' => 'new'
			),
			array(
				'label' => 'Popular',
				'value' => 'popular'
			),
			array(
				'label' => 'Featured',
				'value' => 'featured'
			),
			array(
				'label' => 'Random',
				'value' => 'random'
			)
		);
		foreach ($options as $option) {
			$selected = '';
			if ($option['value'] == $saved_value) {
				$selected = 'selected="selected"';
			}
			echo '<option value="'.$option['value'].'" '.$selected.'>'.$option['label'].'</option>';
		}
		 ?>
		
		</select>
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'shape' ); ?>"><?php _e( 'Shape:' , 'c5-market-affiliate' ); ?></label> 
		<select class="widefat" id="<?php echo $this->get_field_id( 'shape' ); ?>" name="<?php echo $this->get_field_name( 'shape' ); ?>">
		<?php 
		$saved_value = $shape;
		$options = array(
			array(
				'label' => 'Big',
				'value' => 'big'
			),
			array(
				'label' => 'Wide',
				'value' => 'wide'
			),
			array(
				'label' => 'Tall',
				'value' => 'tall'
			),
			array(
				'label' => 'Thumbnail',
				'value' => 'thumbnail'
			),
			array(
				'label' => 'Sidebar',
				'value' => 'sidebar'
			),
		);
		foreach ($options as $option) {
			$selected = '';
			if ($option['value'] == $saved_value) {
				$selected = 'selected="selected"';
			}
			echo '<option value="'.$option['value'].'" '.$selected.'>'.$option['label'].'</option>';
		}
		 ?>
		
		</select>
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'marketplace' ); ?>"><?php _e( 'MarketPlace:' , 'c5-market-affiliate' ); ?></label> 
		<select class="widefat" id="<?php echo $this->get_field_id( 'marketplace' ); ?>" name="<?php echo $this->get_field_name( 'marketplace' ); ?>">
		<?php 
		$saved_value = $marketplace;
		$options = array(
			array(
				'label' => 'ThemeForest',
				'value' => 'themeforest'
			),
			array(
				'label' => 'CodeCanyon',
				'value' => 'codecanyon'
			),
			array(
				'label' => 'VideoHive',
				'value' => 'videohive'
			),
			array(
				'label' => 'AudioJungle',
				'value' => 'audiojungle'
			),
			array(
				'label' => 'GraphicRiver',
				'value' => 'graphicriver'
			),
			array(
				'label' => 'PhotoDune',
				'value' => 'photodune'
			),
			array(
				'label' => '3DOcean',
				'value' => '3docean'
			),
			array(
				'label' => 'ActiveDen',
				'value' => 'activeden'
			),
		);
		foreach ($options as $option) {
			$selected = '';
			if ($option['value'] == $saved_value) {
				$selected = 'selected="selected"';
			}
			echo '<option value="'.$option['value'].'" '.$selected.'>'.$option['label'].'</option>';
		}
		 ?>
		
		</select>
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'category' ); ?>"><?php _e( 'Category:' ,'c5-market-affiliate'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'category' ); ?>" name="<?php echo $this->get_field_name( 'category' ); ?>" type="text" value="<?php echo esc_attr( $category ); ?>" />
	</p>
	
	<p>
		<label for="<?php echo $this->get_field_id( 'count' ); ?>"><?php _e( 'Count:' ,'c5-market-affiliate'); ?></label> 
		<input class="widefat" id="<?php echo $this->get_field_id( 'count' ); ?>" name="<?php echo $this->get_field_name( 'count' ); ?>" type="text" value="<?php echo esc_attr( $count ); ?>" />
	</p>
	<?php 
}

// Updating widget replacing old instances with new
public function update( $new_instance, $old_instance ) {
	$instance = array();
	$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
	$instance['method'] = ( ! empty( $new_instance['method'] ) ) ? strip_tags( $new_instance['method'] ) : '';
	$instance['shape'] = ( ! empty( $new_instance['shape'] ) ) ? strip_tags( $new_instance['shape'] ) : '';
	$instance['marketplace'] = ( ! empty( $new_instance['marketplace'] ) ) ? strip_tags( $new_instance['marketplace'] ) : '';
	$instance['category'] = ( ! empty( $new_instance['category'] ) ) ? strip_tags( $new_instance['category'] ) : '';
	$instance['count'] = ( ! empty( $new_instance['count'] ) ) ? strip_tags( $new_instance['count'] ) : '';
	return $instance;
}
} // Class c5ma_feed_widget ends here

// Register and load the widget
function c5ma_feed_load_widget() {
	register_widget( 'C5MA_feed_widget' );
}
add_action( 'widgets_init', 'c5ma_feed_load_widget' );

?>